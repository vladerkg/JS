﻿function UserRegisterInit () {
    $('#TxtUsuarioRed').focus();
    inicializaControles();
    $("input[name=tipoEmpleado]").change(function ()
    {
        changeTipoEmpleado();
    });

}



function searchUsuarioRed()
{
    limpiarCamposReg();
    var _url = 'uiUserRegister.aspx/searchUsuarioRed';

    var TipoAute = $('#TipoAcceso').val();
    var sistema = $('#cbSistema').val()
    var user = $('#TxtUsuarioRed').val();
    var pass = $('#TxtPasswordRed').val();

    if (user == '' || pass == '') {
        if (TipoAute == 1) {
            $('#LabMessageRegister').text('Introduzca Nomina y RFC para registrarse');
            $('#MessageRegister').fadeIn("slow");

        }
        else {
            $('#LabMessageRegister').text('Introduzca su usuario de red y contraseña');
            $('#MessageRegister').fadeIn("slow");
        }
    }
    else {

        //$('#TxtUsuarioRed').attr('disabled', 'disabled');
        //$('#TxtPasswordRed').attr('disabled', 'disabled');
            
        $('#LoaderRegister').fadeIn('slow');


        $.ajax({
            type: "POST",
            url: _url,
            data: '{"User":"' + user + '", "Pass":"' + pass + '" }',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (UsrRes) {
                $('#LoaderRegister').fadeOut('fast');
                if (!UsrRes.d.isValid)//si no existe
                {
                    alert(UsrRes.d.msgError);
                    $('#LabMessageRegister').text(UsrRes.d.msgError);
                    $('#MessageRegister').fadeIn("slow");
                    setAllCamposRegHabilitado(false);
                    return false;
                }
                else //si existe en Active Directory
                {
                    //carga de datos en inputs
                    $('#MessageRegister').css('display', 'none');
                    $('#TxtNumNomina').val(UsrRes.d.nomina); 
                    $('#TxtEmail').val(UsrRes.d.email);
                    $('#TxtApellidoPaterno').val(UsrRes.d.apellidoPaterno);
                    $('#TxtApellidoMaterno').val(UsrRes.d.apellidoMaterno);
                    $('#TxtNombres').val(UsrRes.d.nombres);
                    $('#TxtPuesto').val(UsrRes.d.puesto); //aqui deberia ser Id de catalogo
                    //validaciones adicionales
                    
                    //if (UsrRes.d.nomina == null || UsrRes.d.nomina == "") //quiere decir que no son de Nissan
                    //{
                    //    $('#cbEmpresa').fadeIn("slow");
                    //    $('#lblEmpresa').fadeIn("slow");
                    //}
                    //else
                    //{
                    //    $('#cbEmpresa').fadeOut("fast");
                    //    $('#lblEmpresa').fadeOut("fast");
                    //}
                    if (UsrRes.d.nomina != "") //quiere decir que no son de Nissan
                        $("#TxtNumNomina").prop("disabled", true);

                    //si ya existe el empleado
                    if (UsrRes.d.empleadoInfo != null)
                    {
                        $('#TxtEmpleadoId').val(UsrRes.d.empleadoId);
                        $('#cbLocalidad').val(UsrRes.d.empleadoInfo.Id_Localidad)
                        $('#cbTipoEmpleado').val(((UsrRes.d.empleadoInfo.Id_TipoEmpleado) ? UsrRes.d.empleadoInfo.Id_TipoEmpleado : 0));
                        $('#cbTipoContrato').val(((UsrRes.d.empleadoInfo.Id_TipoContrato) ? UsrRes.d.empleadoInfo.Id_TipoContrato : 0));
                        $('#cbClasificacion').val(((UsrRes.d.empleadoInfo.Id_ClasifEmpleado) ? UsrRes.d.empleadoInfo.Id_ClasifEmpleado : 0));
                        $('#TxtFechaNac').val(((UsrRes.d.empleadoInfo.FechaNacimiento) ? UsrRes.d.empleadoInfo.FechaNacimiento : 0));

                    }
                    //si ya esta registrado en LMS
                    if (UsrRes.d.registradoLMS)
                    {

                        //$('#TxtEmpleadoId').val(UsrRes.d.empleadoId);
                        //$('#cbLocalidad').val(UsrRes.d.empleadoInfo.Id_Localidad)
                        //$('#cbTipoEmpleado').val(((UsrRes.d.empleadoInfo.Id_TipoEmpleado) ? UsrRes.d.empleadoInfo.Id_TipoEmpleado : 0));
                        //$('#cbTipoContrato').val(((UsrRes.d.empleadoInfo.Id_TipoContrato) ? UsrRes.d.empleadoInfo.Id_TipoContrato : 0));
                        //$('#cbClasificacion').val(((UsrRes.d.empleadoInfo.Id_ClasifEmpleado) ? UsrRes.d.empleadoInfo.Id_ClasifEmpleado : 0));
                        //$('#TxtFechaNac').val(((UsrRes.d.empleadoInfo.FechaNacimiento) ? UsrRes.d.empleadoInfo.FechaNacimiento : 0));
                        

                        alert('Este usuario de red ya esta registrado en el sistema LMS');
                        $('#LabMessageRegister').text('Este usuario de red ya esta registrado en el sistema LMS');
                        $('#MessageRegister').fadeIn("slow");

                        
                    }
                        //si no esta registrado
                    else
                    {
                        //habilitar/deshabilitar campos
                        setAllCamposRegHabilitado(true);
                    }

                  
                }

                    
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    $('#LoaderRegister').fadeOut('fast');
                    alert("Se ha producido el siguiente error:" + error + +request.responseText);

                }
            }
        });
    }

    return false;

}
function inicializaControles() {
    iniciaCombos();
    BindDataPickers();
    //oculta controles
    setAllCamposRegHabilitado(false);
}
function BindDataPickers() {

    loadCSS('../Scripts/datepicker/css/datepicker.css');
    $.getScript('../Scripts/datepicker/js/bootstrap-datepicker.js', function () {
        //                    $('.TxtFechaIniF').datepicker({ format: 'dd/mm/yyyy' });
        //                    $('.TxtFechaFinF').datepicker({ format: 'dd/mm/yyyy' });
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);


        $('#TxtFechaNac').datepicker({ format: 'dd/mm/yyyy', autoclose: true }).on('changeDate', function (ev) {
            $(this).datepicker('hide');
        });


        $('#TxtFechaIngreso').datepicker({ format: 'dd/mm/yyyy', autoclose: true }).on('changeDate', function (ev) {
            $(this).datepicker('hide');
        });

        //$('#TxtFechaIngNissF').datepicker({ format: 'dd/mm/yyyy', autoclose: true }).on('changeDate', function (ev) {
        //    $(this).datepicker('hide');
        //});

        //$('#TxtFechaBaja').datepicker({ format: 'dd/mm/yyyy', autoclose: true }).on('changeDate', function (ev) {
        //    $(this).datepicker('hide');
        //});

          
    });
}

/***** INICIO Control de informacion de campos ********/
function limpiarCamposReg() {
    $('#MessageRegister').css('display', 'none');
    //$('select.fieldReg option[value="0"]').attr("selected", true);
    $("input.fieldReg:text ").val('');
    $('select.fieldReg').prop('selectedIndex', '0');
}
function setAllCamposRegHabilitado(habilitado)
{
    $(".fieldReg ").prop('disabled', (!habilitado)); //si se requiere habilitar mandar true

    if (habilitado) {$('#btnRegistrar').fadeIn('slow');}
    else { $('#btnRegistrar').fadeOut('fast'); }

}
function setUserHabilitado(habilitado)
{
    $(".fielduser").prop('disabled', (!habilitado)); //si se requiere habilitar mandar true
    //$('#searchRed').prop('disabled', (!habilitado));
    if (habilitado) {
        $('#searchRed').fadeIn('slow');
    }
    else { $('#searchRed').fadeOut('fast'); }
}
function onKeyPressReg(evt) {
    var nav = window.Event ? true : false;
    var key = nav ? evt.which : evt.keyCode;
    var res = true;
    if (key == undefined) {
        key = evt.keyCode;
    }
    if (key == 13)
        res = searchUsuarioRed();
    return res;
}
function limpiaUser()
{
    $('#TxtUsuarioRed').val('');
    $('#TxtPasswordRed').val('');

}
function LimpiarReg()
{
    limpiaUser();
    limpiarCamposReg();
    setAllCamposRegHabilitado(false);
    return false;
}
function changeTipoEmpleado()
{
    var tipo = $('input[name=tipoEmpleado]:checked').val();
    switch (tipo)
    {
        case 'E':
            interno();
            break;
        case 'S':
            sindicalizado();
            break;
    }
}
function sindicalizado()
{
    LimpiarReg();
    limpiaUser();
    setUserHabilitado(false);
    setAllCamposRegHabilitado(true);
    $('#TxtNumNomina').focus();
}
function interno()
{
    setUserHabilitado(true);
    LimpiarReg();
    setAllCamposRegHabilitado(false);
    $('#TxtUsuarioRed').focus();
}

/*****FIN Control de informacion de campos ********/


/*********CARGA DE COMBOS**********/

function iniciaCombos() {
    cargarSexo();
    obtenerCatalogosInicales();
    cargarCatalogoWorkDay("cbDireccion", 2, 0, 0, 0, 0, 0);
    fillCombo('#cbTipoEmpleado', 'uiUserRegister.aspx/consultaTipoEmpleado', null, '');

    $('#cbTipoContrato').change(changeTipoContrato);

}

function changeTipoContrato()
{
    
    var opcionSelected = $('#cbTipoContrato option:selected').text();
    
    //SOLO SI ES OUTSOURCING ASIGNAR AUTOMATICO EL NO DE NOMINA
    if (opcionSelected.toUpperCase().includes("OUTSOURCING")) {
        asignarNomina('mp');
        $("#TxtNumNomina").prop("disabled", true);
    }
    else
    {
        $('#TxtNumNomina').val("");
        $("#TxtNumNomina").prop("disabled", false);
    }

}
function asignarNomina(tipo)
{
    $('#TxtNumNomina').val("");
    $.ajax({
        type: 'POST',
        url: 'uiUserRegister.aspx/consultaNominaConsecutivo',
        data: '{tipo:"'+tipo+'"}',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            var res = msg.d;
            $('#TxtNumNomina').val(res);
            
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
   
}

function cargarSexo() {
    $('#cbSexo option').remove();

    $.ajax({
        type: 'POST',
        url: 'uiUserRegister.aspx/consultaSexo',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            var res = msg.d;
            if (res != null) {
                for (var i = 0; i < res.length; i++) {
                    $("#cbSexo").append('<option value="' + res[i].ID + '">' + res[i].Value + '</option>');
                }
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}

function obtenerCatalogosInicales() {

    var cbTipoContF = $("#cbTipoContrato");
    var cbClasifEmpleadoF = $("#cbClasificacion");
    //var cbAreaF = $("#cbAreaF");
    //var cbLugarNacimientoF = $("#cbLugarNacimientoF");
    //var cbPuestoF = $("#cbPuestoF");
    //var cbLugarEstudioF = $("#cbLugarEstudioF");
    //var cbGradoEscF = $("#cbGradoEscF");
    //var cbNomCarreraF = $("#cbNomCarreraF");
    //var cbInstEducF = $("#cbInstEducF");
    //var cbDocObtF = $("#cbDocObtF");
    
    //var cbTipoEmpF = $("#cbTipoEmpF");
      var cbLocalidad = $("#cbLocalidad");
    //var cboLocalidadCI = $("#cboLocalidadCI");
    $.ajax({
        type: 'POST',
        url: 'uiUserRegister.aspx/obtenerCatalogosIniciales',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {

            if (msg != null) {


                setTimeout(function () {
                    //Carga el combo tipo contrato
                    jsonResult = $.parseJSON(msg.d[1]);
                    var option = '<option value="0">Seleccione</option>';
                    for (var i = 0; i < jsonResult.length; i++) {
                        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                        //cbTipoContF.append('<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>');
                    }
                    cbTipoContF.find('option').remove().end().append(option);
                    option = null;
                }, 0);


                //setTimeout(function () {
                //    //Carga el combo lugar de nacimiento y lugar de estudios
                //    var jsonResult = $.parseJSON(msg.d[0]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                //    }
                //    cbLugarNacimientoF.find('option').remove().end().append(option);
                //    cbLugarEstudioF.find('option').remove().end().append(option);
                //    option = null;
                //}, 0);


                //setTimeout(function () {
                //    //Carga el combo puesto
                //    jsonResult = $.parseJSON(msg.d[2]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';

                //    }
                //    cbPuestoF.find('option').remove().end().append(option);
                //    option = null;
                //}, 0);

                //setTimeout(function () {
                //    //Carga el combo grado escolaridad
                //    jsonResult = $.parseJSON(msg.d[3]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';

                //    }
                //    cbGradoEscF.find('option').remove().end().append(option);
                //    option = null;

                //}, 0);

                //setTimeout(function () {
                //    //Carga el combo carrera
                //    jsonResult = $.parseJSON(msg.d[4]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';

                //    }
                //    cbNomCarreraF.find('option').remove().end().append(option);
                //    option = null;
                //}, 0);

                //setTimeout(function () {
                //    //Carga el combo institución educativa
                //    jsonResult = $.parseJSON(msg.d[5]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                //    }

                //    cbInstEducF.find('option').remove().end().append(option);
                //    option = null;
                //}, 0);

                //setTimeout(function () {
                //    //Carga el combo documento obtenido
                //    jsonResult = $.parseJSON(msg.d[6]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                //    }

                //    cbDocObtF.find('option').remove().end().append(option);
                //    option = null;
                //}, 0);

                setTimeout(function () {
                    //Carga el combo clasificación
                    jsonResult = $.parseJSON(msg.d[7]);
                    var option = '<option value="0">Seleccione</option>';
                    for (var i = 0; i < jsonResult.length; i++) {
                        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';

                    }
                    cbClasifEmpleadoF.find('option').remove().end().append(option);
                    option = null;
                }, 0);

                //setTimeout(function () {
                //    //Carga el combo tipo
                //    jsonResult = $.parseJSON(msg.d[8]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';

                //    }
                //    cbTipoEmpF.find('option').remove().end().append(option);
                //    option = null;
                //}, 0);

                setTimeout(function () {
                    //Carga el combo localidad
                    jsonResult = $.parseJSON(msg.d[9]);
                    var option = '<option value="0">Seleccione</option>';
                    for (var i = 0; i < jsonResult.length; i++) {
                        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                    }
                    cbLocalidad.find('option').remove().end().append(option);
                    //cboLocalidadCI.find('option').remove().end().append(option);
                    option = null;
                }, 0);


                //setTimeout(function () {
                //    //Carga el combo Área
                //    jsonResult = $.parseJSON(msg.d[10]);
                //    var option = '<option value="0">Seleccione</option>';
                //    for (var i = 0; i < jsonResult.length; i++) {
                //        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                //    }
                //    cbAreaF.find('option').remove().end().append(option);
                //    option = null;
                //}, 0);

            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });

}

//function cargarDireccion() {

//    $('#cbDireccion option').remove();
//    $('#cbGerencia option').remove();
//    $('#cbJefatura option').remove();
//    //$('#cbProcesoF option').remove();

//    var idLocalidad = $("#cbLocalidad").val();
//    if (idLocalidad != null && !isNaN(idLocalidad)) {
//        $.ajax({
//            type: 'POST',
//            url: 'uiUserRegister.aspx/consultaDirecciones',
//            data: '{"Id_Localidad":"' + idLocalidad + '"}',
//            contentType: 'application/json; charset=utf-8',
//            dataType: 'json',
//            //async: false,
//            success: function (msg) {
//                var res = msg.d;
//                if (res != null) {
//                    for (var i = 0; i < res.length; i++) {
//                        $("#cbDireccion").append('<option value="' + res[i].ID + '">' + res[i].Value + '</option>');
//                    }
//                }
//            },
//            error: function (request, status, error) {
//                if (request.status == 401) {
//                    document.location.href = "uiPublic/uiLogin.aspx";
//                } else {
//                    alert("Se ha producido el siguiente error:" + error);
//                    closePopup('popup2', 0);
//                }
//            }
//        });
//    }
//}

function cargarCatalogoWorkDay(nombreCombo, catalogo, Id_Localidad, Id_Direccion, Id_Gerencia, Id_Jefatura, Id_Proceso) {
    var ctrCombo = $("#" + nombreCombo);
    var _data = '{"cat":"' + catalogo + '","Id_Localidad":"' + Id_Localidad + '","Id_Direccion":"' + Id_Direccion + '","Id_Gerencia":"' + Id_Gerencia + '","Id_Jefatura":"' + Id_Jefatura + '","Id_Proceso":"' + Id_Proceso + '"}';
    $.ajax({
        type: 'POST',
        url: 'uiUserRegister.aspx/ObtenerCatalogo',
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg != null) {
                setTimeout(function () {

                    //Carga el combo
                    jsonResult = $.parseJSON(msg.d);
                    var option = '<option value="0">Seleccione</option>';
                    for (var i = 0; i < jsonResult.length; i++) {
                        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                    }
                    ctrCombo.find('option').remove().end().append(option);
                    option = null;
                }, 0);
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });

}
/*********FIN CARGA DE COMBOS**********/

/********** REGISTRAR ****************/
function Registrar() {
    
    $('#MessageRegister').css('display', 'none');
    var _url = '';
    var JSONCurso = '';

    var NumNomina = $('#TxtNumNomina').val().trim();
    var ApellidoPaterno = $('#TxtApellidoPaterno').val().trim();
    var ApellidoMaterno = $('#TxtApellidoMaterno').val().trim();
    var Nombre = $('#TxtNombres').val().trim();
    var Curp = $('#TxtCurp').val().trim();
    var RFC = $('#TxtRFC').val().trim();
    var Usuario = $('#TxtUsuarioRed').val();
    //var RutaImagen = $('#spImagen').text();
    var datSexo;
    if ($('#cbSexo').val() == 1) {
        datSexo = "M"
    }
    else {
        datSexo = "H"
    }
    var Sexo = datSexo;
    var FechaNac = $('#TxtFechaNac').val().trim();

    var FechaIng = $('#TxtFechaIngreso').val().trim();
    var Estatus = "1";
    var red = ""; //$('#TxtUsuarioRed').val().trim();

    var TipoCont = validarEntero($('#cbTipoContrato').val());
    var Puesto = $('#TxtPuesto').val();
    var ClasifEmpleado = validarEntero($('#cbClasificacion').val());
    var TipoEmp = validarEntero($('#cbTipoEmpleado').val());
    var Proceso = validarEntero($('#cbProceso').val());
    
    var localidad = validarEntero($('#cbLocalidad').val());

    //VALORES EMPTY
    var email = $('#TxtEmail').val();


    //VBF Se agregan los nuevos campos

    var direccion = validarEntero($('#cbDireccion').val());
    var gerencia = validarEntero($('#cbGerencia').val());
    var jefatura = validarEntero($('#cbJefatura').val());

    
    if (NumNomina == ' ' || Nombre == ' ' || Curp == ' ' || RFC == ' ' || FechaNac == ' ' || FechaIng == '' || localidad == 0 || direccion == 0 || direccion == null || (Estatus == '' || Estatus == 0))
    {

        $('#LabMessageRegister').html("Los campos marcados con <b>'*'</b> son <b>'Requeridos'</b>, verifique por favor.");
        $('#MessageRegister').fadeIn("slow");
    }
    else {
    //


        
        var idEmpleado = $('#TxtEmpleadoId').val();
        var confirmar = "";
        if (idEmpleado == 0) {

            //Valida si ya existe el empelado

            if (consultarEmpleadoNomina($("#TxtNumNomina").val().trim())) {
                showPopup('popup', "El empleado con nómina <b>" + $("#TxtNumNominaF").val().trim() + "</b> ya existe, no es posible insertar de nuevo ", null);
                return false;
            }

            confirmar = "¿Guardar nuevo empleado?";
        }
        else {
            confirmar = "¿Actualizar empleado?";
        }
        _url = 'uiUserRegister.aspx/guardarUsuario';
        var _props = {
            easing: 'easeOutBack', //uses jQuery easing plugin
            speed: 650,
            opacity: 0.4,
            modalColor: '#F8F8F8',
            modal: true,
            transition: 'fadeIn',
            modalClose: false,
            onClose: function () {
                if (popupResult == true) {
                    var JSONEmpleados = '';

                    if (idEmpleado == 0) {
                        
                        JSONEmpleados = '{"Id_Empleado":"0", "NumNomina":"' + NumNomina +
                                            '", "ApellidoPaterno":"' + ApellidoPaterno +
                                            '", "ApellidoMaterno":"' + ApellidoMaterno +
                                            '", "Nombre":"' + Nombre +
                                            '", "Curp":"' + Curp +
                                            '", "RFC":"' + RFC +
                                            '", "Sexo":"' + Sexo +
                                            '", "FechaNacimiento":"' + FechaNac +
                                            '", "Id_LugarNacimiento":"0'  +
                                            '", "FechaIngreso":"' + FechaIng +
                                            '", "Id_TipoContrato":"' + TipoCont +
                                            '", "Id_Puesto":"' + Puesto +
                                            //'", "NivelIngles":"' + NivelIngles +
                                            //'", "NivelJapones":"' + NivelJapones +
                                            //'", "OtroIdioma":"' + OtroIdioma +
                                            //'", "Id_LugarEstudio":"' + LugarEstudio +
                                            //'", "Id_GradoEscolaridad":"' + GradoEsc +
                                            //'", "Id_NombreCarrera":"' + NomCarrera +
                                            //'", "Id_InstitucionEducativa":"' + InstEduc +
                                            //'", "Id_DocumentoObtenido":"' + DocObt +
                                            //'", "OtrosEstudios":"' + OtroEstudio +
                                            //'", "OtrosCursosExter":"' + CursoExt +
                                            '", "Id_ClasifEmpleado":"' + ClasifEmpleado +
                                            '", "Id_TipoEmpleado":"' + TipoEmp +
                                           // '", "FechaIngreNiss":"' + FechaIngNiss +
                                            '", "Id_Proceso":"' + Proceso +
                                            //'", "Instructor":"' + Instructor +
                                            //'", "FechaBaja":"' + FechaBaja +
                                            '", "Estatus":"' + Estatus +
                                            '", "Id_Usuario":"' + Usuario +
                                            '", "Id_Localidad":"' + localidad +
                                            //'", "Id_InstrucExte":"' + id_InstrucExte +
                                            '", "Id_Direccion":"' + direccion +
                                            '", "Id_Gerencia":"' + gerencia +
                                            //'", "RutaImagen":"' + RutaImagen +
                                            '", "Id_Jefatura":"' + jefatura + '"}';
                    } else {
                        
                        JSONEmpleados = '{"Id_Empleado":"' + $('#TxtEmpleadoId').val() +
                                            '", "NumNomina":"' + NumNomina +
                                            '", "ApellidoPaterno":"' + ApellidoPaterno +
                                            '", "ApellidoMaterno":"' + ApellidoMaterno +
                                            '", "Nombre":"' + Nombre +
                                            '", "Curp":"' + Curp +
                                            '", "RFC":"' + RFC +
                                            '", "Sexo":"' + Sexo +
                                            '", "FechaNacimiento":"' + FechaNac +
                                            '", "Id_LugarNacimiento":"0' +
                                            '", "FechaIngreso":"' + FechaIng +
                                            '", "Id_TipoContrato":"' + TipoCont +
                                            '", "Id_Puesto":"' + Puesto +
                                            //'", "NivelIngles":"' + NivelIngles +
                                            //'", "NivelJapones":"' + NivelJapones +
                                            //'", "OtroIdioma":"' + OtroIdioma +
                                            //'", "Id_LugarEstudio":"' + LugarEstudio +
                                            //'", "Id_GradoEscolaridad":"' + GradoEsc +
                                            //'", "Id_NombreCarrera":"' + NomCarrera +
                                            //'", "Id_InstitucionEducativa":"' + InstEduc +
                                            //'", "Id_DocumentoObtenido":"' + DocObt +
                                            //'", "OtrosEstudios":"' + OtroEstudio +
                                            //'", "OtrosCursosExter":"' + CursoExt +
                                            '", "Id_ClasifEmpleado":"' + ClasifEmpleado +
                                            '", "Id_TipoEmpleado":"' + TipoEmp +
                                           // '", "FechaIngreNiss":"' + FechaIngNiss +
                                            '", "Id_Proceso":"' + Proceso +
                                            //'", "Instructor":"' + Instructor +
                                            //'", "FechaBaja":"' + FechaBaja +
                                            '", "Estatus":"' + Estatus +
                                            '", "Id_Usuario":"' + Usuario +
                                            '", "Id_Localidad":"' + localidad +
                                            //'", "Id_InstrucExte":"' + id_InstrucExte +
                                            '", "Id_Direccion":"' + direccion +
                                            '", "Id_Gerencia":"' + gerencia +
                                            //'", "RutaImagen":"' + RutaImagen +
                                            '", "Id_Jefatura":"' + jefatura + '"}';

                    }
                    
                    //alert(JSONEmpleados);
                    showLoader2();
                    $.ajax({
                        type: 'POST',
                        url: _url,
                        data: '{Usuario:"' + Usuario + '", Email:"'+ email + '" , Empleado:' + JSONEmpleados + '}',
                        contentType: 'application/json; charset=utf-8',
                        dataType: 'json',
                        success: function (res) {
                            if (res.d) {
                                if (res.d=="OK") {

                                    //if (idEmpleado == 0) {
                                   
                                    var _props2 = {
                                        easing: 'easeOutBack', //uses jQuery easing plugin
                                        speed: 650,
                                        opacity: 0.4,
                                        modalColor: '#F8F8F8',
                                        modal: true,
                                        transition: 'fadeIn',
                                        modalClose: false,
                                        onClose: function () {
                                            document.location.href = "uiLogin.aspx";
                                        }
                                    };
                                    showPopup('popup', 'Usuario correctamente registrado!', _props2);
                                    //}
                                    //else {
                                    //    showPopup('popup', 'Empleado actualizado', props);
                                    //}
                                }
                                else {
                                    
                                        //showPopup('popup', 'No fue posible actualizar los datos del empleado', props);
                                    $('#LabMessageRegister').html("No fue posible registrarse,  error: " + res.d );
                                    $('#MessageRegister').fadeIn("slow");
                                }
                            }
                        },
                        error: function (request, status, error) {
                            if (request.status == 401) {
                                document.location.href = "uiPublic/uiLogin.aspx";
                            } else {
                                alert("Se ha producido el siguiente error:" + error);
                            }
                            closePopup('popup2', 0);
                        }
                    });
                }
            }
        };
        
        showPopup('popup', confirmar, _props);
    }

    return false;
}

//Funcion para validar que se envie entero a travez de los combos
function validarEntero(valor) {
    if (valor == null || valor == undefined || valor == "" || isNaN(valor)) {
        return 0;
    }

    return valor;
}

function guardarUsuario() {
    var _url = '';
    var JSONUsuario = '';
    var validar = validarForm();
    if (validar == true) {
        showLoader2();
        var idUsuario = $('#lblIDUsuario').text() == '' ? '0' : $('#lblIDUsuario').text();
        var usuario = $('#TxtUsuario').val() == '' ? ' ' : $('#TxtUsuario').val();
        var perfil = $('#cbPerfil').val() == '' ? ' ' : $('#cbPerfil').val();
        var correo = $('#TxtCorreo').val() == '' ? ' ' : $('#TxtCorreo').val();
        var nomina = $('#TxtNomina').val() == '' ? ' ' : $('#TxtNomina').val();

        if ($('#lblIDUsuario').html().length == 0) {
            _url = 'uiCatalogos/uiUsuarios.aspx/guardarUsuario';
            var JSONUsuario = '{"Id_Usuario":"0"' +
                            ', "usuario":"' + usuario +
                            '", "id_Perfil":"' + perfil +
                            '", "mail":"' + correo +
                            '", "nomina":"' + nomina + '"}';

        } else {
            _url = 'uiCatalogos/uiUsuarios.aspx/actualizarUsuario';
            var JSONUsuario = '{"Id_Usuario":"' + idUsuario + '"' +
                            ', "usuario":"' + usuario +
                            '", "id_Perfil":"' + perfil +
                            '", "mail":"' + correo +
                            '", "nomina":"' + nomina + '"}';
        }

        $.ajax({
            type: 'POST',
            url: _url,
            data: '{Usuario:' + JSONUsuario + '}',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (msg) {
                if (msg.d == true) {
                    GetData(function () {
                        setTimeout(function () {
                            $('#CatContWrap').fadeIn('fast');
                            showPopup('popup', 'Usuario Guardado', props)
                            closePopup('popContent', 0);
                        }, 300);
                    })
                } else {
                    showPopup('popup', 'No se pudo guardar el usuario', props)
                    closePopup('popup2', 0);
                }
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                }
            }
        });
    } else {
        showPopup('popup', 'Debe llenar todos los campos para guardar la información', props)
        //alert('Debe llenar todos los campos para guardar la información');
    }
}

function consultarEmpleadoNomina(nomina) {
    
    var result = false;

    $.ajax({
        type: 'POST',
        url: 'uiUserRegister.aspx/consultarCursoPorEmpleados',
        data: '{ Empleados: {"NumNomina":"' + nomina + '"} }',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        async: false,
        success: function (resultado) {



            if (resultado.d != null) {
                var json = $.parseJSON(resultado.d);

                if (json != null && json != undefined && json != "") {
                    result = true;
                }
            }

            
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + request.responseText);
                closePopup('popup2', 0);
            }
        }
    });

    return result;
}