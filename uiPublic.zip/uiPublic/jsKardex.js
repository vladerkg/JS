﻿function GetData(callback) {
    buscarEmpleados(1, callback);
    //loadForm()

}


//function loadForm() {
//    $('#content > .main').load('uiReportes/uiKardex.aspx', function (response, status, xhr) {
//    $(document).ready(function () {

//        CargarControlSeleccionSubprogramas();
//     //   buscarEmpleados(1, callback);
//    });
//});
//}


function buscarEmpleados(tipoBusqueda, callback) {


    var _data = null;
    var validar = validarForm();
    var _url = 'uiReportes/uiKardex.aspx/'
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    var programa = $('#cbProgramasF option:selected').val();
    for (i in listaCookies) {
        var busca = listaCookies[i].search("IDEmpleado");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);

    if (tipoBusqueda == 1) {//Todos  
        _url = _url + 'consultarKardex'
        _data = '{ "Id_Empleado":"' + valor + '"}';

    }

    else {//Por Campos
        _url = _url + 'consultarKardexPorCampos'
        var check = $("input:checked").val();
        var nomina;
        var nombre;
        if (check == "NumNomina") {
            nomina = $('#txtDescripcion').val();
            nombre = '';

            if (nomina == "") {
                showPopup('popup', 'Ingrese Número de Nómina', null);
                return;
            }


        }
        else {
            nomina = '';
        }

        if (check == "Nombre") {
            nombre = $('#txtDescripcion').val();
            nomina = '';
            if (nombre == "") {
                showPopup('popup', 'Ingrese Nombre', null);
                return;
            }
        }
        else {
            nombre = '';
        }

        var area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
        var programa = $('#cbProgramasF').val() == '' ? ' ' : $('#cbProgramasF').val();
        //cambio antonio: agrego dos parámetro mas el cual va a buscar tambien por id subprograma y el id especialidad en el caso del GMTs, para los demas proceso es transparente, 
        // ya que modifique el sp (pcap_ConsultaMateriaKardex)
        var Tecnica = $('#cbTecnica').val() == '' ? ' ' : $('#cbTecnica').val();
        if (Tecnica == null || Tecnica == undefined || Tecnica == '')
            Tecnica = 0;
        var Subprograma = $('#cbSubProgramasF').val() == '' ? ' ' : $('#cbSubProgramasF').val();
        if (Subprograma == null || Subprograma == undefined || Subprograma == '')
            Subprograma = 0;
        var idEspecialidad = $('#cbEspecialidad :selected').val();
        if (idEspecialidad == null || idEspecialidad == undefined || idEspecialidad == '')
            idEspecialidad = 0;

        _data = '{ NumNomina:"' + nomina + '", Nombres:"' + nombre + '", "Id_Programa":"' + programa + '", "Id_Area":"' + area + '" ,"id_Subprograma": "' + Subprograma + '"}';


    }
    $.ajax({
        type: 'POST',
        url: _url,
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {

            $('#content > .main').load('uiReportes/uiKardex.aspx', function (response, status, xhr) {
                $('#CatContWrap #GridContent').append(CreateTableKardex(resultado.d));
                if (tipoBusqueda == 1) {

                    fillCombo('#cbAreaF', 'uiReportes/uiKardex.aspx/ListaAreas', null, 0)

                    filtrarArea(1);

                    $('#kardex')[0].style.visibility = "hidden";
                    $('#otros')[0].style.visibility = "hidden";
                }
                else {


                    fillCombo('#cbAreaF', 'uiReportes/uiKardex.aspx/ListaAreas', null, area)
                    filtrarArea(area);
                    $('#GridContent')[0].style.visibility = "visible"
                    //var x = document.getElementById("cbAreaF");
                    //var option = document.createElement("option");
                    //option.text = "Seleccionar";
                    //option.value = 0;
                    //x.add(option);
                   

                   
                    filtraproc(area, programa);

                    filtrasub(programa, Subprograma);
                    $('#kardex')[0].style.visibility = "visible";
                    $('#otros')[0].style.visibility = "visible";
                }
                if (callback && typeof (callback) === "function") {
                    callback();
                }
                //var x = $('#cbAreaF')[0];
                //    var option = document.createElement("option");
                //    option.text = "Seleccionar";
                //    option.value = 0;
                //    x.add(option);
                //$("#cbProgramasF")
                //var programa = $('#cbProgramasF option:selected').val();
                //filtrasub(programa);


            });
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
            }
        }
    });

}

function validarForm() {
    if ($('#cbAreaF').val() == 0 || $('#cbProgramasF').val() == 0) {
        return false;
    }
    return true;
}
//jdr 10/09/2018 se modificó función por secuencia de la pagina, era necesario que se filtrara los combos de uno por uno para mejor funcionalidad
function filtrarArea(_valor) {

    var areaAPre = $("#cbAreaF option:selected").text();
    var programa = $('#cbProgramasF option:selected').val();
    if (areaAPre == 'GMT-Global Master Trainer') {
        //    alert("filtro");
        document.getElementById('cbTecnica').style.visibility = "visible";
        document.getElementById('cbEspecialidad').style.visibility = "visible";
        document.getElementById('lblTecnica').style.visibility = "visible";
        document.getElementById('lblEspecialidad').style.visibility = "visible";
        $('#cbTecnica option').remove();
    }
    else {

        document.getElementById('cbTecnica').style.visibility = "hidden";
        document.getElementById('cbEspecialidad').style.visibility = "hidden";
        document.getElementById('lblTecnica').style.visibility = "hidden";
        document.getElementById('lblEspecialidad').style.visibility = "hidden";
        $('#cbTecnica option').remove();
    }
    //var _data = '{"Id_Area":"' + _valor + '", "Id_Localidad":"0"}';
    //fillCombo('#cbProgramasF', 'uiReportes/uiKardex.aspx/consultarAreaXProgramas', _data, 0);
    // filtraproc(_valor);

    $("#cbProgramasF").val('0');
    $("#cbsubProgramasF").val('0');
   
    var nombreEspe = '';
    var JSONConsulta = '{"Id_Especialidad":"0", "gEspecialidad": "' + nombreEspe + '"}';

    var _data1 = '{E:' + JSONConsulta + '}';

    fillCombo('#cbEspecialidad', 'uiReportes/uiKardex.aspx/ConsultarEspecialidad', _data1, 0);


}

//jdr 10/09/2018 --se creó función de filtrado de procesosos reciviendo como parametro el id del área
function filtraproc(_valor, grid) {
    var areaAPre = $("#cbAreaF option:selected").text();
    var _data = '{"Id_Area":"' + _valor + '", "Id_Localidad":"0"}';
    fillCombo('#cbProgramasF', 'uiReportes/uiKardex.aspx/consultarAreaXProgramas', _data, grid);

    $("#cbProgramasF").val(grid);
    $("#cbSubProgramasF").val('0');
    if (areaAPre == 'GMT-Global Master Trainer') {

        document.getElementById('cbTecnica').style.visibility = "visible";
        document.getElementById('cbEspecialidad').style.visibility = "visible";
        document.getElementById('lblTecnica').style.visibility = "visible";
        document.getElementById('lblEspecialidad').style.visibility = "visible";
        $('#cbTecnica option').remove();
    }
    else {

        document.getElementById('cbTecnica').style.visibility = "hidden";
        document.getElementById('cbEspecialidad').style.visibility = "hidden";
        document.getElementById('lblTecnica').style.visibility = "hidden";
        document.getElementById('lblEspecialidad').style.visibility = "hidden";
        $('#cbTecnica option').remove();
    }
    removeOptions(document.getElementById("cbSubProgramasF"));
    var x = document.getElementById("cbProgramasF");
    var option = document.createElement("option");
    $('#kardex')[0].style.visibility = "visible";
    $('#otros')[0].style.visibility = "visible";
    //option.text = "Seleccionar";
    //option.value = 0;
    //x.add(option);
    //x = document.getElementById("cbSubProgramasF");
    //option.text = "Seleccionar";
    //option.value = 0;
    //x.add(option);

}
//jdr 10/09/2018 --se creó función de filtrado de subprocesosos reciviendo como parametro el id del proceso
function filtrasub(_valor, antes) {


    //var programa = $('#cbProgramasF option:selected').val();
    var _data2 = '{ "Id_Programa": "' + _valor + '" }';

    fillCombo('#cbSubProgramasF', 'uiReportes/uiKardex.aspx/consultaComboSp', _data2, antes)

    var x = document.getElementById("cbSubProgramasF");
    var option = document.createElement("option");
    option.text = "Seleccionar";
    option.value = 0;
    x.add(option);
    $("#cbSubProgramasF").val(antes);
  

}

function filtrarMaterias(_valor, _select) {
    alert('materias');
    //iniciaCombos 
    $('#cbMateriaF option').remove();
    var _data = '{ "Id_Programa": "' + _valor + '" }';
    fillCombo('#cbMateriaF', 'uiReportes/uiKardex.aspx/consultaCursoXProg', _data, 0)
}

//jdr 10/09/2018 --se modificó función de filtrado de subprocesosos 

function filtrarSubProg(_valor, _select) {

    //iniciaCombos 
    var programa = $('#cbProgramasF option:selected').val();

    $('#cboSubPrograma option').remove();
    var _data = '{ "Id_Programa": "' + programa + '" }';
    fillCombo('#cbSubProgramasF', 'uiReportes/uiKardex.aspx/consultaComboSp', _data, 0)


}
//jdr 10/09/2018 --se creó función de CargarControlSeleccionSubprogramas en donde se carga una sub vista que permite el filtrado de áreas, proceso, subproceso y cursos
//no se utilizo pero ya se creo el control

//function CargarControlSeleccionSubprogramas() {
//    debugger
//    $('#div-uiControl_SubProgramas').load('uiControls/PartialView/uiControl_SubProgramas.aspx');
//}


function cerrarGrid() {

    llenacbTecnica();
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    for (i in listaCookies) {
        var busca = listaCookies[i].search("IdDiv");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);
    doClickProg(valor);

}

//Cambio antonio, funcion para llenar las tecnicas con base al id programa
function llenacbTecnica() {


    var areaAPre = $("#cbAreaF option:selected").text();
    if (areaAPre == 'GMT-Global Master Trainer') {
        document.getElementById('cbTecnica').style.visibility = "visible";
        document.getElementById('cbEspecialidad').style.visibility = "visible";
        document.getElementById('lblTecnica').style.visibility = "visible";
        document.getElementById('lblEspecialidad').style.visibility = "visible";
        $('#cbTecnica option').remove();
    }
    else {

        document.getElementById('cbTecnica').style.visibility = "hidden";
        document.getElementById('cbEspecialidad').style.visibility = "hidden";
        document.getElementById('lblTecnica').style.visibility = "hidden";
        document.getElementById('lblEspecialidad').style.visibility = "hidden";
        $('#cbTecnica option').remove();
    }
    var idPrograma = $("#cbProgramasF :selected").val();
    if (idPrograma > 0) {
        var _data = '{"Id_Programa":"' + idPrograma + '"}';
        fillCombo('#cbTecnica', 'uiReportes/uiKardex.aspx/consultaComboSp', _data, 0);
    }
    else {
        $('#cbTecnica option').remove();
    }
    //}
    //else {
    //    document.getElementById('cbTecnica').style.visibility = "hidden";
    //}
}
debugger
function doClickProg(event) {

    //cambio antonio: agrego un parámetro mas el cual va a buscar tambien por id subprograma en el caso del GMTs, para los demas proceso es transparente, 
    // ya que modifique el sp (pcap_ConsultaMateriaKardex)
    var Subprograma = $('#cbTecnica').val() == '' ? ' ' : $('#cbTecnica').val();
    if (Subprograma == null || Subprograma == undefined || Subprograma == '') {
        Subprograma = $('#cbSubProgramasF').val() == '' ? ' ' : $('#cbSubProgramasF').val();
        if (Subprograma == null || Subprograma == undefined || Subprograma == '') {
            Subprograma = 0;
        }
    }

    var tr = $(event.target).parent().parent();
    var area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
    var programa = $('#cbProgramasF').val() == '' ? ' ' : $('#cbProgramasF').val();
    document.cookie = "trEmpleado=" + tr.find("#TxtIdEmpleado").html();
    var IdFilesDiv = 'DivFiles_' + $(tr).find("#TxtIdEmpleado").text();
    $('.activeDivFile').animate({
        height: 0
    }, function () {
        $('.activeDivFile').html('');
        $('#' + IdFilesDiv).html('');
    });

    if (!$('#' + IdFilesDiv).length)
        $(tr).after('<tr class="FileDivContent"><td colspan="8"><div id="' + IdFilesDiv + '" align="center"></div></td></tr>');

    document.cookie = "IdDiv=" + event;

    if (!$(tr).next().find('div').hasClass('activeDivFile')) {
        $('#' + IdFilesDiv).animate({
            height: 50
        }, function () {

            $('#' + IdFilesDiv).append('<img  class="LoaderArchivos" src="App_Themes/PCAP/images/loading_hill.gif"/>');

            var misCookies = document.cookie;
            var listaCookies = misCookies.split(";")
            for (i in listaCookies) {
                var busca = listaCookies[i].search("IDPerfil");
                if (busca > -1) { micookie = listaCookies[i] }
            }
            var buscaValor;
            var igual = micookie.indexOf("=");
            var IDPerfil = micookie.substring(igual + 1);

            var _data = '{"Id_Empleado":"' + tr.find("#TxtIdEmpleado").html() + '", "Id_Programa":"' + programa + '", "Id_Area":"' + area + '", ' +
                        '"Id_Perfil":"' + IDPerfil + '","id_SubPrograma":"' + Subprograma + '"}';

            $.ajax({
                type: 'POST',
                url: 'uiReportes/uiKardex.aspx/consultarKardexDetalle',
                data: _data,
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (resultado) {
                    $('.LoaderArchivos').css('display', 'none');

                    $('#' + IdFilesDiv).append(CreateTableDetalle(resultado.d));
                    $('#' + IdFilesDiv + ' div.paginatorContainer').attr('style', '');

                    $('#' + IdFilesDiv).css('height', 'auto');

                    $('.activeDivFile').removeClass('activeDivFile');
                    $('#' + IdFilesDiv).addClass('activeDivFile');

                    $.ajax({
                        type: 'POST',
                        url: 'uiReportes/uiKardex.aspx/ConsultaTotalMateria',
                        data: '{"Id_Empleado":"' + tr.find("#TxtIdEmpleado").html() + '", "Id_Programa":"' + programa + '"}',
                        contentType: 'application/json; charset=utf-8',
                        dataType: 'json',
                        success: function (resultado) {
                            if (resultado.d == true) {
                                var s = document.cbProgramasF;
                                $('#RowImage').css('visibility', 'visible');
                                $('#Descripcion').html($('#cbProgramasF option:selected').text() + ' - CERTIFICADO');
                            }
                            else {
                                $('#RowImage').css('visibility', 'hidden');
                                $('#Descripcion').html('');
                            }
                        },
                        error: function (request, status, error) {
                            if (request.status == 401) {
                                document.location.href = "uiPublic/uiLogin.aspx";
                            } else {
                                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                            }
                        }
                    });
                },
                error: function (request, status, error) {
                    if (request.status == 401) {
                        document.location.href = "uiPublic/uiLogin.aspx";
                    } else {
                        alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                    }
                }
            });
        });
    } else {
        $('.activeDivFile > .gridTable').css('display', 'none');
        $('.activeDivFile').removeClass('activeDivFile');
    }
    selectGridRow(tr);
}
debugger
function reporte(event) {

    //cambio antonio: agrego un parámetro mas el cual va a buscar tambien por id subprograma en el caso del GMTs, para los demas proceso es transparente, 
    // ya que modifique el sp (pcap_ConsultaMateriaKardex)
    var Subprograma = $('#cbTecnica').val() == '' ? ' ' : $('#cbTecnica').val();
    if (Subprograma == null || Subprograma == undefined || Subprograma == '') {
        Subprograma = $('#cbSubProgramasF').val() == '' ? ' ' : $('#cbSubProgramasF').val();
        if (Subprograma == null || Subprograma == undefined || Subprograma == '') {
            Subprograma = 0;
        }
    }
    var idEspecialidad = $('#cbEspecialidad').val() == '' ? ' ' : $('#cbEspecialidad').val();
    if (idEspecialidad == null || idEspecialidad == undefined || idEspecialidad == '')
        idEspecialidad = 0;

    var areaAPre = $("#cbAreaF option:selected").text();
    if (areaAPre == 'GMT-Global Master Trainer' && (Subprograma == 0 || idEspecialidad == 0)) {
        showPopup('popup', "Debe seleccionar de nuevo el programa, la especialidad y la tecnica", props)
    }

    else {
        var tr = $(event.target).parent().parent();
        var area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
        var programa = $('#cbProgramasF').val() == '' ? ' ' : $('#cbProgramasF').val();
        var _data = '{"Id_Empleado":"' + tr.find("#TxtIdEmpleado").html() + '", "Id_Programa":"' + programa + '", "Id_Area":"' + area + '",' +
                      '"Id_SubPrograma":"' + Subprograma + '", "Id_Especialidad":"' + idEspecialidad + '"}';
        $.ajax({
            type: 'POST',
            url: 'uiReportes/uiKardex.aspx/consultaReporte',
            data: _data,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (resultado) {

                window.open("uiComun/AuxTableToXls.aspx");
            },
            error: function (request, status, error) {

                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error: " + error + request.responseText);
                    closePopup('popup2', 0);
                }
            },
            fail: function (error) {
                alert('error');
            }
        });
        selectGridRow(tr);
    }
}

function getCalendarFechaPosData(event) {
    var total = 0;
    var tr = $(event.target).parent().parent();
    var idMateria = $(tr).find("#TxtIDMateria").text();
    document.cookie = "Id_Materia=" + $(tr).find("#TxtIDMateria").text();
    var _contentProps =
    {
        easing: 'fadeIn', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        modalClose: false,
        onOpen: function () {
            setTimeout(function () { $(window).resize() }, 700);
        }
    }
    var _url = 'uiReportes/uiKardex.aspx/';
    _url = _url + 'FechasPosData'
    $.ajax({
        type: 'POST',
        url: _url,
        data: '{Id_Materia:' + idMateria + '}',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            for (var i = 0; i < resultado.d._rowValues.length; i++) {
                total = total + 1;
            }

            if (total > 0) {
                loadContent('#popContent > .content', '#ContWrapFechasPos',
                    function () {
                        $('#popContent > .content #DetGridContentFp').html(CreateTableKardex(resultado.d));
                        $('#popContent > .content #Title').html($(tr).find("#TxtCurso").text());
                        $('#popContent > .content #descripF').html("Fechas disponibles para el curso: ");
                        showPContent('popContent', _contentProps);
                    });
                showLoader(true);
            }
            else {
                loadContent('#popContent > .content', '#ContWrapFechasPos',
                    function () {
                        $('#popContent > .content #desTr').css('display', 'block');
                        $('#popContent > .content #Title').html($(tr).find("#TxtCurso").text());
                        $('#popContent > .content #descripF').html("No hay fechas disponibles, deseas que se te notifique para el curso: ");
                        showPContent('popContent', _contentProps);
                    });
                showLoader(true);
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + request.responseText);
                closePopup('popup2', 0);
            }
        }
    });
}

function Postular(event) {
    var tr = $(event.target).parent().parent();
    var Id_Curso = $(tr).find("#TxtIDCurso").text();

    var proms = {
        easing: 'easeOutBack', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        transition: 'fadeIn',
        modalClose: false,
        onClose: function () {
            showLoader(false);
            $('#ContWrapFechasPos').fadeIn('fast');
        }
    }

    var _props = {
        easing: 'easeOutBack', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        transition: 'fadeIn',
        modalClose: false,
        onClose: function () {
            $('#popup #pbtnAceptar').text('Aceptar')
            $('#popup #pbtnCancelar').text('Cancelar')
            if (popupResult == 1) {
                $.ajax({
                    type: "POST",
                    url: "uiReportes/uiKardex.aspx/Postular",
                    data: '{Id_Curso :' + Id_Curso + '}',
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (resultado) {
                        if (resultado.d) {
                            showPopup('popup', 'Tu solicitud ha sido recibida, espera la confirmación de tu participación en tu correo', proms)
                            closePopup('popContent', 0);
                            cerrarGrid();
                            cerrarGrid();

                        }
                    },
                    error: function (request, status, error) {
                        if (request.status == 401) {
                            document.location.href = "uiPublic/uiLogin.aspx";
                        } else {
                            alert("Se ha producido el siguiente error:" + error);
                        }
                    }
                });
            }
        }
    };
    showPopup('popup', '¿Deseas participar en el curso?', _props);
    $('#popup #pbtnAceptar').text('Si')
    $('#popup #pbtnCancelar').text('No')
    return false;
}

function notificar() {
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    for (i in listaCookies) {
        var busca = listaCookies[i].search("Id_Materia");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);
    var _props = {
        easing: 'easeOutBack', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        transition: 'fadeIn',
        modalClose: false,
        onClose: function () {
            if (popupResult == 1) {
                var _data = '{ Id_Materia:' + valor + ' }';
                var _url = 'uiReportes/uiKardex.aspx/notificar'
                $.ajax({
                    type: 'POST',
                    url: _url,
                    data: _data,
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    success: function (resultado) {
                        if (resultado.d.toString() == "-1") {
                            showPopup('popup', 'Ocurrio un error, no se pudo programar la notificación', props)
                            closePopup('popContent', 0);
                        }
                        else if (resultado.d.toString() == "1") {
                            showPopup('popup', 'No se puede guardar mas de una notificacion para una materia', props)
                            closePopup('popContent', 0);
                        }
                        else {
                            showPopup('popup', 'Notificación Guardada', props)
                            closePopup('popContent', 0);
                        }
                    },
                    fail: function (error) {
                        alert('error');

                    }
                });
                popResult = null;
            }
        }
    };
    showPopup('popup', '¿Quiere que se le notifique cuando se abra este curso?', _props)
}

function DC3(event) {
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    for (i in listaCookies) {
        var busca = listaCookies[i].search("trEmpleado");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);

    // var curso = "lalalalala";
    var tr = $(event.target).parent().parent();
    var curso = tr.find("#TxtCurso").html();
    var materia = tr.find("#TxtIDMateria").html();
    var _data = '{"Id_Empleado":"' + valor + '", "Id_Materia":"' + materia + '", "curso":"' + curso + '"}';
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiKardex.aspx/consultaReporteDC3',
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            window.open("uiComun/AuxTableToXls.aspx");
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + request.responseText);
                closePopup('popup2', 0);
            }
        },
        fail: function (error) {
            alert('error');
        }
    });
    selectGridRow(tr);
}



function Evaluacion(event) {
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    for (i in listaCookies) {
        var busca = listaCookies[i].search("trEmpleado");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);

    var tr = $(event.target).parent().parent();
    $('#LabIdCurso').html(tr.find("#TxtIDCurso").html());
    selectGridRow(tr);
    DetalleEvaluacion(valor, tr.find("#TxtIDCurso").html());
}

function DetalleEvaluacion(idEmpleado, idCurso) {
    var _contentProps =
    {
        easing: 'fadeIn', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        modalClose: false,
        onOpen: function () {
            setTimeout(function () { $(window).resize() }, 700);
        }
    }
    $.ajax({
        type: "POST",
        url: "uiReportes/uiKardex.aspx/consultarEva",
        data: '{Id_Curso:' + idCurso + ', Id_Empleado:' + idEmpleado + '}',
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (eval) {
            loadContent('#popContent > .content', '#ContWrapEvaluacion',
                    function () {
                        if (eval.d.eval1.toString() == "true")
                            $('#popContent > .content #cEval1').attr('checked', true)
                        else
                            $('#popContent > .content #cEval1').attr('checked', false)

                        if (eval.d.eval2.toString() == "true")
                            $('#popContent > .content #cEval2').attr('checked', true)
                        else
                            $('#popContent > .content #cEval2').attr('checked', false)

                        if (eval.d.eval3.toString() == "true")
                            $('#popContent > .content #cEval3').attr('checked', true)
                        else
                            $('#popContent > .content #cEval3').attr('checked', false)

                        if (eval.d.Eval1Activa.toString() == "true") {
                            $('#popContent > .content #Eval1Activa').attr('checked', true)
                            var suma = parseInt(eval.d.valor1.toString());
                            var resultado = suma / 1;
                            $('#popContent > .content #calFinal').val(resultado);
                        }
                        else {
                            $('#popContent > .content #Eval1Activa').attr('checked', false)
                            $('#popContent > .content #txtEval1').css('visibility', 'hidden')
                            $('#popContent > .content #lblEval1').css('visibility', 'hidden')
                        }
                        if (eval.d.Eval1Activa.toString() == "true" && eval.d.Eval2Activa.toString() == "true") {
                            $('#popContent > .content #Eval2Activa').attr('checked', true)
                            var suma = parseInt(eval.d.valor1.toString()) + parseInt(eval.d.valor2.toString());
                            var resultado = suma / 2;
                            $('#popContent > .content #calFinal').val(resultado);
                        }
                        else {
                            $('#popContent > .content #Eval2Activa').attr('checked', false)
                            $('#popContent > .content #txtEval2').css('visibility', 'hidden')
                            $('#popContent > .content #lblEval2').css('visibility', 'hidden')
                        }
                        if (eval.d.Eval1Activa.toString() == "true" && eval.d.Eval2Activa.toString() == "true" && eval.d.Eval3Activa.toString() == "true") {
                            $('#popContent > .content #Eval3Activa').attr('checked', true)
                            var suma = parseInt(eval.d.valor1.toString()) + parseInt(eval.d.valor2.toString()) + parseInt(eval.d.valor3.toString());
                            var resultado = suma / 3;
                            $('#popContent > .content #calFinal').val(resultado);
                        }
                        else {
                            $('#popContent > .content #Eval3Activa').attr('checked', false)
                            $('#popContent > .content #txtEval3').css('visibility', 'hidden')
                            $('#popContent > .content #lblEval3').css('visibility', 'hidden')
                        }
                        $('#popContent > .content #cAsistio').is(':checked') ? "true" : "false";

                        $('#popContent > .content #lblIdEmpleado').val(eval.d.idEmpleado.toString());
                        $('#popContent > .content #lblIdCurso').val(eval.d.IdCurso.toString());
                        $('#popContent > .content #txtEval1').val(eval.d.valor1.toString());
                        $('#popContent > .content #txtEval2').val(eval.d.valor2.toString());
                        $('#popContent > .content #txtEval3').val(eval.d.valor3.toString());
                        $('#popContent > .content #lblCalAprobatoria').val(eval.d.calApro.toString());

                        $('#popContent > .content #TxtCurso0').val(eval.d.title.toString());

                        $('#popContent > .content #TxtEmpleado').val(eval.d.instructor.toString());
                        $('#popContent > .content #TxtPrograma0').val(eval.d.DesProg.toString());
                        $('#popContent > .content #TxtArea0').val(eval.d.area.toString());

                        if (parseInt($('#popContent > .content #calFinal').val()) >= parseInt($('#popContent > .content #lblCalAprobatoria').val()))
                            $('#popContent > .content #cAprobado').attr('checked', true)
                        else
                            $('#popContent > .content #cAprobado').attr('checked', false)

                        if (eval.d.calAsistio == 1)
                            $('#popContent > .content #cAsistio').attr('checked', true);
                        else {
                            if ((eval.d.valor1 == 0) || (eval.d.valor1 == 1)) {
                                $('#popContent > .content #cAsistio').attr('checked', true);
                            }
                            else {
                                $('#popContent > .content #cAsistio').attr('checked', false);
                            }
                        }

                        showPContent('popContent', _contentProps);
                    });

            showLoader(true);
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
            }
        }
    });
}

function eliminarEmpleado(event) {
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    for (i in listaCookies) {
        var busca = listaCookies[i].search("trEmpleado");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);

    var tr = $(event.target).parent().parent();
    var _props = {
        easing: 'easeOutBack', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        transition: 'fadeIn',
        modalClose: true,
        onClose: function () {
            if (popupResult == 1) {
                showLoader2();
                var tr = $(event.target).parent().parent();
                var valorEmp = tr.find("#TxtIdEmpleado").html();
                var detalle = '{Id_Curso:' + tr.find("#TxtIDCurso").html() + ', Id_Empleado:' + valor + '}'
                $.ajax({
                    type: 'POST',
                    url: 'uiReportes/uiKardex.aspx/eliminarPostulado',
                    data: detalle,
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    success: function (msg) {
                        //alert('Curso Eliminado');
                        closePopup('popup2', 0)
                        showPopup('popup', 'Registro Eliminado', props)
                        GetData(function () {
                            showLoader(false);
                            $('#CatContWrap').fadeIn('fast');
                        });
                    },
                    error: function (request, status, error) {
                        if (request.status == 401) {
                            document.location.href = "uiPublic/uiLogin.aspx";
                        } else {
                            alert("Se ha producido el siguiente error:" + error + request.responseText);
                        }
                    }
                });
            }
        }
    };
    showPopup('popup', '¿Esta seguro de borrar este registro?', _props)
    //var c = confirm('Esta seguro de borrar este registro?');
}

function guardarCalificacion() {
    var _url = '';
    var JSONEvaluacion = '';

    var Curso = $('#popContent > .content #lblIdCurso').val();
    var empleado = $('#popContent > .content #lblIdEmpleado').val();
    var Valor1 = $('#popContent > .content #txtEval1').val();
    var Valor2 = $('#popContent > .content #txtEval2').val();
    var Valor3 = $('#popContent > .content #txtEval3').val();

    var Ev1 = $('#popContent > .content #Eval1Activa').is(':checked') ? "true" : "false";
    var Ev2 = $('#popContent > .content #Eval2Activa').is(':checked') ? "true" : "false";
    var Ev3 = $('#popContent > .content #Eval3Activa').is(':checked') ? "true" : "false";
    var Asistio = $('#popContent > .content #cAsistio').is(':checked') ? "true" : "false";
    var Aprobado = $('#popContent > .content #cAprobado').is(':checked') ? "true" : "false";

    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    for (i in listaCookies) {
        var busca = listaCookies[i].search("EstatusEva");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valorCur = micookie.substring(igual + 1);

    _url = 'uiReportes/uiKardex.aspx/actualizarMateria';
    JSONEvaluacion = '{"Id_Postulado":"0", "Id_Curso":"' + Curso + '", "Id_Usuario":"0", "Curso":"", "Id_Empleado":"' + empleado +
        '", "Asistio":"' + Asistio +
        '", "Ev1":"' + Ev1 +
        '", "Valor1":"' + Valor1 +
        '", "Ev2":"' + Ev2 +
        '", "Valor2":"' + Valor2 +
        '", "Ev3":"' + Ev3 +
        '", "Valor3":"' + Valor3 +
        '", "Aprobado":"' + Aprobado + '"}';

    $.ajax({
        type: 'POST',
        url: _url,
        data: '{postulado:' + JSONEvaluacion + '}',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (res) {
            if (res.d) {
                showPopup('popup', 'Evaluacion Guardado', props)
                closePopup('popContent', 0)
            }
            else {
                alert("La calificacion debe ser entre 5 y 10");
                $('#popContent > .content #txtEval1').val(0);
                $('#popContent > .content #txtEval2').val(0);
                $('#popContent > .content #txtEval3').val(0);
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
            }
        }
    });
}

function onKeyPress(e) {
    if (e.which == 13 || e.keyCode == 13) {
        var eval1 = $('#popContent > .content #Eval1Activa').is(':checked') ? "true" : "false";
        var eval2 = $('#popContent > .content #Eval2Activa').is(':checked') ? "true" : "false";
        var eval3 = $('#popContent > .content#Eval3Activa').is(':checked') ? "true" : "false";

        if (eval1 == "true") {
            var x = $('#popContent > .content #txtEval1').val() == '' ? ' ' : $('#popContent > .content #txtEval1').val();

            if (x >= 5 && x <= 10) {
                var suma = parseInt($('#popContent > .content #txtEval1').val());
                var resultado = suma / 1;
                $('#popContent > .content #calFinal').val(resultado);
            }
            else {
                $('#popContent > .content #txtEval1').val(0);
                alert("La calificacion debe ser entre 5 y 10");
            }
        }
        if (eval1 == "true" && eval2 == "true") {
            var x = $('#popContent > .content #txtEval1').val() == '' ? ' ' : $('#popContent > .content #txtEval1').val();
            var y = $('#popContent > .content #txtEval2').val() == '' ? ' ' : $('#popContent > .content #txtEval2').val();

            if ((x >= 5 && x <= 10) && (y >= 5 && y <= 10)) {
                var suma = parseInt($('#popContent > .content #txtEval1').val()) + parseInt($('#popContent > .content #txtEval2').val());
                var resultado = suma / 2;
                $('#popContent > .content #calFinal').val(resultado);
            }
            else {
                $('#popContent > .content #txtEval1').val(0);
                $('#popContent > .content #txtEval2').val(0);
                alert("La calificacion debe ser entre 5 y 10");
            }
        }
        if (eval1 == "true" && eval2 == "true" && eval3 == "true") {
            var x = $('#popContent > .content #txtEval1').val() == '' ? ' ' : $('#popContent > .content #txtEval1').val();
            var y = $('#popContent > .content #txtEval2').val() == '' ? ' ' : $('#popContent > .content #txtEval2').val();
            var z = $('#popContent > .content #txtEval3').val() == '' ? ' ' : $('#popContent > .content #txtEval3').val();

            if ((x >= 5 && x <= 10) && (y >= 5 && y <= 10) && (z >= 5 && z <= 10)) {
                var suma = parseInt($('#popContent > .content #txtEval1').val()) + parseInt($('#popContent > .content #txtEval2').val()) + parseInt($('#popContent > .content #txtEval3').val());
                var resultado = suma / 3;
                $('#popContent > .content #calFinal').val(resultado);
            }
            else {
                $('#popContent > .content #txtEval1').val(0);
                $('#popContent > .content #txtEval2').val(0);
                $('#popContent > .content #txtEval3').val(0);
                alert("La calificacion debe ser entre 5 y 10");
            }
        }
        try {
            if (parseInt($('#popContent > .content #calFinal').val()) >= parseInt($('#popContent > .content #lblCalAprobatoria').val()))
                $('#popContent > .content #cAprobado').attr('checked', true)
            else
                $('#popContent > .content #cAprobado').attr('checked', false)
        } catch (err) {
            alert(err);
        }
    }
}

//jdr funcion para limpiar el combo que se pase como parametro
//removeOptions(document.getElementById("cbAreaF"));
function removeOptions(selectbox) {
    var i;
    for (i = selectbox.options.length - 1 ; i >= 0 ; i--) {
        selectbox.remove(i);
    }
}

function muestraSubPro()
{
    var check = document.getElementById('ctipoSec');
    if (check.checked == true) {
        // document.getElementById('cbSubProgramasF').disabled = false;
        $("#cbProgramasF")
        var programa = $('#cbProgramasF option:selected').val();
        filtrasub(programa,0);
        //  document.getElementById('lblaSubPrograma').disabled = false;
    }
    else {
        document.getElementById('cbSubProgramasF').disabled = true;
        $("#cbSubProgramasF").val('0');
        //   document.getElementById('lblaSubPrograma').disabled = true;
    }
}

function RecuperaDato()
{

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiKardex.aspx/RecuperaDato',
        data:null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            alert(resultado.d);
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + request.responseText);
                closePopup('popup2', 0);
            }
        },
        fail: function (error) {
            alert('error');
        }
    });


}

function kardex(tipo, callback)
{
    // buscarEmpleados(1, callback);
    var _data = null;
    // var validar = validarForm();
    var _url = 'uiReportes/uiKardex.aspx/'
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")

    for (i in listaCookies) {
        var busca = listaCookies[i].search("IDEmpleado");
        if (busca > -1) { micookie = listaCookies[i] }
    }

    $("#cbAreaF")
    var area = $('#cbAreaF option:selected').val();
    $("#cbProgramasF")
    var programa = $('#cbProgramasF option:selected').val();

    $("#cbSubProgramasF")
    var subprograma = $('#cbSubProgramasF option:selected').val();

    
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);
    _url = _url + 'consultarKardex'
    _data = '{ "Id_Empleado":"' + valor + '"}';
    $.ajax({
        type: 'POST',
        url: _url,
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {

            $('#content > .main').load('uiReportes/uiKardex.aspx', function (response, status, xhr) {
                $('#CatContWrap #GridContent').append(CreateTableKardex(resultado.d));


                fillCombo('#cbAreaF', 'uiReportes/uiKardex.aspx/ListaAreas', null, area)

                filtrarArea(1);
                filtraproc(area, programa);
                filtrasub(programa, subprograma);

                //}
                //else {


                //    fillCombo('#cbAreaF', 'uiReportes/uiKardex.aspx/ListaAreas', null, area)
                //    filtrarArea(area);
                //    $('#GridContent')[0].style.visibility = "visible"
                //    //var x = document.getElementById("cbAreaF");
                //    //var option = document.createElement("option");
                //    //option.text = "Seleccionar";
                //    //option.value = 0;
                //    //x.add(option);
                //    $("#cbProgramasF")
                //    var programa = $('#cbProgramasF option:selected').val();
                //    filtraproc(area);
                //}
                if (callback && typeof (callback) === "function") {
                    callback();
                }
                //var x = $('#cbAreaF')[0];
                //    var option = document.createElement("option");
                //    option.text = "Seleccionar";
                //    option.value = 0;
                //    x.add(option);
                //$("#cbProgramasF")
                //var programa = $('#cbProgramasF option:selected').val();
                //filtrasub(programa);
                $('#kardex')[0].style.visibility = "visible";
                $('#otros')[0].style.visibility = "visible";
                $('#GridContent')[0].style.visibility = "visible"

            });
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
            }
        }
    });



}

function BuscarOtros(callback)
{
    //filtraproc(area, area);
    //if (callback && typeof (callback) === "function") {
    //    callback();
    //}
    $('#busqueda')[0].style.visibility = "visible"


    $('#kardex')[0].style.visibility = "visible";
    $('#otros')[0].style.visibility = "visible";

}

function mensaje() {
    showPopup('popup', 'La persona seleccionada no tiene cursos asignados.<br /> <b>Agregar cursos a esta persona antes de generar el reporte</b>', props)
}

//Create table personalizado kardex
function CreateTableKardex(tableObj) {
    var table = $('<table></table>').attr(tableObj.tableHtmlAttrs);
    var th = $('<thead><tr></tr></thead>').attr(tableObj.thHtmlAttrs);
    for (var i = 0; i < tableObj._rowHeaders.length; i++) {
        var thcell = $('<th></th>').attr(tableObj._rowHeaders[i].htmlAttrs);
        thcell.append('<span>' + tableObj._rowHeaders[i]._value + ' </span>');
        th.append(thcell);
    }
    table.append(th);

    for (var j = 0; j < tableObj._rowValues.length; j++) {
        var actRow = tableObj._rowValues[j];
        var tr = $('<tr></tr>');
        for (var a = 0; a < actRow._ListRowValues.length; a++) {
            if (actRow._ListRowValues[a].tdHtmlAttrs == null)
                var td = $('<td></td>');
            else
                var td = $('<td></td>').attr(actRow._ListRowValues[a].tdHtmlAttrs);
            if (actRow._ListRowValues[a].type === 'img') {
                var res = GetCols(actRow._ListRowValues[a]._events);
                var tdcell = $('<img></img>').attr('src', actRow._ListRowValues[a]._value).attr(actRow._ListRowValues[a].htmlAttrs);
                $(res).each(function (indx, val) {
                    if (val === 'onclick') {
                        $(tdcell).bind('click', window[actRow._ListRowValues[a]._events[val]]);
                    }
                });
                td.append(tdcell);

            } else if (actRow._ListRowValues[a].type === 'txt') {
                var tdcell = $('<span></span>').text(actRow._ListRowValues[a]._value).attr(actRow._ListRowValues[a].htmlAttrs);
                td.append(tdcell);
            } else if (actRow._ListRowValues[a].type === 'check') {
                var ID = actRow._ListRowValues[a]._value
                var tdcell = '<td><input type="checkbox" name="chkbox1" id=' + ID + '></td>'
                td.append(tdcell);
            }
            else if (actRow._ListRowValues[a].type === 'link') {
                var ID = actRow._ListRowValues[a]._value
                var tdcell = $('<a href="' + actRow._ListRowValues[a]._value + '"target="_blank">Ver</a>');
                td.append(tdcell);
            }


            tr.append(td);
            table.append(tr);
        }
    }

    $(table).children('tbody').children('tr:odd').addClass('gridTrUnselected');
    sort($(table));
    //return paginate($(table), 10);
    return table;
}