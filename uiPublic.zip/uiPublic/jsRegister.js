﻿function initPage() {
    var urlUnescaped = unescape(location.href);
    var usrParam = getURLParameter('usr', urlUnescaped);

    if (usrParam == 'null') {
        location.href = "uiLogin.aspx";
    }
    else {
        $('#TxtUsuario').val(usrParam.toUpperCase());
    }
}


function getURLParameter(name, UrlString) {
    return decodeURI(
        (RegExp(name + '=' + '(.+?)(&|$)').exec(UrlString) || [, null])[1]
    );
}



function guardarUsuario() {
  //  debugger;
    var _props = {
        easing: 'easeOutBack', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        transition: 'fadeIn',
        modalClose: false,
        onClose: function () {
            if (popupResult == true) {
               // debugger;
                var _url = 'uiRegister.aspx/guardarUsuario';
                var JSONUsuario = '';


                var idUsuario = $('#lblIDUsuario').text() == '' ? '0' : $('#lblIDUsuario').text();
                var usuario = $('#TxtUsuario').val() == '' ? ' ' : $('#TxtUsuario').val();
                var nomina = $('#TxtNomina').val() == '' ? ' ' : $('#TxtNomina').val();
                var correo = $('#TxtCorreo').val() == '' ? ' ' : $('#TxtCorreo').val();

                //Cambio antonio: se cambi al control (lblData) por un cbDominio
                var Dominio = $('#cbDominio option:selected').text();

                if (correo == " ") {
                    //$('#lblData').html("")
                    Dominio='';
                }


                var JSONUsuario = '{"Id_Usuario":"' + idUsuario + '", "mail":"' + correo + Dominio + '", "nomina":"' + nomina + '", "usuario":"' + usuario + '"}';

                $.ajax({
                    type: 'POST',
                    url: _url,
                    data: '{Usuario:' + JSONUsuario + '}',

                    //Se agregan las propiedades context y sender para especificar la validacion del formulario antes de hacer el request
                    context: document.body,
                    sender: 'CatContWrap',
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    success: function (msg) {
                        //debugger;
                        if (msg.d == '1') {
                            var pagDefa = "uiLogin.aspx";
                            alert('Se ha guardado la informacion satisfactoriamente');
                            location.href = pagDefa;
                        }
                        else {
                            if (msg.d != '') {
                                alert('El numero de nomina ya esta asignado a : ' + msg.d);
                            }
                            else {
                                if (msg.d == '') {
                                    alert('El registro del empleado no existe por favor contacte al administrador');
                                    location.href = "uiLogin.aspx";
                                }
                            }
                        }
                    },
                    error: function (request, status, error) {
                        if (request.status == 401) {
                            document.location.href = "uiPublic/uiLogin.aspx";
                        } else {
                            alert("Se ha producido el siguiente error:" + error);
                        }
                    }
                });
            }
        }
    };
    showPopup('popup', '¿Esta seguro de que usted es ' + $('#nombreNom').text() + '?', _props)
 
}

function soloLetras(e) {
    key = e.keyCode || e.which;
    tecla = String.fromCharCode(key).toLowerCase();
    letras = " áéíóúabcdefghijklmnñopqrstuvwxyz.123456789";
    especiales = "!#$%&/()=?¡'¿@{}¨*[]_-";

    tecla_especial = false
    for (var i in especiales) {
        if (key == especiales[i]) {
            tecla_especial = true;
            break;
        }
    }

    if (letras.indexOf(tecla) == -1 && !tecla_especial) {
        return false;
    }
}

function ValidaNomina(e) {
    var _url = 'uiRegister.aspx/consultaNomina'
    key = e.keyCode || e.which;
    var data = $('#TxtNomina').val() == '' ? ' ' : $('#TxtNomina').val();
    var valor = String.fromCharCode(key).toLowerCase();
    var nomina = data + valor;
    $('#nombreNom').html('');
    $.ajax({
        type: 'POST',
        url: _url,
        data: '{ numNomina:"' + nomina + '"}',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            $('#nombreNom').html(msg.d);
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error + request.responseText);
            }
        }
    });
}