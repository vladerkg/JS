﻿/// <reference path="../JQuery/jquery-1.10.4/jquery-1.10.2.js" />
function GetData(callback) {
    //buscarLista(1, callback);
    loadForm();
}

//function buscarLista(tipoBusqueda, callback) {
//    var _data = null;
//    var validar = validarForm();
//    var _url = 'uiReportes/uiReporteAvance.aspx/'
//    var result = "'";
//    if (tipoBusqueda == 1) {//Todos  
//        _url = _url + 'consultarListadoEval'
//    }
//    $.ajax({
//        type: 'POST',
//        url: _url,
//        data: _data,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (resultado) {
//            $('#content > .main').load('uiReportes/uiReporteAvance.aspx', function (response, status, xhr) {
//                iniciaCombos();
//                BindDataPickers();
//                if (callback && typeof (callback) === "function") {
//                    callback();
//                }
//            });
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
//            }
//        }
//    });
//}

//function filtrarArea(_valor) {
//    //CSR
//    var Area = $('#cbAreaF option:selected').html()
//    if (Area != '' || Area != 'Seleccionar' || $('#cbAreaF').val() != '' || $('#cbAreaF').val() != '0') {
//        $('#vlAreaF').css('visibility', 'hidden');
//    }

//    var _data = '{"Id_Area":"' + _valor + '", "Id_Localidad":"0"}';
//    fillCombo('#cbProgramaF', 'uiReportes/uiReporteAvance.aspx/Areas_consultarAreaXProgramas', _data, 0);
//}

////CSR
//function cambioPrograma() {
//    var Programa = $('#cbProgramaF option:selected').html()
//    if (Programa != '' || Programa != 'Seleccionar' || $('#cbProgramaF').val() != '' || $('#cbProgramaF').val() != '0') {
//        $('#vlProgramaF').css('visibility', 'hidden');
//    }
//}

////CSR
//function cambioLocalidad() {
//    var Localidad = $('#cbLocalidadF option:selected').html()
//    if (Localidad != '' || Localidad != 'Seleccionar' || $('#cbLocalidadF').val() != '' || $('#cbLocalidadF').val() != '0') {
//        $('#vlLocalidad').css('visibility', 'hidden');
//    }
//}

//function Reporte() {
//    //CSR
//    // debugger;
//    var validacion = ValidarFiltrosObligatorios();
//    if (!validacion) {
//        return false;
//    }

//    var _data = null;
//    var validar = validarForm();
//    var _url = 'uiReportes/uiReporteAvance.aspx/exportar'
//    var result = "";
//    var Id_Programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();
//    var Programa = $('#cbProgramaF option:selected').text();

//    var Id_Localidad = $('#cbLocalidadF').val() == '' ? ' ' : $('#cbLocalidadF').val();
//    var Localidad = $('#cbLocalidadF option:selected').text();

//    var Periodo = $('#cbPeriodo').val() == '' ? ' ' : $('#cbPeriodo').val();
//    var Fecha_Inicial = $('#TxtFechaIniF').val() == '' ? ' ' : $('#TxtFechaIniF').val();
//    var Fecha_Final = $('#TxtFechaFinF').val() == '' ? ' ' : $('#TxtFechaFinF').val();

//    _data = '{ "Id_Programa": "' + Id_Programa +
//                '", "Id_Localidad": "' + Id_Localidad +
//                '", "Programa": "' + Programa +
//                '", "Localidad": "' + Localidad +
//                '", "Periodo": "' + Periodo +
//                '", "Fecha_Inicial": "' + Fecha_Inicial +
//                '", "Fecha_Final": "' + Fecha_Final + '" }';


//    showLoader2();
//    $.ajax({
//        type: 'POST',
//        url: _url,
//        data: _data,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (resultado) {
//            $('#content > .main').load('uiReportes/uiReporteAvance.aspx', function (response, status, xhr) {
//                //debugger;
//                iniciaCombos();
//                var ruta = resultado;
//                if (ruta.d != "") {
//                    window.open("uiComun/AuxTableToXls.aspx");
//                }
//                else {
//                    alert("No existe información con los parámetros seleccionados, verifique.");
//                }
//            });
//            closePopup('popup2', 0);
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error: " + error + " " + request.responseText);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}

//function iniciaCombos() {
//    fillCombo('#cbAreaF', 'uiReportes/uiReporteAvance.aspx/ListaAreas', null, 0);
//    fillCombo('#cbLocalidadF', 'uiReportes/uiReporteAvance.aspx/consultaComboLocalidades', null, 0);
//    filtrarArea(1);
//}

//function BindDataPickers() {
//    loadCSS('Scripts/datepicker/css/datepicker.css');
//    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {
//        //                    $('.TxtFechaIniF').datepicker({ format: 'dd/mm/yyyy' });
//        //                    $('.TxtFechaFinF').datepicker({ format: 'dd/mm/yyyy' });
//        var nowTemp = new Date();
//        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

//        var checkin = $('#TxtFechaIniF').datepicker({
//            onRender: function (date) {
//                return '';
//            },
//            format: 'yyyy/mm/dd'
//        }).on('changeDate', function (ev) {

//            var newDate = new Date(ev.date)
//            newDate.setDate(newDate.getDate());
//            checkout.setValue(newDate);

//            checkin.hide();
//            $('#TxtFechaFinF')[0].focus();
//        }).data('datepicker');
//        var checkout = $('#TxtFechaFinF').datepicker({
//            onRender: function (date) {
//                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
//            },
//            format: 'yyyy/mm/dd'
//        }).on('changeDate', function (ev) {
//            checkout.hide();
//        }).data('datepicker');

//        if ($('#TxtFechaIniF').val() != '') {
//            checkin.setValue($('#TxtFechaIniF').val());
//        }

//        if ($('#TxtFechaFinF').val() != '') {
//            checkout.setValue($('#TxtFechaFinF').val());
//        }
//    });
//}

////CSR
//function ValidarFiltrosObligatorios() {
//    var respuesta = true;

//    var Area = $('#cbAreaF option:selected').html()
//    if (Area == '' || Area == 'Seleccionar' || $('#cbAreaF').val() == '' || $('#cbAreaF').val() == '0') {
//        $('#vlAreaF').css('visibility', 'visible');
//        respuesta = false;
//    }

//    var Programa = $('#cbProgramaF option:selected').html()
//    if (Programa == '' || Programa == 'Seleccionar' || $('#cbProgramaF').val() == '' || $('#cbProgramaF').val() == '0') {
//        $('#vlProgramaF').css('visibility', 'visible');
//        respuesta = false;
//    }

//    //var Localidad = $('#cbLocalidadF option:selected').html()
//    //if (Localidad == '' || Localidad == 'Seleccionar' || $('#cbLocalidadF').val() == '' || $('#cbLocalidadF').val() == '0') {
//    //    $('#vlLocalidad').css('visibility', 'visible');
//    //    respuesta = false;
//    //}

//    return respuesta
//}



/****************************************************************************************************************************************
* Cambios para nuevo reporte (solo se ocual el funcionamiento de la pantalla anterior y reporte)
* Fecha de modificación: 03-11-2017
* Autor: José Miguel Cervantes
*****************************************************************************************************************************************/


function loadForm() {
    $('#content > .main').load('uiReportes/uiReporteAvance.aspx', function (response, status, xhr) {
        $(document).ready(function () {

            showLoader2();
            CargarControlJerarquiaEmpleados();
            CargarControlSeleccionCurso();
            CargarControlSeleccionLocalidad();
            CargarControlPuestosGrados();
            BindDatepickerFormat();



            ///CargarComboAreaAprendizaje();
            ///cargarCatalogoWorkDay('cboLocalidad', 1, 0, 0, 0, 0, 0);
            /// cargarCatalogoWorkDay('cboDireccion', 2, 0, 0, 0, 0, 0);
            //ObtnerGradoPuesto();
            /// ObtnerGrado();
            /// ObtnerPuesto();
            CargarComboTipoEmpleado();
            OcultarControlesInicales();

            //Oculta la selección de numeros de nomina
            $("#tblNominasCarga").css("display", "none");
            //$("#AreaNumNomina").css("display", "none");
            //$("#mensajeNomina").html("");


            $("#btnLimpiarCampos").on('click', function (event) {
                event.preventDefault();
                LimpiarCampos();
                return false;
            });

            $("#btnGenerarReporte").on('click', function (event) {
                event.preventDefault();
                setNombresAsignados();
                GenerarReporte();
            });

            $("#cboAreaAprendizaje").on('change', function () {
                CargarComboPrograma();
            });

            $("#cboPrograma").on('change', function () {
                cargarComboSubPrograma();
            });

            $("#cboSubPrograma").on('change', function () {
                cargarComboCursos();
            });

            $("#cboDireccion").on('change', function () {
                var idDireccion = $("#cboDireccion").val();

                cargarCatalogoWorkDay('cboGerencia', 3, 0, idDireccion, 0, 0, 0);
            });

            $("#cboGerencia").on('change', function () {
                var idDireccion = $("#cboDireccion").val();
                var idGerencia = $("#cboGerencia").val();
                cargarCatalogoWorkDay('cboJefatura', 4, 0, idDireccion, idGerencia, 0, 0);
            });


            jQuery('#log').ajaxStop(function () {
                closePopup('popup2', 0);

            });

            jQuery("#log").ajaxComplete(function () {
                //$(this).html("");
                $("#popup2").find("div:first").html("");
            });


            $("#chkBuscarNominas").on('change', function () {
                $("#AreaNumNomina").val("");

                if ($('#chkBuscarNominas').prop('checked')) {

                    $("#tblNominasCarga").css("display", "block");

                    //$("#AreaNumNomina").css("display", "block");
                    //$("#btnCargarNominas").css({ 'display': 'block' });
                    //$("#mensajeNomina").html("*Ingrese los números de nómina separados por comas <b>(,)</b> <b>Ejemplo: 111111,222222,333333,444444</b>");
                }
                else {
                    //$("#AreaNumNomina").css("display", "none");
                    //$("#btnCargarNominas").css({ 'display': 'none' });
                    //$("#mensajeNomina").html("");

                    $("#tblNominasCarga").css("display", "none");
                }
            });


            $("#btnCargarNominas").on('click', function () {
                CargarNominas();
                return false;
            });


            $("#cboLocalidadCurso").on('change', function () {
                $("#hiddenDescLocalidadCurso").val($(this).find('option:selected').text());
            });


            $("#btnReporteHistorico").on('click', function (event) {
                event.preventDefault();
                setNombresAsignados();
                GenerarReporteHistorico();
            });

            //CargarControlJerarquiaEmpleados();
            NoAdmin();
            CargarLocalidadesCursos();
        });
    });
}



function CargarControlSeleccionLocalidad() {

    //if (admin == true) {
    $('#div-uiControl_Loc_Dir_Ger_Jef').load('uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx');

    //}
    //else {
    //    $('#div-uiControl_Loc_Dir_Ger_Jef').load('uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx?Ident=1');
    //}
}



function NoAdmin() {

    //Oculta si no es admin
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";");
    var micookie = null;

    for (i in listaCookies) {
        var busca = listaCookies[i].search("Perfil");
        if (busca > -1) {
            micookie = listaCookies[i];
            break;
        }
    }

    var igual = micookie.indexOf("=");

    var valor = micookie.split('=');
    if (valor.length > 1) {

        if (valor[1] != 1) {
            //Quita los divs 
            $("#div-uiControl_Puesto_Grado").css("display", "none");
            $("#tableFechasCursos").css("display", "none");
            $("#div-uiControl_Loc_Dir_Ger_Jef").css("display", "none");
            $("#div-uiControl_Puesto_Grado").css("display", "none");
            $("#tableReporteAvance").css("display", "none");
            $("#div-LoadNominas").css("display", "none");

            //CargarControlSeleccionLocalidad(false);
            //$("#select_Direccion").css("display", "none");
            //$("#table-uiControl_Loc_Dir_Ger_Jef").css("display", "none");
            //$("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Direccion").css("display", "none");
            //$("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Gerencia").css("display", "none");
            //$("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Jefatura").css("display", "none");
        }
        else {
            //CargarControlSeleccionLocalidad(true);
        }

    }
}


function OcultarControlesInicales() {
    $("#div-contentNominas").css({ 'display': 'none' });
    CargarLocalidades();
}

function LimpiarCampos() {

    $("#CatContWrap #select_AreaAprendizaje").val("0");
    $("#CatContWrap #select_Programa option").remove();
    $("#CatContWrap #select_SubPrograma option").remove();
    $("#CatContWrap #select_Curso option").remove();

    $("#CatContWrap #select_Localidad").val("0");
    $("#CatContWrap #select_Direccion").val("0");
    $("#CatContWrap #select_Gerencia option").remove();
    $("#CatContWrap #select_Jefatura option").remove();

    $('#CatContWrap #selectPuestos option').prop('selected', false);
    $('#CatContWrap #selectGrados option').prop('selected', false);

    $("#CatContWrap #txtFechaInicial").val("");
    $("#CatContWrap #txtFechaFinal").val("");

    $("#CatContWrap #cboTipoEmpleado").val(0);
    $("#CatContWrap #cboEstatus").val("");
    $("#CatContWrap #cboDireccion").val(0);
    $("#CatContWrap #rbtnGrafica").removeAttr("checked");
    $("#CatContWrap #rbtnListado").attr("checked", true);
    $("#CatContWrap #hiddenIdPuesto").val("");
    $("#CatContWrap #AreaNumNomina").val("");

}




function BindDatepickerFormat() {

    loadCSS('Scripts/datepicker/css/datepicker.css');
    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {

        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#txtFechaInicial').datepicker({
            onRender: function (date) {
                return '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {

            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate());
            checkout.setValue(newDate);

            checkin.hide();
            $('#txtFechaFinal')[0].focus();
        }).data('datepicker');
        var checkout = $('#txtFechaFinal').datepicker({
            onRender: function (date) {
                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');

        if ($('#txtFechaInicial').val() != '') {
            checkin.setValue($('#txtFechaInicial').val());
        }

        if ($('#txtFechaFinal').val() != '') {
            checkout.setValue($('#txtFechaFinal').val());
        }



    });
}


//function CargarComboAreaAprendizaje() {


//    $("#CatContWrap #cboPrograma option").remove();
//    $("#CatContWrap #cboSubPrograma option").remove();
//    $("#CatContWrap #cboCurso option").remove();

//    var ctrCombo = $("#CatContWrap #cboAreaAprendizaje");
//    //var idArea= ctrCombo.val();

//    //if(idArea == "" || idArea == null || idArea == undefined || isNaN(idArea))
//    //{
//    //    idArea = 0;
//    //}

//    //if (idArea == 0) {
//    //    alert("Seleccione Área de aprendizaje");
//    //    return;
//    //}
//    //else {

//    $.ajax({
//        type: 'POST',
//        url: 'uiReportes/uiReporteAvance.aspx/ListaAreas',
//        data: '{"Id_Area":"0", "Id_Localidad":"0"}',
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (msg) {
//            if (msg != null) {
//                // debugger;
//                //Carga el combo
//                jsonResult = msg.d;
//                var option = '<option value="0">Seleccione</option>';
//                if (jsonResult != null) {
//                    for (var i = 0; i < jsonResult.length; i++) {
//                        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
//                    }
//                }
//                ctrCombo.find('option').remove().end().append(option);
//                option = null;
//            }
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//    //}
//}


//function CargarComboPrograma() {

//    $("#CatContWrap #cboPrograma option").remove();
//    $("#CatContWrap #cboSubPrograma option").remove();
//    $("#CatContWrap #cboCurso option").remove();

//    var ctrCombo = $("#CatContWrap #cboPrograma");
//    var idArea = $("#CatContWrap #cboAreaAprendizaje").val();

//    if (idArea == "" || idArea == null || idArea == undefined || isNaN(idArea)) {
//        idArea = 0;
//    }

//    if (idArea == 0) {
//        alert("Seleccione Área de aprendizaje");
//        return;
//    }
//    else {

//        if (idArea > 0) {
//            $.ajax({
//                type: 'POST',
//                url: 'uiReportes/uiReporteAvance.aspx/consultarAreaXProgramas',
//                data: '{"Id_Area":"' + idArea + '", "Id_Localidad":"0"}',
//                contentType: 'application/json; charset=utf-8',
//                dataType: 'json',
//                success: function (msg) {
//                    if (msg != null) {
//                        //debugger;
//                        //Carga el combo
//                        jsonResult = msg.d;
//                        var option = '<option value="0">Seleccione</option>';
//                        if (jsonResult != null) {
//                            for (var i = 0; i < jsonResult.length; i++) {
//                                option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
//                            }
//                        }
//                        ctrCombo.find('option').remove().end().append(option);
//                        option = null;
//                    }
//                },
//                error: function (request, status, error) {
//                    if (request.status == 401) {
//                        document.location.href = "uiPublic/uiLogin.aspx";
//                    } else {
//                        alert("Se ha producido el siguiente error:" + error);
//                        closePopup('popup2', 0);
//                    }
//                }
//            });
//        }
//    }

//}

//function cargarComboSubPrograma() {


//    $("#CatContWrap #cboSubPrograma option").remove();
//    $("#CatContWrap #cboCurso option").remove();

//    var ctrCombo = $("#CatContWrap #cboSubPrograma");
//    var idArea = $("#CatContWrap #cboAreaAprendizaje").val();
//    var idPrograma = $("#CatContWrap #cboPrograma").val();

//    if (idArea == "" || idArea == null || idArea == undefined || isNaN(idArea)) {
//        idArea = 0;
//    }
//    else if (idPrograma == "" || idPrograma == null || idPrograma == undefined || isNaN(idPrograma)) {
//        idPrograma = 0;

//    }

//    if (idArea == 0) {
//        alert("Seleccione Área de aprendizaje");
//        return;
//    }
//    else if (idPrograma == 0) {
//        alert("Seleccione programa");
//        return;
//    }
//    else {

//        if (idPrograma > 0) {
//            $.ajax({
//                type: 'POST',
//                url: 'uiReportes/uiReporteAvance.aspx/ConsultarSubProgramas',
//                data: '{"idPrograma":"' + idPrograma + '"}',
//                contentType: 'application/json; charset=utf-8',
//                dataType: 'json',
//                success: function (msg) {
//                    if (msg != null) {
//                        //debugger;
//                        //Carga el combo
//                        jsonResult = msg.d;
//                        var option = '';
//                        if (jsonResult != null) {
//                            for (var i = 0; i < jsonResult.length; i++) {
//                                option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
//                            }
//                        }
//                        ctrCombo.find('option').remove().end().append(option);
//                        option = null;
//                    }
//                },
//                error: function (request, status, error) {
//                    if (request.status == 401) {
//                        document.location.href = "uiPublic/uiLogin.aspx";
//                    } else {
//                        alert("Se ha producido el siguiente error:" + error);
//                        closePopup('popup2', 0);
//                    }
//                }
//            });
//        }
//    }
//}


//function cargarComboCursos() {

//    var ctrCombo = $("#CatContWrap #cboCurso");
//    var idSubPrograma = $("#CatContWrap #cboSubPrograma").val();
//    $("#CatContWrap #cboCurso option").remove();

//    if (idSubPrograma == "" || idSubPrograma == undefined || idSubPrograma == null || isNaN(idSubPrograma)) {
//        idSubPrograma = 0;
//    }

//    if (idSubPrograma == 0) {
//        alert("Seleccione Subprograma");
//        return;
//    }
//    else {

//        if (idSubPrograma > 0) {

//            $.ajax({
//                type: 'POST',
//                url: 'uiReportes/uiReporteAvance.aspx/obtenerCursos',
//                data: '{"idSubPrograma":"' + idSubPrograma + '"}',
//                contentType: 'application/json; charset=utf-8',
//                dataType: 'json',
//                success: function (msg) {
//                    if (msg != null) {
//                        //debugger;
//                        //Carga el combo
//                        jsonResult = msg.d;
//                        var option = '';
//                        if (jsonResult != null) {
//                            for (var i = 0; i < jsonResult.length; i++) {
//                                option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
//                            }
//                        }
//                        ctrCombo.find('option').remove().end().append(option);
//                        option = null;
//                    }
//                },
//                error: function (request, status, error) {
//                    if (request.status == 401) {
//                        document.location.href = "uiPublic/uiLogin.aspx";
//                    } else {
//                        alert("Se ha producido el siguiente error:" + error);
//                        closePopup('popup2', 0);
//                    }
//                }
//            });


//        }
//    }

//}

/*
* Obtiene los catalogos de los campos Localidad, Direccion, Gerencia y Jefatura
*
*/
//function cargarCatalogoWorkDay(nombreCombo, catalogo, Id_Localidad, Id_Direccion, Id_Gerencia, Id_Jefatura, Id_Proceso) {
//    var ctrCombo = $("#" + nombreCombo);
//    var _data = '{"cat":"' + catalogo + '","Id_Localidad":"' + Id_Localidad + '","Id_Direccion":"' + Id_Direccion + '","Id_Gerencia":"' + Id_Gerencia + '","Id_Jefatura":"' + Id_Jefatura + '","Id_Proceso":"' + Id_Proceso + '"}';
//    $.ajax({
//        type: 'POST',
//        url: 'uiReportes/uiReporteAvance.aspx/ObtenerCatalogo',
//        data: _data,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (msg) {
//            if (msg != null) {
//                setTimeout(function () {

//                    //Carga el combo
//                    jsonResult = $.parseJSON(msg.d);
//                    var option = '<option value="0">Seleccione</option>';
//                    for (var i = 0; i < jsonResult.length; i++) {
//                        option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
//                    }
//                    ctrCombo.find('option').remove().end().append(option);
//                    option = null;
//                }, 0);
//            }
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error);
//                closePopup('popup2', 0);
//            }
//        }
//    });

//}


//function ObtnerPuesto() {
//    $.ajax({
//        type: 'POST',
//        url: 'uiReportes/uiReporteAvance.aspx/ObtenerPuestos',
//        data: null,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (msg) {
//            if (msg != null) {

//                var ctrCombo = $("#cboPuesto");

//                jsonResult = $.parseJSON(msg.d);

//                //Carga el combo

//                var option = ''; //'<option value="-1">Seleccione</option>';
//                for (var i = 0; i < jsonResult.length; i++) {
//                    option += '<option value="' + jsonResult[i].Puesto + '">' + jsonResult[i].Puesto + '</option>';
//                }

//                ctrCombo.find('option').remove().end().append(option);
//                option = null;



//            }
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}


//function ObtnerGrado() {
//    $.ajax({
//        type: 'POST',
//        url: 'uiReportes/uiReporteAvance.aspx/ObtenerGrados',
//        data: null,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (msg) {
//            if (msg != null) {

//                var ctrCombo = $("#cboGrado");

//                jsonResult = $.parseJSON(msg.d);

//                //Carga el combo

//                var option = ''; //'<option value="-1">Seleccione</option>';
//                for (var i = 0; i < jsonResult.length; i++) {
//                    option += '<option value="' + jsonResult[i].Grado + '">' + jsonResult[i].Grado + '</option>';
//                }

//                ctrCombo.find('option').remove().end().append(option);
//                option = null;



//            }
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}






//function ObtnerGradoPuesto() {


//    $.ajax({
//        type: 'POST',
//        url: 'uiReportes/uiReporteAvance.aspx/ObtenerPuestoGrado',
//        data: null,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (msg) {
//            if (msg != null) {

//                var ctrCombo = $("#cboGradoPuesto");

//                jsonResult = $.parseJSON(msg.d);

//                //Carga el combo

//                var option = '<option value="0">Seleccione</option>';
//                for (var i = 0; i < jsonResult.length; i++) {
//                    option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
//                }

//                ctrCombo.find('option').remove().end().append(option);
//                option = null;



//            }
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}


function CargarLocalidadesCursos() {


    $("#cboLocalidadCurso option").remove();
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteAvance.aspx/ConsultarLocalidadesCursos',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {


            if (msg != null) {


                var ctrCombo = $("#cboLocalidadCurso");
                jsonResult = $.parseJSON(msg.d);

                //Carga el combo
                var option = '<option value="-1">Seleccione</option>';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].Id_Localidad + '">' + jsonResult[i].Descripcion + '</option>';
                }

                ctrCombo.find('option').remove().end().append(option);
                option = null;
            }

        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}

function CargarComboTipoEmpleado() {

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteAvance.aspx/ObtenerTipoEmpleado',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg != null) {


                var ctrCombo = $("#cboTipoEmpleado");
                jsonResult = msg.d;

                //Carga el combo
                var option = '';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].ID + '">' + jsonResult[i].Value + '</option>';
                }

                ctrCombo.find('option').remove().end().append(option);
                option = null;
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


function GenerarReporteHistorico() {

    debugger;
    if (!$('#chkBuscarNominas').prop('checked')) {
        NumNominas = "";
    }

    var _formArray = $("#frmReporte").serializeArray();

    var Puesto = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectPuestos");
    var indice = Puesto[0];
    var TotalRegistros = indice.childElementCount;
    var strPuestos = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strPuestos += ("'" + indice[i].value + "',");
        }
    }

    var Grado = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectGrados");
    indice = Grado[0];
    TotalRegistros = indice.childElementCount;
    var strGrado = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strGrado += ("'" + indice[i].value + "',");
        }
    }

    var myJson = objectifyForm(_formArray);

    myJson["Puestos"] = strPuestos;
    myJson["Grados"] = strGrado;

    var strJson = JSON.stringify(myJson);

    showLoader2();

    debugger;

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteAvance.aspx/ExportarReporteAvanceProgramaHistorico',
        data: '{ frm : ' + strJson + ' }',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {

            if (msg != null && msg.d != "") {
                window.open("uiComun/AuxTableToXls.aspx");
            }
            else {
                showPopup('popup', "No se encotraron resultados ", null);
                closePopup('popup2', 0);
            }
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {

            closePopup('popup2', 0);
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}



function GenerarReporte() {

    if (!validarCampos()) {
        return false;
    }

    if (!$('#chkBuscarNominas').prop('checked')) {
        NumNominas = "";
    }

    var _formArray = $("#frmReporte").serializeArray();

    var Puesto = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectPuestos");
    var indice = Puesto[0];
    var TotalRegistros = indice.childElementCount;
    var strPuestos = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strPuestos += ("'" + indice[i].value + "',");
        }
    }

    var Grado = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectGrados");
    indice = Grado[0];
    TotalRegistros = indice.childElementCount;
    var strGrado = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strGrado += ("'" + indice[i].value + "',");
        }
    }

    var myJson = objectifyForm(_formArray);

    myJson["Puestos"] = strPuestos;
    myJson["Grados"] = strGrado;

    var strJson = JSON.stringify(myJson);

    showLoader2();
    debugger;


    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteAvance.aspx/ExportarReporteAvancePrograma',
        data: '{ frm : ' + strJson + ' }',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {

            if (msg != null && msg.d != "") {
                window.open("uiComun/AuxTableToXls.aspx");
            }
            else {
                showPopup('popup', "No se encotraron resultados ", null);
                closePopup('popup2', 0);
            }
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {

            closePopup('popup2', 0);
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


function setNombresAsignados() {
    //Test
    $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val("");

    $("#divControl_JerarquiaEmpleado #div-Grados select").each(function () {


        //Obtiene el id del control select
        var idSelect = $(this).attr('id');
        //Busca el valor seleccionado de id del select dinamico de empleado asignado
        var valId = $("#divControl_JerarquiaEmpleado #" + idSelect).val();

        if (valId > 0) {

            var textAsignados = $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val();
            textAsignados = textAsignados + $("#divControl_JerarquiaEmpleado #" + idSelect + " option:selected").html();
            $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val(textAsignados + "~");

            //alert($(this).attr('id'));

        }
    });
}

//function GenerarReporte() {


//    if (!validarCampos()) {
//        return false;
//    }

//    var Id_Area = $("#CatContWrap #cboAreaAprendizaje").val();
//    var Id_Programa = $("#CatContWrap #cboPrograma").val();
//    var Id_SubPrograma = $("#CatContWrap #cboSubPrograma").val();
//    var Id_Materia = $("#CatContWrap #cboCurso").val();
//    var Fecha_Inicio = $("#CatContWrap #txtFechaInicial").val().trim();
//    var Fecha_Fin = $("#CatContWrap #txtFechaFinal").val().trim();
//    var Id_Localidad = $("#CatContWrap #cboLocalidad").val();
//    var Id_Direccion = $("#CatContWrap #cboDireccion").val();
//    var Id_Gerencia = $("#CatContWrap #cboGerencia").val();
//    var Id_Jefatura = $("#CatContWrap #cboJefatura").val();
//    var NumNominas = $("#AreaNumNomina").val();


//    if (!$('#chkBuscarNominas').prop('checked')) {
//        NumNominas = "";
//    }


//    var Id_TipoEmp = $("#CatContWrap #cboTipoEmpleado").val();
//    var Estatus = $("#CatContWrap #cboEstatus").val();

//    showLoader2();

//    //Valida que no venga vacio valor de algun combo
//    if (Id_Area == null || Id_Area == undefined || Id_Area == "" || isNaN(Id_Area)) {
//        Id_Area = 0;
//    }

//    if (Id_Programa == null || Id_Programa == undefined || Id_Programa == "" || isNaN(Id_Programa)) {
//        Id_Programa = 0;
//    }

//    if (Id_SubPrograma == null || Id_SubPrograma == undefined || Id_SubPrograma == "" || isNaN(Id_SubPrograma)) {
//        Id_SubPrograma = 0;
//    }

//    if (Id_Materia == null || Id_Materia == undefined || Id_Materia == "" || isNaN(Id_Materia)) {
//        Id_Materia = 0;
//    }

//    if (Id_Localidad == null || Id_Localidad == undefined || Id_Localidad == "" || isNaN(Id_Localidad)) {
//        Id_Localidad = 0;
//    }

//    if (Id_Direccion == null || Id_Direccion == undefined || Id_Direccion == "" || isNaN(Id_Direccion)) {
//        Id_Direccion = 0;
//    }

//    if (Id_Gerencia == null || Id_Gerencia == undefined || Id_Gerencia == "" || isNaN(Id_Gerencia)) {
//        Id_Gerencia = 0;
//    }

//    if (Id_Jefatura == null || Id_Jefatura == undefined || Id_Jefatura == "" || isNaN(Id_Jefatura)) {
//        Id_Jefatura = 0;
//    }


//    if (Id_TipoEmp == null || Id_TipoEmp == undefined || Id_TipoEmp == "" || isNaN(Id_TipoEmp)) {
//        Id_TipoEmp = 0;
//    }

//    //if (Estatus == null || Estatus == undefined || Estatus == "" || isNaN(Estatus)) {
//    //    Estatus = 0;
//    //}



//    var Puesto = $("#cboPuesto");
//    var indice = Puesto[0];
//    var TotalRegistros = indice.childElementCount;
//    var strPuestos = '';

//    for (var i = 0; i < TotalRegistros; i++) {

//        if (indice[i].selected == true) {
//            strPuestos += ("'" + indice[i].value + "',");
//        }
//    }

//    var Grado = $("#cboGrado");
//    indice = Grado[0];
//    TotalRegistros = indice.childElementCount;
//    var strGrado = '';

//    for (var i = 0; i < TotalRegistros; i++) {

//        if (indice[i].selected == true) {
//            strGrado += ("'" + indice[i].value + "',");
//        }
//    }

//    var NominaPadre = $("#divControl_JerarquiaEmpleado #hiddenNominaSelected").val();

//    var _data = '{"Id_Area":"' + Id_Area +
//        '","Id_Programa":"' + Id_Programa +
//        '","Id_SubPrograma":"' + Id_SubPrograma +
//        '","Id_Materia":"' + Id_Materia +
//        '","Fecha_Inicio":"' + Fecha_Inicio +
//        '","Fecha_Fin":"' + Fecha_Fin +
//        '","Id_Localidad":"' + Id_Localidad +
//        '","Id_Direccion":"' + Id_Direccion +
//        '","Id_Gerencia":"' + Id_Gerencia +
//        '","Id_Jefatura":"' + Id_Jefatura +
//        '","Puesto":"' + strPuestos +
//        '","Grado":"' + strGrado +
//        '","Id_TipoEmp":"' + Id_TipoEmp +
//        '","Estatus":"' + Estatus +
//        '","NumNominas":"' + NumNominas +
//        '","NominaPadre":"' + NominaPadre +
//        '"}';

//    var _url = 'uiReportes/uiReporteAvance.aspx/ExportarReporteAvancePrograma';

//    debugger;

//    $.ajax({
//        type: 'POST',
//        url: _url,
//        data: _data,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (resultado) {


//            var ruta = resultado;
//            if (ruta.d != "") {
//                window.open("uiComun/AuxTableToXls.aspx");
//            }
//            else {
//                alert("No existe información con los parámetros seleccionados, verifique.");
//            }
//            closePopup('popup2', 0);
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error: " + error + " " + request.responseText);
//                closePopup('popup2', 0);
//            }
//        }
//    });

//}

function objectifyForm(formArray) {//serialize data function


    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

function validarCampos() {


    //Valida el campo area de aprendizaje
    var idAreaAprendizaje = $("#table-uiControl_Cursos #select_AreaAprendizaje").val();
    var idPrograma = $("#table-uiControl_Cursos #select_Programa").val();
    var permite_operacion = true;
    var mensaje = "";

    if (idAreaAprendizaje == "" || idAreaAprendizaje == undefined || idAreaAprendizaje == null || idAreaAprendizaje == "0" || isNaN(idAreaAprendizaje)) {
        permite_operacion = false;
        mensaje = "<br /><b>Área de aprendizaje</b>";
    }

    if (idPrograma == "" || idPrograma == undefined || idPrograma == null || idPrograma == "0" || isNaN(idPrograma)) {
        permite_operacion = false;
        mensaje += "<br /><b>Programa</b>";
    }

    if (permite_operacion == false) {
        showPopup('popup', "Los siguientes campos son obligatorios : " + mensaje, null);
        closePopup('popup2', 0);
    }


    return permite_operacion;


}


//function quitarSeleccionPuesto() {
//    $('#cboPuesto option').prop('selected', false);
//}


//function quitarSeleccionGrado() {
//    $('#cboGrado option').prop('selected', false);
//}


function CargarNominas() {
    var _contentProps =
    {
        easing: 'fadeIn', //uses jQuery easing plugin
        speed: 650,
        opacity: 0.4,
        modalColor: '#F8F8F8',
        modal: true,
        modalClose: false,
        onOpen: function () {
            setTimeout(function () { $(window).resize() }, 700);
        }
    }
    loadContent('#popContent > .content', '#div-contentNominas',
                    function () {

                        $('#popContent > .content #fuPerLstFileInstructores').fileupload({
                            replaceFileInput: true,
                            dataType: 'json',
                            url: 'uiComun/FileUploadHandler.ashx',
                            formData: function (form) {

                                return [{ name: 'usrFileName', value: 'LstUsuariosFile' }, { name: 'FileDesc', value: '-1' }, { name: 'IdObjeto', value: '0' }, { name: 'id_TipoObjeto', value: '4' }];
                            },
                            add: function (e, data) {

                                $('#popContent > .content #TxtAuxFileNameInstructor').val(data.files[0].name);

                                var valid = true;
                                var re = /^.+\.((xls)|(xlsx))$/i;

                                if (!re.test(data.files[0].name)) {
                                    alert("Debe seleccionar un archivo con extension .xls o .xlsx");
                                    valid = false;
                                }

                                data.context = $('#popContent > .content .BtnCargarLst').unbind('click').bind('click', function () {
                                    if (valid) {
                                        $('#popContent > .content #LabLoadingPW').fadeIn('slow');
                                        showLoader2();
                                        $('#popContent > .content  #TxtAuxFileNameInstructor').val('');
                                        data.submit();
                                        return;
                                    }
                                });
                            },
                            done: function (e, data) {
                                try {


                                    showLoader2();



                                    //$.each(data.result, function (index, file) {  cambio antonio comento la linea ya que solo se necesita el nombre del archivo

                                    var file = data.result.name;
                                    var JSONObj = '{"Id_Objeto":0, "Id_TipoObjeto":4, "Ruta":"' + file + '" }';
                                    var _dataObj = '{ Archivo: ' + JSONObj + ', estatus: ' + 'true' + '}';

                                    $.ajax({
                                        type: "POST",
                                        url: 'uiReportes/uiReporteAvance.aspx/cargaArchivoEmpleadosNominas',
                                        data: _dataObj,
                                        contentType: "application/json; charset=utf-8",
                                        dataType: "json",
                                        success: function (resultado) {




                                            if (resultado != null && resultado.d != null) {
                                                var json = $.parseJSON(resultado.d);
                                                var nominas = "";
                                                for (var i = 0; i < json.length; i++) {

                                                    nominas = nominas + json[i].Nomina + ",";
                                                }

                                                $("#AreaNumNomina").val(nominas);
                                            }
                                            closePopup('popContent', 0);
                                            closePopup('popup2', 0);
                                            /*
                                            showPopup('popup', 'Datos Guardados', props)
                                            closePopup('popContent', 0);
                                            if (resultado.d != "")
                                                window.open("uiComun/AuxTableToXls.aspx");
                                            closePopup('popup2', 0);
                                            */
                                        },
                                        error: function (request, status, error) {
                                            if (request.status == 401) {
                                                document.location.href = "uiPublic/uiLogin.aspx";
                                            } else {
                                                alert("Se ha producido el siguiente error:" + error + request.responseText);
                                            }
                                        }
                                    });

                                    //});
                                } catch (err) {
                                    closePopup('popup2', 0);
                                    alert('Error al Subir archivo:' + err);
                                }
                            },
                            fail: function (e, data) {
                                closePopup('popup2', 0);
                                alert('Error al Subir archivo:fail');
                            }
                        });

                        showPContent('popContent', _contentProps);
                    });
}


function filtrarDirecciones_CargaIntructores(idLocalidad) {

    $("#popContent > .content  #cboDireccionCI option").remove();
    $('#popContent > .content  #cboGerenciaCI option').remove();
    $('#popContent > .content  #cboJefaturaCI option').remove();

    if (idLocalidad == "" || idLocalidad == undefined || idLocalidad == null || isNaN(idLocalidad)) {
        alert("Seleccione localidad");
        return;
    }
    else {
        $.ajax({
            type: 'POST',
            url: 'uiReportes/uiReporteAvance.aspx/consultaDirecciones',
            data: '{"Id_Localidad":"' + idLocalidad + '"}',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            async: false,
            success: function (msg) {
                var res = msg.d;
                if (res != null) {
                    var option = "";
                    for (var i = 0; i < res.length; i++) {
                        option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
                    }
                    $('#popContent > .content  #cboDireccionCI').find('option').remove().end().append(option);
                }
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }

        });
    }
}



function filtrarGerencia_CargaIntructores(idDireccion) {

    $('#popContent > .content  #cboGerenciaCI option').remove();
    $('#popContent > .content  #cboJefaturaCI option').remove();

    if (idDireccion == "" || idDireccion == undefined || idDireccion == null || isNaN(idDireccion)) {
        alert("Seleccione dirección");
        return;
    }
    else {

        $.ajax({
            type: 'POST',
            url: 'uiReportes/uiReporteAvance.aspx/consultaGerencias',
            data: '{"Id_Direccion":"' + idDireccion + '"}',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            async: false,
            success: function (msg) {
                var res = msg.d;
                if (res != null) {
                    var option = "";
                    for (var i = 0; i < res.length; i++) {
                        option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
                    }
                    $('#popContent > .content  #cboGerenciaCI').find('option').remove().end().append(option);
                }
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }

        });
    }
}


function filtrarJefaturaCargaEmpleados(idGerencia) {

    $('#popContent > .content  #cboJefaturaCI option').remove();

    if (idGerencia == "" || idGerencia == undefined || idGerencia == null || isNaN(idGerencia)) {
        alert("Seleccione dirección");
        return;
    }
    else {


        $.ajax({
            type: 'POST',
            url: 'uiReportes/uiReporteAvance.aspx/consultaJefaturas',
            data: '{"Id_Gerencia":"' + idGerencia + '"}',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            async: false,
            success: function (msg) {
                var res = msg.d;
                if (res != null) {
                    var option = "";
                    for (var i = 0; i < res.length; i++) {
                        option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
                    }
                    $('#popContent > .content  #cboJefaturaCI').find('option').remove().end().append(option);
                }
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }

        });
    }
}

function descargarFormatoInstructores() {

    var idLocalidad = $("#popContent > .content #cboLocalidadCI").val();
    var idDireccion = $("#popContent > .content #cboDireccionCI").val();
    var idGerencia = $("#popContent > .content #cboGerenciaCI").val();
    var idJefatura = $("#popContent > .content #cboJefaturaCI").val();

    if (idLocalidad == "" || idLocalidad == undefined || idLocalidad == null || isNaN(idLocalidad)) {
        idLocalidad = 0;
    }
    if (idDireccion == "" || idDireccion == undefined || idDireccion == null || isNaN(idDireccion)) {
        idDireccion = 0;
    }
    if (idGerencia == "" || idGerencia == undefined || idGerencia == null || isNaN(idGerencia)) {
        idGerencia = 0;
    }
    if (idJefatura == "" || idJefatura == undefined || idJefatura == null || isNaN(idJefatura)) {
        idJefatura = 0;
    }

    var _data = '{"idLocalidad":"' + idLocalidad + '","idDireccion":"' + idDireccion + '","idGerencia":"' + idGerencia + '","idJefatura":"' + idJefatura + '"}';

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteAvance.aspx/GetArchivoStream',
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            window.open("uiComun/AuxTableToXls.aspx");
        },
        fail: function (error) {
            alert('No se pudo descargar el formato');
        }
    });
}




function CargarLocalidades() {


    var _url = "uiReportes/uiReporteAvance.aspx/ConsultarLocalidades";
    var _data = null;

    $.ajax({
        type: 'POST',
        url: _url,
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            //Carga el combo
            if (resultado != null && resultado.d != null) {
                var ctrCombo = $("#cboLocalidadCI");
                jsonResult = $.parseJSON(resultado.d);
                var option = '<option value="0">Seleccione</option>';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].Id_Localidad + '">' + jsonResult[i].Descripcion + '</option>';
                }
                ctrCombo.find('option').remove().end().append(option);
                option = null;

            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + " " + request.responseText);
                closePopup('popup2', 0);
            }
        }
    });
}


function CargarControlSeleccionCurso() {
    $('#div-uiControl_Cursos').load('uiControls/PartialView/uiControl_Cursos.aspx');
}

//Carga el control Jerarquia empelado
function CargarControlJerarquiaEmpleados() {
    //Carga el control Jerarquia empelado
    $('#divControl_JerarquiaEmpleado').load('uiControls/PartialView/uiControl_JerarquiaEmpleado.aspx', function (response, status, xhr) { });
}

function CargarControlPuestosGrados() {
    $('#div-uiControl_Puesto_Grado').load('uiControls/PartialView/uiControl_PuestoGrado.aspx');
}
