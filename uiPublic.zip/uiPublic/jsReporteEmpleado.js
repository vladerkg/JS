﻿/// <reference path="../JQuery/jquery-1.10.4/jquery-1.10.2.js" />
function GetData(callback) {
    //debugger;

    //buscarEmpleados(1, callback);
    LoadForm();
}

function buscarEmpleados(tipoBusqueda, callback) {
    //debugger;
    var _data = null;
    var _url = 'uiReportes/uiReporteEmpleados.aspx/'
    _url = _url + 'empleadoReporteS'
    showLoader2();
    $.ajax({
        type: 'POST',
        url: _url,
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            $('#content > .main').load('uiReportes/uiReporteEmpleados.aspx', function (response, status, xhr) {
                iniciaCombos();
                BindDataPickers();
                if (callback && typeof (callback) === "function") {
                    callback();
                }
            });
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + request.responseText);
                closePopup('popup2', 0);
            }
        }
    });
}

function BindDataPickers() {
    loadCSS('Scripts/datepicker/css/datepicker.css');
    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {
        //                    $('.TxtFechaIniF').datepicker({ format: 'dd/mm/yyyy' });
        //                    $('.TxtFechaFinF').datepicker({ format: 'dd/mm/yyyy' });
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#TxtFechaIniF').datepicker({
            onRender: function (date) {
                return '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {

            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate());
            checkout.setValue(newDate);

            checkin.hide();
            $('#TxtFechaFinF')[0].focus();
        }).data('datepicker');
        var checkout = $('#TxtFechaFinF').datepicker({
            onRender: function (date) {
                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');

        if ($('#TxtFechaIniF').val() != '') {
            checkin.setValue($('#TxtFechaIniF').val());
        }

        if ($('#TxtFechaFinF').val() != '') {
            checkout.setValue($('#TxtFechaFinF').val());
        }
    });
}

function iniciaCombos() {
    fillCombo('#cbClasifEmpleadoF', 'uiReportes/uiReporteEmpleados.aspx/consultaClasifEmp', null, 0);
    fillCombo('#cbGradoEscF', 'uiReportes/uiReporteEmpleados.aspx/consultaGradoEsc', null, 0);
    fillCombo('#cbLugarNacimientoF', 'uiReportes/uiReporteEmpleados.aspx/consultaLugarNac', null, 0);
    fillCombo('#cbNomCarreraF', 'uiReportes/uiReporteEmpleados.aspx/consultaNomCarrera', null, 0);
    fillCombo('#cbPuestoF', 'uiReportes/uiReporteEmpleados.aspx/consultaPuesto', null, 0)
    fillCombo('#cbTipoContF', 'uiReportes/uiReporteEmpleados.aspx/consultaTipoCont', null, 0);
    fillCombo('#cbTipoEmpF', 'uiReportes/uiReporteEmpleados.aspx/consultaTipoEmpleado', null, 0)
    fillCombo('#cbLocalidad', 'uiReportes/uiReporteEmpleados.aspx/consultaLocalidad', null, 0)
    fillCombo('#cbSexo', 'uiReportes/uiReporteEmpleados.aspx/consultaSexo', null, 0);
    fillCombo('#cbGrado0', 'uiReportes/uiReporteEmpleados.aspx/consultaGrado', null, 0);
}

function llamaCallback(callback) {
    if (callback && typeof (callback) === "function") {
        callback();
    }
}

function Reporte() {


    var nominaPadre = $("#divControl_JerarquiaEmpleado #hiddenNominaSelected").val();

    var _data = null;
    //var validar = validarForm();
    var _url = 'uiReportes/uiReporteEmpleados.aspx/'
    var result = "";
    _url = _url + 'empleadoReporte'
    var localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();
    var datSexo;
    if ($('#cbSexo').val() == 0) {
        datSexo = "0"
    }
    else {
        if ($('#cbSexo').val() == 1) {
            datSexo = "M"
        }
        else {
            datSexo = "H"
        }
    }

    var Sexo = datSexo;
    var LugarNacimiento = $('#cbLugarNacimientoF').val() == '' ? ' ' : $('#cbLugarNacimientoF').val();
    var TipoCont = $('#cbTipoContF').val() == '' ? ' ' : $('#cbTipoContF').val();
    var Puesto = $('#cbPuestoF').val() == '' ? ' ' : $('#cbPuestoF').val();
    var GradoEsc = $('#cbGradoEscF').val() == '' ? ' ' : $('#cbGradoEscF').val();
    var NomCarrera = $('#cbNomCarreraF').val() == '' ? ' ' : $('#cbNomCarreraF').val();
    var ClasifEmpleado = $('#cbClasifEmpleadoF').val() == '' ? ' ' : $('#cbClasifEmpleadoF').val();
    var TipoEmp = $('#cbTipoEmpF').val() == '' ? '' : $('#cbTipoEmpF').val();
    var FechaIngIni = $('#TxtFechaIniF').val() == '' ? '' : $('#TxtFechaIniF').val();
    var FechaIngFin = $('#TxtFechaFinF').val() == '' ? '' : $('#TxtFechaFinF').val();
    var Estatus = $('#chEstatusF').val() == '' ? '' : $('#chEstatusF').val();
    var Grado = $('#cbGrado0').val() == '' ? '' : $('#cbGrado0').val();
    var SoloAsignados = "0";


    if ($("#chkAsignados").is(':checked')) {
        SoloAsignados = "1";
    }


    var JSONEmpleados = '{ "Id_Localidad":"' + localidad +
                            '", "Sexo":"' + Sexo +
                            '", "Id_LugarNacimiento":"' + LugarNacimiento +
                            '", "Id_TipoContrato":"' + TipoCont +
                            '", "Id_Puesto":"' + Puesto +
                            '", "Id_GradoEscolaridad":"' + GradoEsc +
                            '", "Id_NombreCarrera":"' + NomCarrera +
                            '", "Id_ClasifEmpleado":"' + ClasifEmpleado +
                            '", "Id_TipoEmpleado":"' + TipoEmp +
                            '", "FechaIngIni":"' + FechaIngIni +
                            '", "FechaIngFin":"' + FechaIngFin +
                            '", "Estatus":"' + Estatus +
                            '", "Grado":"' + Grado +
                            '", "SoloAsignados":"' + SoloAsignados +
                            '", "NominaPadre":"' + nominaPadre + '"}';
    showLoader2();
    $.ajax({
        type: 'POST',
        url: _url,
        data: JSONEmpleados,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            //$('#content > .main').load('uiReportes/uiReporteEmpleados.aspx', function (response, status, xhr) {
            //iniciaCombos();
            //BindDataPickers();
            debugger;
            if (resultado.d != "") {
                window.open("uiComun/AuxTableToXls.aspx");
            }
            else {
                showPopup('popup', "No se encotraron resultados ", null);
                closePopup('popup2', 0);
            }
            //});
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {
            closePopup('popup2', 0);
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                //closePopup('popup2', 0);
            }
        }
    });
}



function LoadForm(e) {
    $('#content > .main').load('uiReportes/uiReporteEmpleados.aspx', function (response, status, xhr) {


        $(document).ready(function () {

            showLoader2();

            jQuery('#log').ajaxStop(function () {
                closePopup('popup2', 0);
            });

            jQuery("#log").ajaxComplete(function () {
                $("#popup2").find("div:first").html("");
            });


            $("#lnkGenerarReporte").click(function (event) {
                event.preventDefault();
                Reporte();
            })


            $("#lnkLimpiarCampos").click(function (event) {
                event.preventDefault();
                LimpiarCampos();
            });

            iniciaCombos();
            BindDataPickers();
            CargarControlJerarquiaEmpleados();

        });

    });
}


function LimpiarCampos() {
    $("#cbLocalidad").val("0");
    $("#cbSexo").val("0");
    $("#cbLugarNacimientoF").val("0");
    $("#cbTipoContF").val("0");
    $("#cbPuestoF").val("0");
    $("#cbGrado0").val("0");
    $("#cbGradoEscF").val("0");
    $("#cbNomCarreraF").val("0");
    $("#cbClasifEmpleadoF").val("0");
    $("#cbTipoEmpF").val("0");
    $("#chEstatusF").val("0");
    $("#TxtFechaIniF").val("");
    $("#TxtFechaFinF").val("");
}



//Carga el control Jerarquia empelado
function CargarControlJerarquiaEmpleados() {
    //debugger;
    //Carga el control Jerarquia empelado
    $('#divControl_JerarquiaEmpleado').load('uiControls/PartialView/uiControl_JerarquiaEmpleado.aspx', function (response, status, xhr) { });

}