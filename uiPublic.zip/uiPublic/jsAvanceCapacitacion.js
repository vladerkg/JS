﻿/// <reference path="../JQuery/jquery-1.10.4/jquery-1.10.2.js" />
function GetData(callback) {
    loadForm();
}


function loadForm() {
    $('#content > .main').load('uiReportes/uiAvanceCapacitacion.aspx', function (response, status, xhr) {
        $(document).ready(function () {
            CargarLocalidadesCursos();
            //CargarControlJerarquiaEmpleados();
            CargarControlSeleccionCurso();
            BindDatepickerFormat();
            //CargarControlSeleccionLocalidad();
            //CargarControlPuestosGrados();

            $("#lnkSeleccionarTodos").on('click', function (event) {
                event.preventDefault();
                SeleccionarLocalidades();
                return false;
            });

            $("#lnkDeseleccionarTodos").on('click', function (event) {
                event.preventDefault();
                DeseleccionarLocalidades();
                return false;
            });


            $("#btnGenerarReporte").on('click', function (event) {
                event.preventDefault();
                generarReporte();
                return false;
            });

        });
    });
}


function SeleccionarLocalidades() {
    $('#cboLocalidadCurso option').prop('selected', true);
}

function DeseleccionarLocalidades() {
    $("#cboLocalidadCurso").val("");
}

function CargarControlSeleccionCurso() {
    $('#div-uiControl_Cursos').load('uiControls/PartialView/uiControl_Cursos.aspx');
}

//Carga el control Jerarquia empelado
function CargarControlJerarquiaEmpleados() {
    //Carga el control Jerarquia empelado
    $('#divControl_JerarquiaEmpleado').load('uiControls/PartialView/uiControl_JerarquiaEmpleado.aspx', function (response, status, xhr) { });
}

//function CargarControlPuestosGrados() {
//    $('#div-uiControl_Puesto_Grado').load('uiControls/PartialView/uiControl_PuestoGrado.aspx');
//}



function BindDatepickerFormat() {

    loadCSS('Scripts/datepicker/css/datepicker.css');
    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {

        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#txtFechaInicial').datepicker({
            onRender: function (date) {
                return '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {

            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate());
            checkout.setValue(newDate);

            checkin.hide();
            $('#txtFechaFinal')[0].focus();
        }).data('datepicker');
        var checkout = $('#txtFechaFinal').datepicker({
            onRender: function (date) {
                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');

        if ($('#txtFechaInicial').val() != '') {
            checkin.setValue($('#txtFechaInicial').val());
        }

        if ($('#txtFechaFinal').val() != '') {
            checkout.setValue($('#txtFechaFinal').val());
        }



    });
}



function CargarLocalidadesCursos() {


    $("#cboLocalidadCurso option").remove();
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiAvanceCapacitacion.aspx/ConsultarLocalidadesCursos',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {


            if (msg != null) {


                var ctrCombo = $("#cboLocalidadCurso");
                jsonResult = $.parseJSON(msg.d);

                //Carga el combo
                var option = '';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].Id_Localidad + '">' + jsonResult[i].Descripcion + '</option>';
                }

                ctrCombo.find('option').remove().end().append(option);
                option = null;
            }

        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


function generarReporte() {

    if ($("#cboTipoAvance").val() == "") {
        showPopup('popup', "Seleccione tipo de búsqueda - Avance por: Horas / Personas", null);
        closePopup('popup2', 0);
        return;
    }

    var Puesto = $("#cboLocalidadCurso");
    var indice = Puesto[0];
    var TotalRegistros = indice.childElementCount;
    var strLocalidades = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strLocalidades += ("'" + indice[i].value + "',");
        }
    }


    var _formArray = $("#frmReporte").serializeArray();
    var myJson = objectifyForm(_formArray);
    myJson["Localidades"] = strLocalidades;
    var strJson = JSON.stringify(myJson);

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiAvanceCapacitacion.aspx/GenerarReporte',
        data: '{ frm : ' + strJson + ' }',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {

            if (msg != null) {

                if (msg != null && msg.d != "") {
                    window.open("uiComun/AuxTableToXls.aspx");
                }
                else {
                    showPopup('popup', "No se encotraron resultados ", null);
                    closePopup('popup2', 0);
                }
                closePopup('popup2', 0);

                //var ctrCombo = $("#cboLocalidadCurso");
                //jsonResult = $.parseJSON(msg.d);

                ////Carga el combo
                //var option = '';
                //for (var i = 0; i < jsonResult.length; i++) {
                //    option += '<option value="' + jsonResult[i].Id_Localidad + '">' + jsonResult[i].Descripcion + '</option>';
                //}

                //ctrCombo.find('option').remove().end().append(option);
                //option = null;

            }

        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


function objectifyForm(formArray) {//serialize data function


    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}