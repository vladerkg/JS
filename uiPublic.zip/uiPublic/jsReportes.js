﻿/// <reference path="../JQuery/jquery-1.10.4/jquery-1.10.2.js" />
function GetData(callback) {
    // buscarReporte(1, callback);
    loadForm();
}

function loadForm() {
    $('#content > .main').load('uiReportes/uiReportes.aspx', function (response, status, xhr) {


        $(document).ready(function (event) {

            CargarControlSeleccionCurso();
            CargarControlSeleccionLocalidad();
            CargarControlJerarquiaEmpleados();
            CargarCombos();

            $("#linkDeseleccionarPuestos").on('click', function (event) {
                event.preventDefault();
                $("#cbPuestos").val("");
                return false;
            });

            $("#linkDeseleccionarGrados").on('click', function (event) {
                event.preventDefault();
                $("#cbGradoF").val("");
                return false;
            });

            $("#lnkReporte").on('click', function (event) {
                event.preventDefault();
                GenerarReporte();
            });

            $("#lnkLimpiarCampos").on('click', function (event) {
                event.preventDefault();
                limpiarCampos();
                return false;
            });

        });

    });
}

function CargarControlSeleccionCurso() {
    $('#div-uiControl_Cursos').load('uiControls/PartialView/uiControl_Cursos.aspx');
}

function CargarControlSeleccionLocalidad() {
    $('#div-uiControl_Loc_Dir_Ger_Jef').load('uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx');
}

function CargarControlJerarquiaEmpleados() {
    $('#divControl_JerarquiaEmpleado').load('uiControls/PartialView/uiControl_JerarquiaEmpleado.aspx');
}


function CargarCombos() {
    BindDataPickers();
    fillCombo('#cbTipoConF', 'uiReportes/uiReportes.aspx/consultaTipoCont', null, 0);
    //fillCombo('#cbGradoF', 'uiReportes/uiReportes.aspx/consultaGrado', null, 0);
    fillCombo('#cbClasificacionF', 'uiReportes/uiReportes.aspx/consultaClasifEmp', null, 0);
    ObtnerPuesto();
    ObtnerGrado();
}

function ObtnerPuesto() {
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReportes.aspx/ObtenerPuestos',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg != null) {

                var ctrCombo = $("#cbPuestos");

                jsonResult = $.parseJSON(msg.d);

                //Carga el combo
                var option = ''; //'<option value="-1">Seleccione</option>';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].Puesto + '">' + jsonResult[i].Puesto + '</option>';
                }

                ctrCombo.find('option').remove().end().append(option);
                option = null;
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}

function ObtnerGrado() {
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReportes.aspx/ObtenerGrados',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg != null) {

                var ctrCombo = $("#cbGradoF");

                jsonResult = $.parseJSON(msg.d);

                //Carga el combo

                var option = ''; //'<option value="-1">Seleccione</option>';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].Grado + '">' + jsonResult[i].Grado + '</option>';
                }

                ctrCombo.find('option').remove().end().append(option);
                option = null;



            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


function validarCampos() {
    var tipoReporte = $("#Id_Opcion").val();

    if (tipoReporte == "0") {
        showPopup('popup', "Seleccione tipo de reporte", null);
        closePopup('popup2', 0);
        $("#Id_Opcion").focus();
        return false;
    }

    return true;
}


function GenerarReporte() {
    if (validarCampos()) {

        var _formArray = $("#frmReporte").serializeArray();

        //var Puesto = $("#cbPuestos");
        //var indice = Puesto[0];
        //var TotalRegistros = indice.childElementCount;
        //var strPuestos = new Array();

        //for (var i = 0; i < TotalRegistros; i++) {
        //    if (indice[i].selected == true) {
        //        strPuestos[i] = indice[i].value;
        //    }
        //}

        //var Grado = $("#cbGradoF");
        //indice = Grado[0];
        //TotalRegistros = indice.childElementCount;
        //var strGrados = new Array();

        //for (var i = 0; i < TotalRegistros; i++) {
        //    if (Grado[i].selected == true) {
        //        strGrados[i] = indice[i].value;
        //    }
        //}


        var Puesto = $("#cbPuestos");
        var indice = Puesto[0];
        var TotalRegistros = indice.childElementCount;
        var strPuestos = '';

        for (var i = 0; i < TotalRegistros; i++) {

            if (indice[i].selected == true) {
                strPuestos += ("'" + indice[i].value + "',");
            }
        }

        var Grado = $("#cbGradoF");
        indice = Grado[0];
        TotalRegistros = indice.childElementCount;
        var strGrado = '';

        for (var i = 0; i < TotalRegistros; i++) {

            if (indice[i].selected == true) {
                strGrado += ("'" + indice[i].value + "',");
            }
        }


        var myJson = objectifyForm(_formArray);

        myJson["Puestos"] = strPuestos;
        myJson["Grados"] = strGrado;

        var strJson = JSON.stringify(myJson);



        showLoader2();

        $.ajax({
            type: 'POST',
            url: 'uiReportes/uiReportes.aspx/GenerarReporte',
            data: '{ frm : ' + strJson + ' }',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (msg) {
                if (msg != null) {
                    window.open("uiComun/AuxTableToXls.aspx");
                }
                closePopup('popup2', 0);
            },
            error: function (request, status, error) {

                closePopup('popup2', 0);
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }
        });
    }
}


function limpiarCampos() {

    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_AreaAprendizaje").val("0");
    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_Programa option").remove();
    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_SubPrograma option").remove();
    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_Curso option").remove();

    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Localidad").val("0");
    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Direccion").val("0");
    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Gerencia option").remove();
    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Jefatura option ").remove();

    $("#Id_Opcion").val("0");
    $("#TxtFechaIniF").val("");
    $("#TxtFechaFinF").val("");
    $("#cbClasificacionF").val("0");
    $("#cbTipoConF").val("0");
    $("#cbPuestos").val("");
    $("#cbGradoF").val("");

    return false;
}


function objectifyForm(formArray) {//serialize data function


    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

//function ConvertFormToJSON(form) {
//    var array = jQuery(form).serializeArray();
//    var json = {};

//    jQuery.each(array, function () {
//        json[this.name] = this.value || '';
//    });

//    return json;
//}


/*****************/
function ConvertFormToJson(form) {
    var o = {};
    var a = $(form).serializeArray();
    $.each(a, function () {
        if (o[this.name]) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });

    return o;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////

function buscarReporte(tipoBusqueda, callback) {
    var _data = null;
    var validar = validarForm();
    var _url = 'uiReportes/uiReportes.aspx/'
    var result = "'";
    if (tipoBusqueda == 1) {//Todos  
        _url = _url + 'consultar'
    }
    $.ajax({
        type: 'POST',
        url: _url,
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            $('#content > .main').load('uiReportes/uiReportes.aspx', function (response, status, xhr) {
                fillCombo('#cbLocalidad', 'uiReportes/uiReportes.aspx/consultaLocalidad', null, 0)
                fillCombo('#cbGradoF', 'uiReportes/uiReportes.aspx/consultaGrado', null, 0);
                fillCombo('#cbClasificacionF', 'uiReportes/uiReportes.aspx/consultaClasifEmp', null, 0);
                fillCombo('#cbAreaF', 'uiReportes/uiReportes.aspx/ListaAreas', null, 0)
                fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
                fillCombo('#cbTipoConF', 'uiReportes/uiReportes.aspx/consultaTipoCont', null, 0);
                BindDataPickers();

                CargarControlSeleccionCurso();

                if (callback && typeof (callback) === "function") {
                    callback();
                }
            });
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
            }
        }
    });
}

function filtrarArea(_valor) {
    var _data = '{"Id_Area":"' + _valor + '", "Id_Localidad":"0"}';
    fillCombo('#cbProgramaF', 'uiReportes/uiReportes.aspx/consultarAreaXProgramas', _data, 0);
}

function filtrarMaterias(_valor, _select) {
    //alert('');
    //iniciaCombos    
    $('#cbCursoF option').remove();
    var _data = '{ "Id_Programa": "' + _valor + '" }';
    fillCombo('#cbCursoF', 'uiReportes/uiReportes.aspx/consultaCursoXProg', _data, 0)
}


function habilitaBotonDirectores() {
    var direc = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
    var _data = null;
    var combo = document.getElementById("cbDireccionF");
    fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', direc);
    fillCombo('#cbSubdireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 2 + ', Id_Antecesor: ' + direc + '}', direc);
    //    $('#cbGerenciaF option').remove();
    //    $('#cbDepartamentoF option').remove();
}

function habilitaBotonSubDirectores() {
    var direc = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
    var subDirec = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
    var comboDi = document.getElementById("cbDireccionF");
    var comboSDi = document.getElementById("cbSubdireccionF");
    fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', direc);
    fillCombo('#cbSubdireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 2 + ', Id_Antecesor: ' + direc + '}', subDirec);
    fillCombo('#cbGerenciaF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 3 + ', Id_Antecesor: ' + subDirec + '}', 0);
    //    $('#cbDepartamentoF option').remove();
}

function habilitaBotonGerentes() {
    var direc = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
    var subDirec = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
    var geren = $('#cbGerenciaF').val() == '' ? ' ' : $('#cbGerenciaF').val();
    var comboDi = document.getElementById("cbDireccionF");
    var comboSDi = document.getElementById("cbSubdireccionF");
    var comboGer = document.getElementById("cbGerenciaF");
    fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', direc);
    fillCombo('#cbSubdireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 2 + ', Id_Antecesor: ' + direc + '}', subDirec);
    fillCombo('#cbGerenciaF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 3 + ', Id_Antecesor: ' + subDirec + '}', geren);
    fillCombo('#cbDepartamentoF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 4 + ', Id_Antecesor: ' + geren + '}', 0);
}

function Reporte() {
    //debugger;
    var _data = null;
    var validar = validarForm();
    var _url = 'uiReportes/uiReportes.aspx/'
    var result = "";
    var Id_Opcion = $('#Id_Opcion').val() == '' ? ' ' : $('#Id_Opcion').val();

    if (Id_Opcion == 1) {
        _url = _url + 'consultarNoAprobados'
        var Id_Programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();
        var Id_Area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
        var Id_Curso = $('#cbCursoF').val() == '' ? ' ' : $('#cbCursoF').val();
        var Id_Dire = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
        var Id_Subdireccion = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
        var Id_Gerencia = $('#cbGerenciaF').val() == '' ? ' ' : $('#cbGerenciaF').val();
        var Id_Departamento = $('#cbDepartamentoF').val() == '' ? ' ' : $('#cbDepartamentoF').val();
        var Id_Clasificacion = $('#cbClasificacionF').val() == '' ? ' ' : $('#cbClasificacionF').val();
        var Id_TipoCont = $('#cbTipoConF').val() == '' ? ' ' : $('#cbTipoConF').val();
        var fechaInicial = $('#TxtFechaIniF').val() == '' ? ' ' : $('#TxtFechaIniF').val();
        var fechaFinal = $('#TxtFechaFinF').val() == '' ? ' ' : $('#TxtFechaFinF').val();
        var Id_Localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();

        var edit = new Array();
        var selGrado = document.getElementById("cbGradoF");
        for (i = 0; i < selGrado.length; i++) {
            currentOption = selGrado[i];
            if (currentOption.selected == true) {
                if (result == "") {
                    result += currentOption.innerText + "-,";
                }
                else {
                    result += "-" + currentOption.innerText + "-,";
                }
            }
            else {
                result = result;
            }
        }
        var gradod = result.substring(0, result.length - 1);
        var comboDi = document.getElementById("cbAreaF");
        //var date =
        _data = '{ Id_Programa: ' + Id_Programa + ' , Id_Area: ' + Id_Area + ' , Id_Curso: ' + Id_Curso + ' , Id_Dire: ' + Id_Dire + ' , Id_Subdireccion: ' + Id_Subdireccion + ' , Id_Gerencia: ' + Id_Gerencia + ' , Id_Departamento: ' + Id_Departamento + ' , Id_Clasificacion: ' + Id_Clasificacion + ' , Grado: "' + gradod + '", Area: "' + comboDi.options[comboDi.selectedIndex].innerText + '" , Id_TipoCont: ' + Id_TipoCont + ', fechaInicial: "' + fechaInicial + '", fechaFinal: "' + fechaFinal + '", Id_Localidad: ' + Id_Localidad + ' }';

        showLoader2();
        $.ajax({
            type: 'POST',
            url: _url,
            data: _data,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (resultado) {
                $('#content > .main').load('uiReportes/uiReportes.aspx', function (response, status, xhr) {
                    fillCombo('#cbLocalidad', 'uiReportes/uiReportes.aspx/consultaLocalidad', null, 0)
                    fillCombo('#cbGradoF', 'uiReportes/uiReportes.aspx/consultaGrado', null, 0);
                    fillCombo('#cbClasificacionF', 'uiReportes/uiReportes.aspx/consultaClasifEmp', null, 0);
                    fillCombo('#cbAreaF', 'uiReportes/uiReportes.aspx/ListaAreas', null, 0)
                    fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
                    fillCombo('#cbTipoConF', 'uiReportes/uiReportes.aspx/consultaTipoCont', null, 0);
                    BindDataPickers();
                    window.open("uiComun/AuxTableToXls.aspx");
                });
                closePopup('popup2', 0);
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                    closePopup('popup2', 0);
                }
            }
        });
    }
    else {
        if (Id_Opcion == 2) {
            _url = _url + 'consultaEmpleadosPostulados'
            var Id_Programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();
            var Id_Area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
            var Id_Curso = $('#cbCursoF').val() == '' ? ' ' : $('#cbCursoF').val();
            var Id_Dire = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
            var Id_Subdireccion = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
            var Id_Gerencia = $('#cbGerenciaF').val() == '' ? ' ' : $('#cbGerenciaF').val();
            var Id_Departamento = $('#cbDepartamentoF').val() == '' ? ' ' : $('#cbDepartamentoF').val();
            var Id_Clasificacion = $('#cbClasificacionF').val() == '' ? ' ' : $('#cbClasificacionF').val();
            var Id_TipoCont = $('#cbTipoConF').val() == '' ? ' ' : $('#cbTipoConF').val();
            var fechaInicial = $('#TxtFechaIniF').val() == '' ? ' ' : $('#TxtFechaIniF').val();
            var fechaFinal = $('#TxtFechaFinF').val() == '' ? ' ' : $('#TxtFechaFinF').val();
            var Id_Localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();

            var edit = new Array();
            var selGrado = document.getElementById("cbGradoF");
            for (i = 0; i < selGrado.length; i++) {
                currentOption = selGrado[i];
                if (currentOption.selected == true) {
                    if (result == "") {
                        result += currentOption.innerText + "-,";
                    }
                    else {
                        result += "-" + currentOption.innerText + "-,";
                    }
                }
                else {
                    result = result;
                }
            }
            var gradod = result.substring(0, result.length - 1);
            var comboDi = document.getElementById("cbAreaF");
            //var date =
            _data = '{ Id_Programa: ' + Id_Programa + ' , Id_Area: ' + Id_Area + ' , Id_Curso: ' + Id_Curso + ' , Id_Dire: ' + Id_Dire + ' , Id_Subdireccion: ' + Id_Subdireccion + ' , Id_Gerencia: ' + Id_Gerencia + ' , Id_Departamento: ' + Id_Departamento + ' , Id_Clasificacion: ' + Id_Clasificacion + ' , Grado: "' + gradod + '", Area: "' + comboDi.options[comboDi.selectedIndex].innerText + '" , Id_TipoCont: ' + Id_TipoCont + ', fechaInicial: "' + fechaInicial + '", fechaFinal: "' + fechaFinal + '", Id_Localidad: ' + Id_Localidad + ' }';

            showLoader2();
            $.ajax({
                type: 'POST',
                url: _url,
                data: _data,
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (resultado) {
                    $('#content > .main').load('uiReportes/uiReportes.aspx', function (response, status, xhr) {
                        fillCombo('#cbLocalidad', 'uiReportes/uiReportes.aspx/consultaLocalidad', null, 0)
                        fillCombo('#cbGradoF', 'uiReportes/uiReportes.aspx/consultaGrado', null, 0);
                        fillCombo('#cbClasificacionF', 'uiReportes/uiReportes.aspx/consultaClasifEmp', null, 0);
                        fillCombo('#cbAreaF', 'uiReportes/uiReportes.aspx/ListaAreas', null, 0)
                        fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
                        fillCombo('#cbTipoConF', 'uiReportes/uiReportes.aspx/consultaTipoCont', null, 0);
                        BindDataPickers();
                        window.open("uiComun/AuxTableToXls.aspx");
                    });
                    closePopup('popup2', 0);
                },
                error: function (request, status, error) {
                    if (request.status == 401) {
                        document.location.href = "uiPublic/uiLogin.aspx";
                    } else {
                        alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                        closePopup('popup2', 0);
                    }
                }
            });
        }
        else {
            if (Id_Opcion == 3) {
                _url = _url + 'consultaEmpleadosInscritos'
                var Id_Programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();
                var Id_Area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
                var Id_Curso = $('#cbCursoF').val() == '' ? ' ' : $('#cbCursoF').val();
                var Id_Dire = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
                var Id_Subdireccion = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
                var Id_Gerencia = $('#cbGerenciaF').val() == '' ? ' ' : $('#cbGerenciaF').val();
                var Id_Departamento = $('#cbDepartamentoF').val() == '' ? ' ' : $('#cbDepartamentoF').val();
                var Id_Clasificacion = $('#cbClasificacionF').val() == '' ? ' ' : $('#cbClasificacionF').val();
                var Id_TipoCont = $('#cbTipoConF').val() == '' ? ' ' : $('#cbTipoConF').val();
                var fechaInicial = $('#TxtFechaIniF').val() == '' ? ' ' : $('#TxtFechaIniF').val();
                var fechaFinal = $('#TxtFechaFinF').val() == '' ? ' ' : $('#TxtFechaFinF').val();
                var Id_Localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();

                var edit = new Array();
                var selGrado = document.getElementById("cbGradoF");
                for (i = 0; i < selGrado.length; i++) {
                    currentOption = selGrado[i];
                    if (currentOption.selected == true) {
                        if (result == "") {
                            result += currentOption.innerText + "-,";
                        }
                        else {
                            result += "-" + currentOption.innerText + "-,";
                        }
                    }
                    else {
                        result = result;
                    }
                }
                var gradod = result.substring(0, result.length - 1);
                var comboDi = document.getElementById("cbAreaF");
                //var date =
                _data = '{ Id_Programa: ' + Id_Programa + ' , Id_Area: ' + Id_Area + ' , Id_Curso: ' + Id_Curso + ' , Id_Dire: ' + Id_Dire + ' , Id_Subdireccion: ' + Id_Subdireccion + ' , Id_Gerencia: ' + Id_Gerencia + ' , Id_Departamento: ' + Id_Departamento + ' , Id_Clasificacion: ' + Id_Clasificacion + ' , Grado: "' + gradod + '", Area: "' + comboDi.options[comboDi.selectedIndex].innerText + '" , Id_TipoCont: ' + Id_TipoCont + ', fechaInicial: "' + fechaInicial + '", fechaFinal: "' + fechaFinal + '", Id_Localidad: ' + Id_Localidad + ' }';

                showLoader2();
                $.ajax({
                    type: 'POST',
                    url: _url,
                    data: _data,
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    success: function (resultado) {
                        $('#content > .main').load('uiReportes/uiReportes.aspx', function (response, status, xhr) {
                            fillCombo('#cbLocalidad', 'uiReportes/uiReportes.aspx/consultaLocalidad', null, 0)
                            fillCombo('#cbGradoF', 'uiReportes/uiReportes.aspx/consultaGrado', null, 0);
                            fillCombo('#cbClasificacionF', 'uiReportes/uiReportes.aspx/consultaClasifEmp', null, 0);
                            fillCombo('#cbAreaF', 'uiReportes/uiReportes.aspx/ListaAreas', null, 0)
                            fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
                            fillCombo('#cbTipoConF', 'uiReportes/uiReportes.aspx/consultaTipoCont', null, 0);
                            BindDataPickers();
                            window.open("uiComun/AuxTableToXls.aspx");
                        });
                        closePopup('popup2', 0);
                    },
                    error: function (request, status, error) {
                        if (request.status == 401) {
                            document.location.href = "uiPublic/uiLogin.aspx";
                        } else {
                            alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                            closePopup('popup2', 0);
                        }
                    }
                });
            }
            else {
                if (Id_Opcion == 4) {
                    _url = _url + 'consultaSinCurso'
                    var Id_Programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();
                    var Id_Area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
                    var Id_Curso = $('#cbCursoF').val() == '' ? ' ' : $('#cbCursoF').val();
                    var Id_Dire = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
                    var Id_Subdireccion = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
                    var Id_Gerencia = $('#cbGerenciaF').val() == '' ? ' ' : $('#cbGerenciaF').val();
                    var Id_Departamento = $('#cbDepartamentoF').val() == '' ? ' ' : $('#cbDepartamentoF').val();
                    var Id_Clasificacion = $('#cbClasificacionF').val() == '' ? ' ' : $('#cbClasificacionF').val();
                    var Id_TipoCont = $('#cbTipoConF').val() == '' ? ' ' : $('#cbTipoConF').val();
                    var Id_Localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();

                    var edit = new Array();
                    var selGrado = document.getElementById("cbGradoF");
                    for (i = 0; i < selGrado.length; i++) {
                        currentOption = selGrado[i];
                        if (currentOption.selected == true) {
                            if (result == "") {
                                result += currentOption.innerText + "-,";
                            }
                            else {
                                result += "-" + currentOption.innerText + "-,";
                            }
                        }
                        else {
                            result = result;
                        }
                    }
                    var gradod = result.substring(0, result.length - 1);
                    var comboDi = document.getElementById("cbAreaF");
                    //var date =
                    _data = '{ Id_Programa: ' + Id_Programa + ' , Id_Area: ' + Id_Area + ' , Id_Curso: ' + Id_Curso + ' , Id_Dire: ' + Id_Dire + ' , Id_Subdireccion: ' + Id_Subdireccion + ' , Id_Gerencia: ' + Id_Gerencia + ' , Id_Departamento: ' + Id_Departamento + ' , Id_Clasificacion: ' + Id_Clasificacion + ' , Grado: "' + gradod + '", Area: "' + comboDi.options[comboDi.selectedIndex].innerText + '" , Id_TipoCont: ' + Id_TipoCont + ', Id_Localidad: ' + Id_Localidad + ' }';

                    showLoader2();
                    $.ajax({
                        type: 'POST',
                        url: _url,
                        data: _data,
                        contentType: 'application/json; charset=utf-8',
                        dataType: 'json',
                        success: function (resultado) {
                            $('#content > .main').load('uiReportes/uiReportes.aspx', function (response, status, xhr) {
                                fillCombo('#cbLocalidad', 'uiReportes/uiReportes.aspx/consultaLocalidad', null, 0)
                                fillCombo('#cbGradoF', 'uiReportes/uiReportes.aspx/consultaGrado', null, 0);
                                fillCombo('#cbClasificacionF', 'uiReportes/uiReportes.aspx/consultaClasifEmp', null, 0);
                                fillCombo('#cbAreaF', 'uiReportes/uiReportes.aspx/ListaAreas', null, 0)
                                fillCombo('#cbDireccionF', 'uiReportes/uiReportes.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
                                fillCombo('#cbTipoConF', 'uiReportes/uiReportes.aspx/consultaTipoCont', null, 0);
                                BindDataPickers();
                                window.open("uiComun/AuxTableToXls.aspx");
                            });
                            closePopup('popup2', 0);
                        },
                        error: function (request, status, error) {
                            if (request.status == 401) {
                                document.location.href = "uiPublic/uiLogin.aspx";
                            } else {
                                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                                closePopup('popup2', 0);
                            }
                        }
                    });
                }
            }
        }
    }
}

function BindDataPickers() {
    loadCSS('Scripts/datepicker/css/datepicker.css');
    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {
        //                    $('.TxtFechaIniF').datepicker({ format: 'dd/mm/yyyy' });
        //                    $('.TxtFechaFinF').datepicker({ format: 'dd/mm/yyyy' });
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#TxtFechaIniF').datepicker({
            onRender: function (date) {
                return '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {

            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate());
            checkout.setValue(newDate);

            checkin.hide();
            $('#TxtFechaIniF')[0].focus();
        }).data('datepicker');
        var checkout = $('#TxtFechaFinF').datepicker({
            onRender: function (date) {
                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');

        if ($('#TxtFechaIniF').val() != '') {
            checkin.setValue($('#TxtFechaIniF').val());
        }

        if ($('#TxtFechaFinF').val() != '') {
            checkout.setValue($('#TxtFechaFinF').val());
        }
    });
}

