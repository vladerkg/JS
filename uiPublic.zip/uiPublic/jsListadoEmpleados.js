﻿/// <reference path="../JQuery/jquery-1.10.4/jquery-1.10.2.js" />
function GetData(callback) {
    //buscarLista(1, callback);
    loadForm();

}


function CargarControlSeleccionCurso() {
    $('#div-uiControl_Cursos').load('uiControls/PartialView/uiControl_Cursos.aspx');
}

//function CargarControlSeleccionLocalidad(esAdmin) {
function CargarControlSeleccionLocalidad() {

    //$.get("uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx?", { Ident: "1" }, function (htmlexterno) {

    //    $("#div-uiControl_Loc_Dir_Ger_Jef").html(htmlexterno);
    //});
    //if (esAdmin == true) {

    //    $.get("uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx?", { Ident: "" }, function (htmlexterno) {

    //        $("#div-uiControl_Loc_Dir_Ger_Jef").html(htmlexterno);
    //    });
    //   // $('#div-uiControl_Loc_Dir_Ger_Jef').load('uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx?Indet=1');
    //}
    //else {
    //    $.get("uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx?", { Ident: "1" }, function (htmlexterno) {

    //        $("#div-uiControl_Loc_Dir_Ger_Jef").html(htmlexterno);
    //    });
    //    //$('#div-uiControl_Loc_Dir_Ger_Jef').load('uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx');
    //}
    $('#div-uiControl_Loc_Dir_Ger_Jef').load('uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx');

}


//Carga el control Jerarquia empelado
function CargarControlJerarquiaEmpleados() {
    //Carga el control Jerarquia empelado
    $('#divControl_JerarquiaEmpleado').load('uiControls/PartialView/uiControl_JerarquiaEmpleado.aspx', function (response, status, xhr) { });
}

function CargarControlPuestosGrados() {
    $('#div-uiControl_Puesto_Grado').load('uiControls/PartialView/uiControl_PuestoGrado.aspx');
}

function NoAdmin() {

    //Oculta si no es admin
    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";");
    var micookie = null;

    for (i in listaCookies) {
        var busca = listaCookies[i].search("Perfil");
        if (busca > -1) {
            micookie = listaCookies[i];
            break;
        }
    }

    var igual = micookie.indexOf("=");

    var valor = micookie.split('=');
    if (valor.length > 1) {

        if (valor[1] != 1) {

            //Quita los divs 
            $("#div-uiControl_Puesto_Grado").css("display", "none");
            $("#tbl_ReporteAvance").css("display", "none");
            $("#div-uiControl_Loc_Dir_Ger_Jef").css("display", "none");

            //$("#tbl_ReporteAvance").css("display", "none");
            //$("#table-uiControl_Loc_Dir_Ger_Jef").css("display", "none");
            //$("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Direccion").css("display", "none");
            //$("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Gerencia").css("display", "none");
            //$("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Jefatura").css("display", "none");
            //ocultarValores(1);
            //CargarControlSeleccionLocalidad(false);
        }
        //else {
        //CargarControlSeleccionLocalidad(true);
        //}
    }
}

function CargarLocalidadesCursos() {


    $("#cboLocalidadCurso option").remove();
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteDetalle.aspx/ConsultarLocalidadesCursos',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {


            if (msg != null) {


                var ctrCombo = $("#cboLocalidadCurso");
                jsonResult = $.parseJSON(msg.d);

                //Carga el combo
                var option = '<option value="-1">Seleccione</option>';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].Id_Localidad + '">' + jsonResult[i].Descripcion + '</option>';
                }

                ctrCombo.find('option').remove().end().append(option);
                option = null;
            }

        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}

//function ocultarValores(Ident) {
//$(document).ready(function () {



//    if (Ident == 1) {

//        //$("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Localidad").show();
//        $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Direccion").hide();
//        $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Gerencia").hide();
//        $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Jefatura").hide();

//        $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #label_Direccion").hide();
//        $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #label_Gerencia").hide();
//        $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #lable_Jefatura").hide();
//    }

//});

//}

function loadForm() {
    $('#content > .main').load('uiReportes/uiReporteDetalle.aspx', function (response, status, xhr) {

        cargarCombos();
        // ObtenerGradosWorkDay();

        try {
            showLoader2();
            jQuery('#log').ajaxStop(function () {
                closePopup('popup2', 0);

            });
        } catch (e) {

        }

        $(document).ready(function () {
            //$("#cbAreaF").on('change', function () {
            //    filtrarAreas();
            //});

            //$("#cbProgramaF").on('change', function () {
            //    filtrarComboSubProgramas();
            //});

            //$("#cbSubPrograma").on('change', function () {
            //    filtrarComboCursos();
            //});

            CargarControlJerarquiaEmpleados();
            CargarControlSeleccionCurso();
            CargarControlSeleccionLocalidad();
            CargarControlPuestosGrados();

            $("#linkReporte").on('click', function (event) {

                event.preventDefault();
                setNombresAsignados();
                generarReporte();
                return false;
            });

            $("#linkReporteTotales").on('click', function (event) {
                event.preventDefault();
                setNombresAsignados();
                generarReporteTotales();
                return false;
            });

            $("#tbl_ReporteAvance #cbEstatus").on('click', function () {
                $("#hiddenDescEstatus").val($(this).find('option:selected').text());
            });

            $("#tbl_ReporteAvance #cbClasificacionF").on('click', function () {
                $("#hiddenDescClasificacion").val($(this).find('option:selected').text());
            });

            $("#tbl_ReporteAvance #cbJuicioF").on('click', function () {
                $("#hiddenDescJuicio").val($(this).find('option:selected').text());
            });

            $("#tbl_ReporteAvance #cbTipoConF").on('click', function () {
                $("#hiddenDescTipoContrato").val($(this).find('option:selected').text());
            });

            $("#tbl_ReporteAvance #cbEvaluacionF").on('click', function () {
                $("#hiddenDescEvaluacion").val($(this).find('option:selected').text());
            });

            $("#tbl_ReporteAvance #cbHistoricoF").on('click', function () {
                $("#hiddenDescHistorico").val($(this).find('option:selected').text());
            });

            $("#hiddenDescHistorico").val($("#tbl_ReporteAvance #cbHistoricoF").find('option:selected').text());


            $("#cboLocalidadCurso").on('change', function () {
                $("#hiddenDescLocalidadCurso").val($(this).find('option:selected').text());
            });

            NoAdmin();
        });

    });
}

function setNombresAsignados() {
    //Test
    $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val("");

    $("#divControl_JerarquiaEmpleado #div-Grados select").each(function () {


        //Obtiene el id del control select
        var idSelect = $(this).attr('id');
        //Busca el valor seleccionado de id del select dinamico de empleado asignado
        var valId = $("#divControl_JerarquiaEmpleado #" + idSelect).val();

        if (valId > 0) {

            var textAsignados = $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val();
            textAsignados = textAsignados + $("#divControl_JerarquiaEmpleado #" + idSelect + " option:selected").html();
            $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val(textAsignados + "~");

            //alert($(this).attr('id'));

        }
    });
}

function cargarCombos() {
    //cargarComboLocalidad();
    cargarComboGrado();
    cargarComboClasificacion();
    //cargarComboArea();
    //cargarComboDireccion();
    cargarComboTipoCont();
    //fillCombo('#cbLocalidad', 'uiReportes/uiReporteDetalle.aspx/consultaLocalidad', null, 0)
    //fillCombo('#cbGradoF', 'uiReportes/uiReporteDetalle.aspx/consultaGrado', null, 0);
    //fillCombo('#cbClasificacionF', 'uiReportes/uiReporteDetalle.aspx/consultaClasifEmp', null, 0);
    //fillCombo('#cbAreaF', 'uiReportes/uiReporteDetalle.aspx/ListaAreas', null, 0)
    //fillCombo('#cbDireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
    //fillCombo('#cbTipoConF', 'uiReportes/uiReporteDetalle.aspx/consultaTipoCont', null, 0);
    BindDataPickers();
    CargarLocalidadesCursos();
}


function cargarComboGrado() {
    $("#CatContWrap #cbGradoF option").remove();
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteDetalle.aspx/consultaGrado',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            var res = msg.d;
            if (res != null) {
                var option = "";
                for (var i = 0; i < res.length; i++) {
                    option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
                }
                $('#CatContWrap #cbGradoF').find('option').remove().end().append(option);
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}

function cargarComboClasificacion() {

    $("#CatContWrap #cbClasificacionF option").remove();

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteDetalle.aspx/consultaClasifEmp',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            var res = msg.d;
            if (res != null) {
                var option = "";
                for (var i = 0; i < res.length; i++) {
                    option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
                }
                $('#CatContWrap #cbClasificacionF').find('option').remove().end().append(option);
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


debugger
function generarReporte() {


    if (validarForm() == false) {
        return;
    }

    var _formArray = $("#frmReporte").serializeArray();

    var Puesto = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectPuestos");
    var indice = Puesto[0];
    var TotalRegistros = indice.childElementCount;
    var strPuestos = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strPuestos += ("'" + indice[i].value + "',");
        }
    }

    var Grado = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectGrados");
    indice = Grado[0];
    TotalRegistros = indice.childElementCount;
    var strGrado = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strGrado += ("'" + indice[i].value + "',");
        }
    }

    var myJson = objectifyForm(_formArray);

    myJson["Puestos"] = strPuestos;
    myJson["Grados"] = strGrado;

    var strJson = JSON.stringify(myJson);

    showLoader2();
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteDetalle.aspx/GenerarReporte',
        data: '{ frm : ' + strJson + ' }',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg != null && msg.d != "") {
                window.open("uiComun/AuxTableToXls.aspx");
            }
            else {
                showPopup('popup', "No se encotraron resultados ", null);
                closePopup('popup2', 0);
            }
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {

            closePopup('popup2', 0);
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


function generarReporteTotales() {

    var _formArray = $("#frmReporte").serializeArray();

    var Puesto = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectPuestos");
    var indice = Puesto[0];
    var TotalRegistros = indice.childElementCount;
    var strPuestos = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strPuestos += ("'" + indice[i].value + "',");
        }
    }

    var Grado = $("#div-uiControl_Puesto_Grado #table_Puesto_Grado #selectGrados");
    indice = Grado[0];
    TotalRegistros = indice.childElementCount;
    var strGrado = '';

    for (var i = 0; i < TotalRegistros; i++) {

        if (indice[i].selected == true) {
            strGrado += ("'" + indice[i].value + "',");
        }
    }

    var myJson = objectifyForm(_formArray);

    myJson["Puestos"] = strPuestos;
    myJson["Grados"] = strGrado;

    var strJson = JSON.stringify(myJson);

    showLoader2();

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteDetalle.aspx/GeenrarReporteTotales',
        data: '{ frm : ' + strJson + ' }',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {

            if (msg != null && msg.d != "") {

                window.open("uiComun/AuxTableToXls.aspx");
            }
            else {
                showPopup('popup', "No se encotraron resultados ", null);
                closePopup('popup2', 0);
            }
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {

            closePopup('popup2', 0);
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


//function ReporteDetalle_Asignados() {

//    var _data = null;
//    var validar = validarForm();
//    var _url = 'uiReportes/uiReporteDetalle.aspx/'
//    var result = "";
//    _url = _url + 'consultarTotalCursos_EmpAsignados'

//    var NominaPadre = $("#divControl_JerarquiaEmpleado #hiddenNominaSelected").val();
//    var Id_Area = $('#cbAreaF').val();
//    var Id_Programa = $('#cbProgramaF').val();
//    var id_SubPrograma = $('').val();
//    var Id_Curso = $('#cbCursoF').val();
//    var fechaInicial = $('#TxtFechaIniF').val();
//    var fechaFinal = $('#TxtFechaFinF').val();
//    var Id_Localidad = $('#cbLocalidad').val();
//    var Estatus = $('#cbEstatus').val();
//    var Id_Clasificacion = $('#cbClasificacionF').val();
//    var Juicio = $('#cbJuicioF').val();
//    var Id_TipoCont = $('#cbTipoConF').val();
//    var Id_Evaluacion = $('#cbEvaluacionF').val();



//    if (Id_Area == null || Id_Area == undefined || Id_Area == "" || isNaN(Id_Area)) {
//        Id_Area = 0;
//    }
//    if (Id_Programa == null || Id_Programa == undefined || Id_Programa == "" || isNaN(Id_Programa)) {
//        Id_Programa = 0;
//    }
//    if (id_SubPrograma == null || id_SubPrograma == undefined || id_SubPrograma == "" || isNaN(id_SubPrograma)) {
//        id_SubPrograma = 0;
//    }
//    if (Id_Curso == null || Id_Curso == undefined || Id_Curso == "" || isNaN(Id_Curso)) {
//        Id_Curso = 0;
//    }
//    if (Id_Localidad == null || Id_Localidad == undefined || Id_Localidad == "" || isNaN(Id_Localidad)) {
//        Id_Localidad = 0;
//    }
//    if (Estatus == null || Estatus == undefined || Estatus == "" || isNaN(Estatus)) {
//        Estatus = 0;
//    }
//    if (Id_Clasificacion == null || Id_Clasificacion == undefined || Id_Clasificacion == "" || isNaN(Id_Clasificacion)) {
//        Id_Clasificacion = 0;
//    }
//    if (Juicio == null || Juicio == undefined || Juicio == "" || isNaN(Juicio)) {
//        Juicio = 0;
//    }
//    if (Id_TipoCont == null || Id_TipoCont == undefined || Id_TipoCont == "" || isNaN(Id_TipoCont)) {
//        Id_TipoCont = 0;
//    }
//    if (Id_Evaluacion == null || Id_Evaluacion == undefined || Id_Evaluacion == "" || isNaN(Id_Evaluacion)) {
//        Id_Evaluacion = 0;
//    }


//    var edit = new Array();
//    var selGrado = document.getElementById("cbGradoF");
//    for (i = 0; i < selGrado.length; i++) {
//        currentOption = selGrado[i];
//        if (currentOption.selected == true) {
//            if (result == "") {
//                result += currentOption.innerText + "-,";
//            }
//            else {
//                result += "-" + currentOption.innerText + "-,";
//            }
//        }
//        else {
//            result = result;
//        }
//    }

//    var gradod = result.substring(0, result.length - 1);



//    //var date =
//    _data = '{"NumNominaPadre":"' + NominaPadre + '","Id_Area":"' + Id_Area + '","Id_Programa":"' + Id_Programa + '","Id_SubPrograma":"' + id_SubPrograma + '","Id_Curso":"' + Id_Curso + '","FechaInicio":"' + fechaInicial + '","FechaFin":"' + fechaFinal + '","Id_Localidad":"' + Id_Localidad + '","Grado":"' + gradod + '","Estatus":"' + Estatus + '","Id_Clasificacion":"' + Id_Clasificacion + '","Juicio":"' + Juicio + '","Id_TipoContrato":"' + Id_TipoCont + '","Id_Evaluacion":"' + Id_Evaluacion + '"}';

//    showLoader2();
//    $.ajax({
//        type: 'POST',
//        url: _url,
//        data: _data,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (resultado) {
//            window.open("uiComun/AuxTableToXls.aspx");
//            closePopup('popup2', 0);
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}



function objectifyForm(formArray) {//serialize data function


    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}


function validarForm() {

    var idArea = $("#div-uiControl_Cursos #table-uiControl_Cursos #select_AreaAprendizaje").val();
    var idPrograma = $("#div-uiControl_Cursos #table-uiControl_Cursos #select_Programa").val();
    var campos = "";
    var esCorrecto = true;

    if (idArea == "" || idArea == "0" || idArea == null || isNaN(idArea)) {
        esCorrecto = false;
        campos += "<b>Area</b><br />";
    }

    if (idPrograma == "" || idPrograma == "0" || idPrograma == null || isNaN(idPrograma)) {
        esCorrecto = false;
        campos += "<b>Programa</b><br />";
    }

    if (esCorrecto == false) {
        showPopup('popup', "Los campos siguientes son requeridos, verifique por favor. <br / > " + campos, null)
        closePopup('popup2', 0);

        //$("#dialog-message").dialog({
        //    modal: true,
        //    buttons: {
        //        Ok: function () {
        //            $(this).dialog("close");
        //        }
        //    }
        //}).css("display", "block");


    }

    return esCorrecto;
}

//function cargarComboArea() {
//    $("#CatContWrap #cbAreaF option").remove();

//    $.ajax({
//        type: 'POST',
//        url: 'uiReportes/uiReporteDetalle.aspx/ListaAreas',
//        data: null,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (msg) {
//            var res = msg.d;
//            if (res != null) {
//                var option = "";
//                for (var i = 0; i < res.length; i++) {
//                    option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
//                }
//                $('#CatContWrap #cbAreaF').find('option').remove().end().append(option);
//            }
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}

//function cargarComboDireccion() {
//    $("#CatContWrap #cbDireccionF option").remove();

//    $.ajax({
//        type: 'POST',
//        url: 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel',
//        data: '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }',
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (msg) {
//            var res = msg.d;
//            if (res != null) {
//                var option = "";
//                for (var i = 0; i < res.length; i++) {
//                    option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
//                }
//                $('#CatContWrap #cbDireccionF').find('option').remove().end().append(option);
//            }
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}

function cargarComboTipoCont() {

    $("#CatContWrap #cbTipoConF option").remove();

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteDetalle.aspx/consultaTipoCont',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            var res = msg.d;
            if (res != null) {
                var option = "";
                for (var i = 0; i < res.length; i++) {
                    option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
                }
                $('#CatContWrap #cbTipoConF').find('option').remove().end().append(option);
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });

}

//-------------------


//function filtrarAreas() {


//    $("#CatContWrap #cbProgramaF option").remove();
//    $("#CatContWrap #cbSubPrograma option").remove();
//    $("#CatContWrap #cbCursoF option").remove();

//    var idArea = $("#CatContWrap #cbAreaF").val();


//    if (idArea != "" || idArea != null || idArea != undefined) {
//        var _data = '{"Id_Area":"' + idArea + '", "Id_Localidad":"0"}';

//        if (idArea > 0) {
//            $.ajax({
//                type: 'POST',
//                url: 'uiReportes/uiReporteDetalle.aspx/consultarAreaXProgramas',
//                data: _data,
//                contentType: 'application/json; charset=utf-8',
//                dataType: 'json',
//                async: false,
//                success: function (msg) {
//                    var res = msg.d;
//                    if (res != null) {
//                        var option = "";
//                        for (var i = 0; i < res.length; i++) {
//                            option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
//                        }
//                        $('#CatContWrap #cbProgramaF').find('option').remove().end().append(option);
//                    }
//                },
//                error: function (request, status, error) {
//                    if (request.status == 401) {
//                        document.location.href = "uiPublic/uiLogin.aspx";
//                    } else {
//                        alert("Se ha producido el siguiente error:" + error);
//                        closePopup('popup2', 0);
//                    }
//                }
//            });
//        }
//    }
//}


//function filtrarComboSubProgramas() {

//    var idPrograma = $("#CatContWrap #cbProgramaF").val();

//    $("#CatContWrap #cbSubPrograma option").remove();
//    $("#CatContWrap #cbCursoF option").remove();

//    if (idPrograma == "" || idPrograma == undefined || idPrograma == null || isNaN(idPrograma)) {
//        alert("Seleccione Programa");
//        return;
//    }
//    else {

//        if (idPrograma > 0) {
//            $.ajax({
//                type: 'POST',
//                url: 'uiReportes/uiReporteDetalle.aspx/obtenerSubProgramas',
//                data: '{"idPrograma":"' + idPrograma + '"}',
//                contentType: 'application/json; charset=utf-8',
//                dataType: 'json',
//                async: false,
//                success: function (msg) {
//                    var res = msg.d;
//                    if (res != null) {
//                        var option = "";
//                        for (var i = 0; i < res.length; i++) {
//                            option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
//                        }
//                        $('#CatContWrap #cbSubPrograma').find('option').remove().end().append(option);
//                    }
//                },
//                error: function (request, status, error) {
//                    if (request.status == 401) {
//                        document.location.href = "uiPublic/uiLogin.aspx";
//                    } else {
//                        alert("Se ha producido el siguiente error:" + error);
//                        closePopup('popup2', 0);
//                    }
//                }
//            });
//        }
//    }
//}


//function filtrarComboCursos() {
//    var idSubPrograma = $("#CatContWrap #cbSubPrograma").val();
//    $("#CatContWrap #cbCursoF option").remove();

//    if (idSubPrograma == "" || idSubPrograma == undefined || idSubPrograma == null || isNaN(idSubPrograma)) {
//        alert("Seleccione Sub Programa");
//        return;
//    }
//    else {

//        if (idSubPrograma > 0) {
//            $.ajax({
//                type: 'POST',
//                url: 'uiReportes/uiReporteDetalle.aspx/obtenerCursos',
//                data: '{"idSubPrograma":"' + idSubPrograma + '"}',
//                contentType: 'application/json; charset=utf-8',
//                dataType: 'json',
//                async: false,
//                success: function (msg) {
//                    var res = msg.d;
//                    if (res != null) {
//                        var option = "";
//                        for (var i = 0; i < res.length; i++) {
//                            option += '<option value="' + res[i].ID + '">' + res[i].Value + '</option>';
//                        }
//                        $('#CatContWrap #cbCursoF').find('option').remove().end().append(option);
//                    }
//                },
//                error: function (request, status, error) {
//                    if (request.status == 401) {
//                        document.location.href = "uiPublic/uiLogin.aspx";
//                    } else {
//                        alert("Se ha producido el siguiente error:" + error);
//                        closePopup('popup2', 0);
//                    }
//                }

//            });
//        }
//    }
//}



//function filtrarArea(_valor) {
//    //CSR
//    var Area = $('#cbAreaF option:selected').html()
//    if (Area != '' || Area != 'Seleccionar' || $('#cbAreaF').val() != '' || $('#cbAreaF').val() != '0') {
//        $('#vlAreaF').css('visibility', 'hidden');
//    }

//    var _data = '{"Id_Area":"' + _valor + '", "Id_Localidad":"0"}';
//    fillCombo('#cbProgramaF', 'uiReportes/uiReporteDetalle.aspx/consultarAreaXProgramas', _data, 0);
//}



//function filtrarMaterias(_valor, _select) {
//    //CSR
//    var Programa = $('#cbProgramaF option:selected').html()
//    if (Programa != '' || Programa != 'Seleccionar' || $('#cbProgramaF').val() != '' || $('#cbProgramaF').val() != '0') {
//        $('#vlProgramaF').css('visibility', 'hidden');
//    }

//    //alert('');
//    //iniciaCombos    
//    $('#cbCursoF option').remove();
//    var _data = '{ "Id_Programa": "' + _valor + '" }';
//    fillCombo('#cbCursoF', 'uiReportes/uiReporteDetalle.aspx/consultaCursoXProg', _data, 0)
//}




//function buscarLista(tipoBusqueda, callback) {
//    var _data = null;
//    var validar = validarForm();
//    var _url = 'uiReportes/uiReporteDetalle.aspx/'
//    var result = "'";
//    if (tipoBusqueda == 1) {//Todos  
//        _url = _url + 'consultarListadoEval'
//    }
//    $.ajax({
//        type: 'POST',
//        url: _url,
//        data: _data,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (resultado) {
//            $('#content > .main').load('uiReportes/uiReporteDetalle.aspx', function (response, status, xhr) {
//                fillCombo('#cbLocalidad', 'uiReportes/uiReporteDetalle.aspx/consultaLocalidad', null, 0)
//                fillCombo('#cbGradoF', 'uiReportes/uiReporteDetalle.aspx/consultaGrado', null, 0);
//                fillCombo('#cbClasificacionF', 'uiReportes/uiReporteDetalle.aspx/consultaClasifEmp', null, 0);
//                fillCombo('#cbAreaF', 'uiReportes/uiReporteDetalle.aspx/ListaAreas', null, 0)
//                fillCombo('#cbDireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
//                fillCombo('#cbTipoConF', 'uiReportes/uiReporteDetalle.aspx/consultaTipoCont', null, 0);
//                BindDataPickers();
//                if (callback && typeof (callback) === "function") {
//                    callback();
//                }
//            });
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
//            }
//        }
//    });
//}




////CSR
//function cambioCurso() {
//    var Curso = $('#cbCursoF option:selected').html()
//    if (Curso != '' || Curso != 'Seleccionar' || $('#cbCursoF').val() != '' || $('#cbCursoF').val() != '0') {
//        $('#vlCursoF').css('visibility', 'hidden');
//    }
//}

//CSR
//function cambioLocalidad() {
//    var Localidad = $('#cbLocalidad option:selected').html()
//    if (Localidad != '' || Localidad != 'Seleccionar' || $('#cbLocalidad').val() != '' || $('#cbLocalidad').val() != '0') {
//        $('#vlLocalidad').css('visibility', 'hidden');
//    }
//}

//function habilitaBotonDirectores() {
//    var direc = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
//    var _data = null;
//    var combo = document.getElementById("cbDireccionF");
//    fillCombo('#cbDireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', direc);
//    fillCombo('#cbSubdireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 2 + ', Id_Antecesor: ' + direc + '}', direc);
//    //    $('#cbGerenciaF option').remove();
//    //    $('#cbDepartamentoF option').remove();
//}

//function habilitaBotonSubDirectores() {
//    var direc = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
//    var subDirec = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
//    var comboDi = document.getElementById("cbDireccionF");
//    var comboSDi = document.getElementById("cbSubdireccionF");
//    fillCombo('#cbDireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', direc);
//    fillCombo('#cbSubdireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 2 + ', Id_Antecesor: ' + direc + '}', subDirec);
//    fillCombo('#cbGerenciaF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 3 + ', Id_Antecesor: ' + subDirec + '}', 0);
//    //    $('#cbDepartamentoF option').remove();
//}

//function habilitaBotonGerentes() {
//    var direc = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
//    var subDirec = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
//    var geren = $('#cbGerenciaF').val() == '' ? ' ' : $('#cbGerenciaF').val();
//    var comboDi = document.getElementById("cbDireccionF");
//    var comboSDi = document.getElementById("cbSubdireccionF");
//    var comboGer = document.getElementById("cbGerenciaF");
//    fillCombo('#cbDireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', direc);
//    fillCombo('#cbSubdireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 2 + ', Id_Antecesor: ' + direc + '}', subDirec);
//    fillCombo('#cbGerenciaF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 3 + ', Id_Antecesor: ' + subDirec + '}', geren);
//    fillCombo('#cbDepartamentoF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 4 + ', Id_Antecesor: ' + geren + '}', 0);
//}

function Reporte() {
    //CSR
    var validacion = ValidarFiltrosObligatorios();
    if (!validacion) {
        return false;
    }

    var _data = null;
    var validar = validarForm();
    var _url = 'uiReportes/uiReporteDetalle.aspx/'
    var result = "";
    _url = _url + 'consultarListadoEvalParametros'
    var Id_Programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();


    var Id_Area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
    // var Id_Curso = $('#cbCursoF').val() == '' ? ' ' : $('#cbCursoF').val();
    var Id_Dire = $('#cbDireccionF').val() == '' ? ' ' : $('#cbDireccionF').val();
    var Id_Subdireccion = $('#cbSubdireccionF').val() == '' ? ' ' : $('#cbSubdireccionF').val();
    var Id_Gerencia = $('#cbGerenciaF').val() == '' ? ' ' : $('#cbGerenciaF').val();
    var Id_Departamento = $('#cbDepartamentoF').val() == '' ? ' ' : $('#cbDepartamentoF').val();
    var Id_Clasificacion = $('#cbClasificacionF').val() == '' ? ' ' : $('#cbClasificacionF').val();
    var Estatus = $('#cbEstatus').val() == '' ? ' ' : $('#cbEstatus').val();
    var Juicio = $('#cbJuicioF').val() == '' ? ' ' : $('#cbJuicioF').val();
    var Id_Evaluacion = $('#cbEvaluacionF').val() == '' ? ' ' : $('#cbEvaluacionF').val();
    var Id_TipoCont = $('#cbTipoConF').val() == '' ? ' ' : $('#cbTipoConF').val();
    var fechaInicial = $('#TxtFechaIniF').val() == '' ? ' ' : $('#TxtFechaIniF').val();
    var fechaFinal = $('#TxtFechaFinF').val() == '' ? ' ' : $('#TxtFechaFinF').val();
    var Id_Localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();
    var Historico = $('#cbHistoricoF').val();

    var nominaPadre = $("#divControl_JerarquiaEmpleado #hiddenNominaSelected").val();

    var edit = new Array();
    var selGrado = document.getElementById("cbGradoF");
    for (i = 0; i < selGrado.length; i++) {
        currentOption = selGrado[i];
        if (currentOption.selected == true) {
            if (result == "") {
                result += currentOption.innerText + "-,";
            }
            else {
                result += "-" + currentOption.innerText + "-,";
            }
        }
        else {
            result = result;
        }
    }
    var gradod = result.substring(0, result.length - 1);
    var comboDi = document.getElementById("cbAreaF");


    var Id_SubPrograma = $('#cbSubPrograma').val();
    var Id_Curso = $('#cbCursoF').val();

    if (Id_SubPrograma == undefined || Id_SubPrograma == '' || Id_SubPrograma == null) {
        Id_SubPrograma = 0;
    }

    if (Id_Curso == undefined || Id_Curso == '' || Id_Curso == null) {
        Id_Curso = 0;
    }



    //var date =
    _data = '{ Id_Programa: ' + Id_Programa + ',"Id_SubPrograma":"' + Id_SubPrograma + '", Id_Area: ' + Id_Area + ' , Id_Curso: ' + Id_Curso + ' , Id_Dire: ' + Id_Dire + ' , Id_Subdireccion: ' + Id_Subdireccion + ' , Id_Gerencia: ' + Id_Gerencia + ' , Id_Departamento: ' + Id_Departamento + ' , Id_Clasificacion: ' + Id_Clasificacion + ' , Estatus: ' + Estatus + ' , Juicio: ' + Juicio + ' , Id_Evaluacion: ' + Id_Evaluacion + ' , Grado: "' + gradod + '", Area: "' + comboDi.options[comboDi.selectedIndex].innerText + '" , Id_TipoCont: ' + Id_TipoCont + ', fechaInicial: "' + fechaInicial + '", fechaFinal: "' + fechaFinal + '", Id_Localidad: ' + Id_Localidad + ', Historico: ' + Historico + ', "NominaPadre":"' + nominaPadre + '" }';

    showLoader2();
    $.ajax({
        type: 'POST',
        url: _url,
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            /*    $('#content > .main').load('uiReportes/uiReporteDetalle.aspx', function (response, status, xhr) {
                   fillCombo('#cbLocalidad', 'uiReportes/uiReporteDetalle.aspx/consultaLocalidad', null, 0)
                   fillCombo('#cbGradoF', 'uiReportes/uiReporteDetalle.aspx/consultaGrado', null, 0);
                   fillCombo('#cbClasificacionF', 'uiReportes/uiReporteDetalle.aspx/consultaClasifEmp', null, 0);
                   fillCombo('#cbAreaF', 'uiReportes/uiReporteDetalle.aspx/ListaAreas', null, 0)                
                   fillCombo('#cbDireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
                   fillCombo('#cbTipoConF', 'uiReportes/uiReporteDetalle.aspx/consultaTipoCont', null, 0);
                   BindDataPickers();*/
            window.open("uiComun/AuxTableToXls.aspx");
            /* }); */
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + " " + request.responseText);
                closePopup('popup2', 0);
            }
        }
    });
}

function ReporteDetalle() {

    var _data = null;
    var validar = validarForm();
    var _url = 'uiReportes/uiReporteDetalle.aspx/'
    var result = "";
    _url = _url + 'consultarTotalCursos'
    var Id_Programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();
    var Id_Area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();
    var Id_Curso = $('#cbCursoF').val() == '' ? ' ' : $('#cbCursoF').val();
    var Id_Clasificacion = $('#cbClasificacionF').val() == '' ? ' ' : $('#cbClasificacionF').val();
    var Estatus = $('#cbEstatus').val() == '' ? ' ' : $('#cbEstatus').val();
    var Juicio = $('#cbJuicioF').val() == '' ? ' ' : $('#cbJuicioF').val();
    var Id_Evaluacion = $('#cbEvaluacionF').val() == '' ? ' ' : $('#cbEvaluacionF').val();
    var Id_TipoCont = $('#cbTipoConF').val() == '' ? ' ' : $('#cbTipoConF').val();
    var fechaInicial = $('#TxtFechaIniF').val() == '' ? ' ' : $('#TxtFechaIniF').val();
    var fechaFinal = $('#TxtFechaFinF').val() == '' ? ' ' : $('#TxtFechaFinF').val();
    var Id_Localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();

    if (Id_Area == null || Id_Area == undefined || Id_Area == "" || isNaN(Id_Area)) {
        Id_Area = 0;
    }
    if (Id_Programa == null || Id_Programa == undefined || Id_Programa == "" || isNaN(Id_Programa)) {
        Id_Programa = 0;
    }
    if (Id_Curso == null || Id_Curso == undefined || Id_Curso == "" || isNaN(Id_Curso)) {
        Id_Curso = 0;
    }

    var edit = new Array();
    var selGrado = document.getElementById("cbGradoF");
    for (i = 0; i < selGrado.length; i++) {
        currentOption = selGrado[i];
        if (currentOption.selected == true) {
            if (result == "") {
                result += currentOption.innerText + "-,";
            }
            else {
                result += "-" + currentOption.innerText + "-,";
            }
        }
        else {
            result = result;
        }
    }

    var gradod = result.substring(0, result.length - 1);
    var comboDi = document.getElementById("cbAreaF");
    //var date =
    _data = '{ Id_Programa: ' + Id_Programa + ' , Id_Area: ' + Id_Area + ' , Id_Curso: ' + Id_Curso + ' , Id_Clasificacion: ' + Id_Clasificacion + ' , Estatus: ' + Estatus + ' , Juicio: ' + Juicio + ' , Id_Evaluacion: ' + Id_Evaluacion + ' , Grado: "' + gradod + '", Area: "' + comboDi.options[comboDi.selectedIndex].innerText + '" , Id_TipoCont: ' + Id_TipoCont + ', fechaInicial: "' + fechaInicial + '", fechaFinal: "' + fechaFinal + '", Id_Localidad: ' + Id_Localidad + ' }';

    showLoader2();
    $.ajax({
        type: 'POST',
        url: _url,
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            /*  $('#content > .main').load('uiReportes/uiReporteDetalle.aspx', function (response, status, xhr) {
                  fillCombo('#cbLocalidad', 'uiReportes/uiReporteDetalle.aspx/consultaLocalidad', null, 0)
                  fillCombo('#cbGradoF', 'uiReportes/uiReporteDetalle.aspx/consultaGrado', null, 0);
                  fillCombo('#cbClasificacionF', 'uiReportes/uiReporteDetalle.aspx/consultaClasifEmp', null, 0);
                  fillCombo('#cbAreaF', 'uiReportes/uiReporteDetalle.aspx/ListaAreas', null, 0)
                  fillCombo('#cbDireccionF', 'uiReportes/uiReporteDetalle.aspx/ConsultaOrganigramaNivel', '{Id_Nivel:' + 1 + ', Id_Antecesor: 0 }', 0);
                  fillCombo('#cbTipoConF', 'uiReportes/uiReporteDetalle.aspx/consultaTipoCont', null, 0);
                  BindDataPickers();*/

            window.open("uiComun/AuxTableToXls.aspx");
            /*});*/
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
                closePopup('popup2', 0);
            }
        }
    });
}

function BindDataPickers() {
    loadCSS('Scripts/datepicker/css/datepicker.css');
    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {
        //                    $('.TxtFechaIniF').datepicker({ format: 'dd/mm/yyyy' });
        //                    $('.TxtFechaFinF').datepicker({ format: 'dd/mm/yyyy' });


        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);



        var checkin = $('#TxtFechaIniF').datepicker({
            onRender: function (date) {
                return '';
            },
            format: 'yyyy/mm/dd', autoclose: true
        }).on('changeDate', function (ev) {

            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate());
            checkout.setValue(newDate);

            checkin.hide();
            $('#TxtFechaIniF')[0].focus();
        }).data('datepicker');

        var checkout = $('#TxtFechaFinF').datepicker({
            onRender: function (date) {
                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
            },
            format: 'yyyy/mm/dd', autoclose: true
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');

        if ($('#TxtFechaIniF').val() != '') {
            checkin.setValue($('#TxtFechaIniF').val());
        }

        if ($('#TxtFechaFinF').val() != '') {
            checkout.setValue($('#TxtFechaFinF').val());
        }


    });




}

//CSR
function ValidarFiltrosObligatorios() {
    var respuesta = true;

    var Area = $('#cbAreaF option:selected').html()
    if (Area == '' || Area == 'Seleccionar' || $('#cbAreaF').val() == '' || $('#cbAreaF').val() == '0') {
        $('#vlAreaF').css('visibility', 'visible');
        respuesta = false;
    }

    var Programa = $('#cbProgramaF option:selected').html()
    if (Programa == '' || Programa == 'Seleccionar' || $('#cbProgramaF').val() == '' || $('#cbProgramaF').val() == '0') {
        $('#vlProgramaF').css('visibility', 'visible');
        respuesta = false;
    }

    //var Curso = $('#cbCursoF option:selected').html()
    //if (Curso == '' || Curso == 'Seleccionar' || $('#cbCursoF').val() == '' || $('#cbCursoF').val() == '0') {
    //    $('#vlCursoF').css('visibility', 'visible');
    //    respuesta = false;
    //}

    //var Localidad = $('#cbLocalidad option:selected').html()
    //if (Localidad == '' || Localidad == 'Seleccionar' || $('#cbLocalidad').val() == '' || $('#cbLocalidad').val() == '0') {
    //    $('#vlLocalidad').css('visibility', 'visible');
    //    respuesta = false;
    //}

    return respuesta
}





function LimpiarCampos() {

    $("#CatContWrap #select_AreaAprendizaje").val("0");
    $("#CatContWrap #select_Programa option").remove();
    $("#CatContWrap #select_SubPrograma option").remove();
    $("#CatContWrap #select_Curso option").remove();
    $("#CatContWrap #TxtFechaIniF").val("");
    $("#CatContWrap #TxtFechaFinF").val("");

    $("#CatContWrap #select_Localidad").val("0");
    $("#CatContWrap #select_Direccion").val("0");

    $("#CatContWrap #select_Gerencia option").remove();
    $("#CatContWrap #select_Jefatura option").remove();

    $('#CatContWrap #selectPuestos option').prop('selected', false);
    $('#CatContWrap #selectGrados option').prop('selected', false);


    $("#CatContWrap #cbEstatus").val("0");
    $("#CatContWrap #cbClasificacionF").val("0");
    $("#CatContWrap #cbJuicioF").val("0");
    $("#CatContWrap #cbTipoConF").val("0");

    $("#CatContWrap #cbEvaluacionF").val("0");
    $("#CatContWrap #cbHistoricoF").val("1");

}








