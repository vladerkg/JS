﻿function GetData(callback) {
    LoadForm();
}


function setActiveOption(idOpcion)
{
    $('#accordion').accordion('option', 'active', idOpcion);

}


function selectReport(idReporte)
{
   
    $("#idReporte").text(idReporte);

    




    setActiveOption(1);

      
}

function newReport()
{
    $("#idReporte").text('');


    limpiarControles();
    setActiveOption(1);

}

function loadReportData(idReporte)
{

    var _data = '{"idReporte":"' + idReporte + '"}';
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteador.aspx/ReportById',
        data: _data,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (resultado) {
            //aqui poner todas las secciones precargadas del reporte



        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error: " + error + request.responseText);
                closePopup('popup2', 0);
            }
        }
    });



    

}


var seccionesAbiertas = [];
function limpiarControles()
{
    seccionesAbiertas = [];
}
 //CONTROLS

function LoadForm(e)  {
    $('#content > .main').load('uiReportes/uiReporteador.aspx', function (response, status, xhr) {


        $(document).ready(function () {
            LoadDataPickersConfig();
            seccionesAbiertas = [];
            //aqui inicia el formulario
            //$("#accordion").accordion();

            jQuery(document).ready(function () {
                $("#accordion").accordion({
                    heightStyle: "content",
                    activate: function (event, ui) {
                        loadSeccion($('#accordion').accordion('option', 'active'));
                    }
                    
                });
                $('.btnNavAcordion').click(function (e) {
                    e.preventDefault();
                    var delta = ($(this).is('.next') ? 1 : -1);
                    $('#accordion').accordion('option', 'active', ($('#accordion').accordion('option', 'active') + delta));

                    //loadSeccion($('#accordion').accordion('option', 'active'));
                });

                //$("#accordion").accordion("option", "disabled", true);
                $("#sortable1, #sortable2").sortable({
                    connectWith: ".connectedSortable",
                    start: function () { $(document).tooltip("destroy") },
                    stop: function () { $(document).tooltip() },
                }).disableSelection();


                $('.reportLink').click(function (e) {
                    
                    
                    selectReport($(this).attr('id'));

                });
                
                $("#txtNombre").on("change paste keyup", function () {
                    //alert($(this).val());
                    $('.reportTitle').text('"' + $(this).val() + '"' + '-');
                });

                $('#cbSourceReporte').on('change', function () {
                    return loadDatosDisponibles();
                });


            });



        });

    });
}

//LOAD FORM


///jdr googlechart

google.charts.load('current', { 'packages': ['corechart'] });
google.charts.load('current', { 'packages': ['charteditor'] });
google.charts.load('current', { 'packages': ['controls'] });

//google.charts.load("current",{ packages: ["corechart", "controls", "charteditor"] });

//google.setOnLoadCallback(loadEditor);

//google.charts.setOnLoadCallback(loadEditor);
var chartEditor = null;
var csv = null;
var view = null;
var data = null;
var gglData = [];
var imgMachineURI = "";
var newWrapper;
var wrapper;
var options;

    function getParamsAndFilters()
    {
        
        var params = [];
        
        
        var idReporte = 1;
        ///PARAMS!!!!!!!!
        $("#sortable2 .param").each(function (index) {
            var idLi = $(this).attr("id");
            var arrId = idLi.split('-');
            var Idparam = arrId[0];
            var tipo = arrId[1];

            var paramObj = {};
            paramObj.Id_parametro = Idparam;
            paramObj.tipo = tipo;
            paramObj.Id_Reporte = idReporte;
            paramObj.Valor_Where = null;
            paramObj.Pos = index;

            params.push(paramObj);
            //console.log("{Id_parametro:" + Idparam + ", tipo:" + tipo + ", Id_Reporte:" + idReporte + ", Valor_Where:null, Pos:" + index + "}");
            
        });

        ///FILTERS!!!!!
        
        $("#tbFiltros tbody tr").each(function (index) {
            debugger;
            if ($(this).find('.selectFilter').val() != null && $(this).find('.selectFilter').val() != "0") {
                
                var idLi = $(this).find('.selectFilter').val();
                var arrId = idLi.split('-');
                var Idparam = arrId[0];
                var tipo = arrId[1];
                //TODO: FORMARLO DINAMICO DEPENDIENDO DEL TIPO DE FILTRO
                var where = "";
                if ($(this).find('.selectOperator').length > 0)
                {

                    var operatorS = $(this).find('.selectOperator').val();


                    var ValorWhere = $(this).find('.txtfilter').val();

                    var ValorWhere2 = "";

                    if ($(this).find('.txtfilter').length > 1) {
                        ValorWhere2 = $(this).find('.txtfilter')[1].val();
                    }


                    var operArr = operatorS.split('-');

                    var operador = operArr[1];
                    var tipoDato = operArr[0];

                    var valoresIN = "";
                    if (operador == "IN") {
                        debugger;
                        valoresIN = "(";
                        if ($(this).find('.txtfilter').val().length > 1) {
                            var valores = $(this).find('.txtfilter').val()
                            valores.forEach(function (item, index) {
                                valoresIN += item + ", ";

                            });
                            valoresIN = valoresIN.substring(0, valoresIN.lastIndexOf(","));
                            valoresIN += ")";
                        }
                        else {
                            valoresIN = "(" + $(this).find('.txtfilter').val() + ")";
                        }

                    }

                    //FORMAR EL WHERE!


                    switch (tipoDato) {
                        case "Num":
                            where = operador + ValorWhere;
                            break;
                        case "Date":
                            switch (operador) {
                                case "Entre":
                                    where = 'BETWEEN ' + '"' + ValorWhere + '" AND ' + ' "' + ValorWhere2 + '"';
                                    break;

                                default:
                                    where = operador + '"' + ValorWhere + '"';
                                    break;
                            }
                            break;

                        case "IdCatalogo":
                            if (ValorWhere != "0") {
                                switch (operador) {
                                    case "=":
                                        where = operador + ValorWhere;
                                        break;
                                    case "IN":
                                        if (valoresIN != "")
                                            where = operador + valoresIN;
                                        break;
                                }

                            }
                            break;
                        case "Str":
                            if (ValorWhere != "0") {
                                switch (operador) {
                                    case "=":
                                        where = operador + "'" + ValorWhere + "'";
                                        break;
                                    case "LIKE":
                                        where = operador + "'%" + ValorWhere + "%'";
                                        break;
                                }

                            }
                            break;

                        case "Year":
                            where = operador + ValorWhere;
                            break;
                        case "Mes":
                            switch (operador) {
                                case "=":
                                    where = operador + ValorWhere;
                                    break;
                                case "IN":
                                    if (valoresIN != "")
                                        where = operador + valoresIN;
                                    break;
                            }
                            break;


                    }
            }
                
                if (where != "")
                {
                    var paramObj = {};
                    paramObj.Id_parametro = Idparam;
                    paramObj.tipo = tipo;
                    paramObj.Id_Reporte = idReporte;
                    paramObj.Valor_Where = where;
                    paramObj.Pos = index;

                    params.push(paramObj);

                }
                



                //console.log("{Id_parametro:" + Idparam + ", tipo:" + tipo + ", Id_Reporte:" + idReporte + ", Valor_Where:null, Pos:" + index + "}");
            }
        });

       

        
        var resObj = {};
        resObj.filtros = params;
        resObj.tipo_repo = 1;
        //var res = JSON.stringify(resObj);
        
        //return res;
        return resObj;
    }


    function loadGrafica() {
 debugger
        //        // Create our data table out of JSON data loaded from server.
        var datag = new google.visualization.arrayToDataTable(gglData);
  view = new google.visualization.DataView(datag);
        if (datag.wg[2] != undefined) {
           
          
            view.setColumns([0, 1, {
                calc: 'stringify',
                role: 'annotation',
                sourceColumn: 1,

                type: 'string'
            }
            , 2, {
                calc: 'stringify',
                role: 'annotation',
                sourceColumn: 2,

                type: 'string'
            }
            //,3, {
            //    calc: 'stringify',
            //    role: 'annotation',
            //    sourceColumn: 3,

            //    type: 'string'
            //}, 4, {
            //    calc: 'stringify',
            //    role: 'annotation',
            //    sourceColumn: 4,

            //    type: 'string'
            //}
            ]);
        }
        else
        {
          
            view.setColumns([0, 1, {
                calc: 'stringify',
                role: 'annotation',
                sourceColumn: 1,

                type: 'string'
            }
            ]);
        }

        if (datag.wg[2] != undefined) {
            var options = {
                title: 'Reportes de Avance',
                vAxis: { title: datag.wg[1].label + ' / ' + datag.wg[2].label },
                hAxis: { title: datag.wg[0].label },
                selectionMode: 'multiple',
                // Trigger tooltips
                // on selections.
                tooltip: { trigger: 'selection' },
                // Group selections
                // by x-value.
                aggregationTarget: 'category',
                seriesType: 'bars',
                series: { 1: { type: 'line' }, 3: { type: 'line' } },
                //   role:{1:{},3:{}}, 
                animation: {
                    duration: 1000,
                    easing: 'out'
                },

            };
        }
        else {
            var options = {
                title: 'Reportes de Avance',
                vAxis: { title: datag.wg[1].label },
                hAxis: { title: datag.wg[0].label },
                selectionMode: 'multiple',
                // Trigger tooltips
                // on selections.
                tooltip: { trigger: 'selection' },
                // Group selections
                // by x-value.
                aggregationTarget: 'category',
                seriesType: 'bars',
                series: { 1: { type: 'line' }, 3: { type: 'line' } },
                //   role:{1:{},3:{}}, 
                animation: {
                    duration: 1000,
                    easing: 'out'
                },

            };

        }
        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
        chart.draw(view, options);


        var table = new google.visualization.Table(document.getElementById('arrowformat_div'));
        csv = google.visualization.dataTableToCsv(datag);
        console.log(csv);

        var formatter = new google.visualization.ArrowFormat();
        formatter.format(datag, 1); // Apply formatter to second column

        table.draw(datag, { allowHtml: true, showRowNumber: true });



        document.getElementById("idimage").src = chart.getImageURI();
        removeLoader();
    }
    //    });


    function convertURIToImageData(URI) {
        return new Promise(function (resolve, reject) {
            if (URI == null) return reject();
            var canvas = document.createElement('canvas'),
                context = canvas.getContext('2d'),
                image = new Image();
            image.addEventListener('load', function () {
                canvas.width = image.width;
                canvas.height = image.height;
                context.drawImage(image, 0, 0, canvas.width, canvas.height);
                resolve(context.getImageData(0, 0, canvas.width, canvas.height));
            }, false);
            image.src = URI;
        });
    }
    //var URI = 
    //convertURIToImageData(URI).then(function (imageData) {
    //    // Here you can use imageData
    //    console.log(imageData);
    //});




    function loadTabla() {
        var data = JSON.stringify(getParamsAndFilters());
        $('#idimage')[0].style.visibility = "hidden";
        gglData = [];
        //console.log(data);
        $.ajax({
            type: "POST",
            url: "uiReportes/uiReporteador.aspx/reporte_avance",
            //data: '{filtros: [ {Id_parametro: 1, tipo: 2, Id_Reporte: 1, Valor_Where:"IN(2017,2016)", Pos:0},    {Id_parametro: 4, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:1 },    {Id_parametro: 3, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:3},    {Id_parametro: 5, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:2},    {Id_parametro: 6, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:4},    {Id_parametro: 7, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:5}    ], tipo_repo:11 }',
            data: data,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            //async: false,
            success: function (jsondata) {
                debugger
                var jsonn = $.parseJSON(jsondata.d);


                if (jsonn.length > 0) {
                    // load column headings
                    var colHead = [];
                    Object.keys(jsonn[0]).forEach(function (key) {
                        colHead.push(key);
                    });
                    gglData.push(colHead);

                    // load data rows
                    jsonn.forEach(function (row) {
                        var gglRow = [];
                        Object.keys(row).forEach(function (key) {
                            gglRow.push(row[key]);
                        });
                        gglData.push(gglRow);
                    });
                }
                else {
                    removeLoader();
                    showPopup('popup', "No se encotraron resultados ", null);
                }
                

                
                // Create our data table out of JSON data loaded from server.
                var datag = new google.visualization.arrayToDataTable(gglData);

               
                view = new google.visualization.DataView(datag); 
                if (datag.wg[2] != undefined) {
                    view.setColumns([0, 1, {
                        calc: 'stringify',
                        role: 'annotation',
                        sourceColumn: 1,

                        type: 'string'
                    }
                    , 2, {
                        calc: 'stringify',
                        role: 'annotation',
                        sourceColumn: 2,

                        type: 'string'
                    }
                    //,3, {
                    //    calc: 'stringify',
                    //    role: 'annotation',
                    //    sourceColumn: 3,

                    //    type: 'string'
                    //}, 4, {
                    //    calc: 'stringify',
                    //    role: 'annotation',
                    //    sourceColumn: 4,

                    //    type: 'string'
                    //}
                    ]);

                }
                else
                    {
                    view.setColumns([0, 1, {
                        calc: 'stringify',
                        role: 'annotation',
                        sourceColumn: 1,

                        type: 'string'
                    }
                    ]);
                }

                if (datag.wg[2] != undefined) {
                    var options = {
                        title: 'Reporte de Avance',
                        vAxis: { title: colHead[1] + ' / ' + datag.wg[2].label },
                        hAxis: { title: colHead[0] },
                        seriesType: 'bars',
                        selectionMode: 'multiple',
                        // Trigger tooltips
                        // on selections.
                        tooltip: { trigger: 'selection' },
                        // Group selections
                        // by x-value.
                        aggregationTarget: 'category',
                        series: { 1: { type: 'line' }, 3: { type: 'line' } },
                        //   role:{1:{},3:{}}, 
                        animation: {
                            duration: 1000,
                            easing: 'out'
                        },
                        'width': 600,
                        'height': 400

                    };
                }
                else {
                    var options = {
                        title: 'Reporte de Avance',
                        vAxis: { title: colHead[1] } ,
                        hAxis: { title: colHead[0] },
                        seriesType: 'bars',
                        selectionMode: 'multiple',
                        // Trigger tooltips
                        // on selections.
                        tooltip: { trigger: 'selection' },
                        // Group selections
                        // by x-value.
                        aggregationTarget: 'category',
                        series: { 1: { type: 'line' }, 3: { type: 'line' } },
                        //   role:{1:{},3:{}}, 
                        animation: {
                            duration: 1000,
                            easing: 'out'
                        },
                        'width': 600,
                        'height': 400

                    };
                }
                // Instantiate and draw our chart, passing in some options.
                //     var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
                //     chart.draw(view, options);

                // Some raw data (not necessarily accurate)
                //var data = google.visualization.arrayToDataTable([
                // ['Month', 'A1', 'A2', 'CIVAC', 'Motor', 'Toluca', 'Objetivo'],
                // ['2004/05', 165, 938, 522, 998, 450, 1614.6],
                // ['2005/06', 135, 1120, 599, 1268, 288, 1682],
                // ['2006/07', 157, 1167, 587, 807, 397, 1623],
                // ['2007/08', 139, 1110, 615, 968, 215, 1609.4],
                // ['2008/09', 136, 691, 629, 1026, 366, 1569.6]
                //]);


                var table = new google.visualization.Table(document.getElementById('arrowformat_div'));
                csv = google.visualization.dataTableToCsv(datag);
                console.log(csv);

                var formatter = new google.visualization.ArrowFormat();
                formatter.format(datag, 1); // Apply formatter to second column

                table.draw(datag, { allowHtml: true, showRowNumber: true });


                wrapper = new google.visualization.ChartWrapper({
                    'chartType': 'ColumnChart',
                    'dataTable': view,
                    'options': options
                });


                chartEditor = new google.visualization.ChartEditor();
                google.visualization.events.addListener(wrapper, 'ready', readyWrapper);
                google.visualization.events.addListener(chartEditor, 'ok', redrawChart);
                wrapper.draw(document.getElementById('chart_div'));


                //var wrapper = new google.visualization.ChartWrapper({
                //    'chartType': 'ColumnChart',
                //    'dataTable': view,
                //    'options': options
                //});


                //chartEditor = new google.visualization.ChartEditor();
                //google.visualization.events.addListener(chartEditor, 'ok', redrawChart);
                //chartEditor.openDialog(wrapper, {});
                //document.getElementById("idimage").src = chart.getImageURI();
                removeLoader();
            },
            error: function (request, status, error) {

                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }
        });


        function convertURIToImageData(URI) {
            return new Promise(function (resolve, reject) {
                if (URI == null) return reject();
                var canvas = document.createElement('canvas'),
                    context = canvas.getContext('2d'),
                    image = new Image();
                image.addEventListener('load', function () {
                    canvas.width = image.width;
                    canvas.height = image.height;
                    context.drawImage(image, 0, 0, canvas.width, canvas.height);
                    resolve(context.getImageData(0, 0, canvas.width, canvas.height));
                }, false);
                image.src = URI;
            });
        }
        //var URI = 
        //convertURIToImageData(URI).then(function (imageData) {
        //    // Here you can use imageData
        //    console.log(imageData);
        //});


    }

    function Editargraf() {
        //var options = {
        //    title: 'Consumo de Cafe por Planta',
        //    vAxis: { title: 'Tazas' },
        //    hAxis: { title: 'Mes' },
        //    seriesType: 'bars',
        //    series: { 1: { type: 'line' }, 3: { type: 'line' } },
        //    //   role:{1:{},3:{}}, 
        //    animation: {
        //        duration: 1000,
        //        easing: 'out'
        //    },

        //};






        //chartEditor = new google.visualization.ChartEditor();
        //google.visualization.events.addListener(chartEditor, 'ok', redrawChart);
        //  chartEditor.openDialog(wrapper, {});
        // document.getElementById("idimage").src = chart.getImageURI();
    }


    function graficapng() {
        $('#idimage')[0].style.visibility = "visible";
        // Instantiate and draw our chart, passing in some options.
        //   var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
        // chart.draw(view, options);

    }

    function loadEditor() {
        var data = JSON.stringify(getParamsAndFilters());
        //console.log(data);
        $.ajax({
            type: "POST",
            url: "uiReportes/uiReporteador.aspx/reporte_avance",
            //data: '{filtros: [ {Id_parametro: 1, tipo: 2, Id_Reporte: 1, Valor_Where:"IN(2017,2016)", Pos:0},    {Id_parametro: 4, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:1 },    {Id_parametro: 3, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:3},    {Id_parametro: 5, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:2},    {Id_parametro: 6, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:4},    {Id_parametro: 7, tipo: 1, Id_Reporte: 1, Valor_Where:null , Pos:5}    ], tipo_repo:11 }',
            data: data,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            //async: false,
            success: function (jsondata) {

                var jsonn = $.parseJSON(jsondata.d);

                var gglData = [];
                if (jsonn.length > 0) {
                    // load column headings
                    var colHead = [];
                    Object.keys(jsonn[0]).forEach(function (key) {
                        colHead.push(key);
                    });
                    gglData.push(colHead);

                    // load data rows
                    jsonn.forEach(function (row) {
                        var gglRow = [];
                        Object.keys(row).forEach(function (key) {
                            gglRow.push(row[key]);
                        });
                        gglData.push(gglRow);
                    });
                }

                // Create our data table out of JSON data loaded from server.
                var data = new google.visualization.arrayToDataTable(gglData);


                view = new google.visualization.DataView(data);
                view.setColumns([0, 1, {
                    calc: 'stringify',
                    role: 'annotation',
                    sourceColumn: 1,

                    type: 'string'
                }
                , 2, {
                    calc: 'stringify',
                    role: 'annotation',
                    sourceColumn: 2,

                    type: 'string'
                }
                //,3, {
                //    calc: 'stringify',
                //    role: 'annotation',
                //    sourceColumn: 3,

                //    type: 'string'
                //}, 4, {
                //    calc: 'stringify',
                //    role: 'annotation',
                //    sourceColumn: 4,

                //    type: 'string'
                //}
                ]);


                //var options = {
                //    title: 'Consumo de Cafe por Planta',
                //    vAxis: { title: 'Tazas' },
                //    hAxis: { title: 'Mes' },
                //    seriesType: 'bars',
                //    series: { 1: { type: 'line' }, 3: { type: 'line' } },
                //    //   role:{1:{},3:{}}, 
                //    animation: {
                //        duration: 1000,
                //        easing: 'out'
                //    },

                //};
                // Instantiate and draw our chart, passing in some options.
                var chart = new google.visualization.ColumnChart(document.getElementById('chart_div'));
                chart.draw(view, options);

                // Some raw data (not necessarily accurate)
                //var data = google.visualization.arrayToDataTable([
                // ['Month', 'A1', 'A2', 'CIVAC', 'Motor', 'Toluca', 'Objetivo'],
                // ['2004/05', 165, 938, 522, 998, 450, 1614.6],
                // ['2005/06', 135, 1120, 599, 1268, 288, 1682],
                // ['2006/07', 157, 1167, 587, 807, 397, 1623],
                // ['2007/08', 139, 1110, 615, 968, 215, 1609.4],
                // ['2008/09', 136, 691, 629, 1026, 366, 1569.6]
                //]);


                var table = new google.visualization.Table(document.getElementById('arrowformat_div'));
                csv = google.visualization.dataTableToCsv(data);
                console.log(csv);

                var formatter = new google.visualization.ArrowFormat();
                formatter.format(data, 1); // Apply formatter to second column

                table.draw(data, { allowHtml: true, showRowNumber: true });


                var wrapper = new google.visualization.ChartWrapper({
                    'chartType': 'ColumnChart',
                    'dataTable': view,
                    'options': options
                });


                chartEditor = new google.visualization.ChartEditor();
                google.visualization.events.addListener(chartEditor, 'ok', redrawChart);
                chartEditor.openDialog(wrapper, {});
                document.getElementById("idimage").src = chart.getImageURI();
                removeLoader();
            }
        });


        function convertURIToImageData(URI) {
            return new Promise(function (resolve, reject) {
                if (URI == null) return reject();
                var canvas = document.createElement('canvas'),
                    context = canvas.getContext('2d'),
                    image = new Image();
                image.addEventListener('load', function () {
                    canvas.width = image.width;
                    canvas.height = image.height;
                    context.drawImage(image, 0, 0, canvas.width, canvas.height);
                    resolve(context.getImageData(0, 0, canvas.width, canvas.height));
                }, false);
                image.src = URI;
            });
        }
        //var URI = 
        //convertURIToImageData(URI).then(function (imageData) {
        //    // Here you can use imageData
        //    console.log(imageData);
        //});


    }

    // On "OK" save the chart to a <div> on the page.
   
    


    function redrawChart() {
      //  console.info('redrawChart');
        // Remove the old listener.
        //google.visualization.events.removeListener(wrapper,
        //                                           'ready');
        wrapper = chartEditor.getChartWrapper();
        google.visualization.events.addListener(wrapper, 'ready', readyWrapper);
        wrapper.draw(document.getElementById('chart_div'));

    }


    function readyWrapper() {
        console.log("readyWrapper New");
        var imgMachineURI = wrapper.getChart().getImageURI();
        document.getElementById("idimage").src =imgMachineURI;

    }

    function readyNewWrapper() {
        console.log("readyWrapper New");
        var imgMachineURI = newWrapper.getChart().getImageURI();
        document.getElementById("idimage").src = imgMachineURI;

    }

   // function redrawChart() {
   //    debugger
   //     chartEditor.getChartWrapper().draw(document.getElementById('chart_div'));
   //     google.visualization.events.addListener(chartEditor.getChartWrapper(), 'ready', function () {  document.getElementById("idimage").src = chartEditor.getChartWrapper().getChart().getImageURI(); });
    
   ////     alert(chart.getImageURI());
   //   //  document.getElementById("idimage").src=chartEditor.getChartWrapper().getChart().getImageURI();
   //     //document.getElementById("idimage").src = chart.getImageURI();
        
   // }
    function newTabImage() {
        var image = new Image();
        image.src = $('#idimage').attr('src');

        var w = window.open("", '_blank');
        w.document.write(image.outerHTML);
        w.document.close();
    }
    function downloadCSV() {
        var data, filename, link;

        if (csv == null) return;

        filename = 'export.csv';

        if (!csv.match(/^data:text\/csv/i)) {
            csv = 'data:text/csv;charset=utf-8,' + csv;
        }
        data = encodeURI(csv);

        link = document.createElement('a');
        link.setAttribute('href', data);
        link.setAttribute('download', filename);
        link.click();
    }
    function showData()
    {
        table.draw(data, { allowHtml: true, showRowNumber: true });

    }

    //GOOGLE CHART
    
    function removeLoader()
    {
        closePopup('popup2', 0);
    }
    function loadSeccion(numSec) {
        showLoader2();
        var idReporte = $("#idReporte").text();
        
        

        
        var isFirstTimeInSeccion = (!seccionesAbiertas.includes(numSec));
        if (isFirstTimeInSeccion)
            seccionesAbiertas.push(numSec);

       

        switch (numSec) {

            case 0:
                removeLoader();//si utiliza ajax remover y poner en success
                break;

            case 1:
                DatosGenerales(idReporte, isFirstTimeInSeccion);
                removeLoader();//si utiliza ajax remover y poner en success
                break;


            case 2: //DATOS DISPONBILES
                DatosDisponibles(idReporte, isFirstTimeInSeccion);

                break;

            case 3: //FILTROS
                Filtros(idReporte, isFirstTimeInSeccion);
                removeLoader();//si utiliza ajax remover y poner en success
                break;
            case 4: //RESULTADOS
                Resultados();
                break;
            case 5:
                Graficos();
               // removeLoader();//si utiliza ajax remover y poner en success
                break;


            default:
           
        }
        //closePopup('popup2', 0);


    }
    //2
    function DatosDisponibles(idReporte, isFirstTimeInSeccion)
    {
        if (isFirstTimeInSeccion)//primera vez cargar datos default
        {
            loadCbSourceReporte();
        }
        else
        {
            removeLoader();//si utiliza ajax remover y poner en success
        }
        if (idReporte)
        {
            //alert('DATOS DISPONBILES' + idReporte);
        }

        else
        {

        }
    }

    //3
    function Filtros(idReporte, isFirstTimeInSeccion) {
        //alert('FILTROS');

        //tbFiltros
        //aqui pintar la tabla de filtros
        //loadtbFiltros();
    }
    //4
    function Resultados()
    {
        loadTabla();

    }
    function Graficos() {
        loadGrafica();

    }//STEPS**



    function DatosGenerales(idReporte, isFirstTimeInSeccion)
    {
       
        if (idReporte)
        {
            //alert('Datos generales de reporte: ' + idReporte);
            //dato fijo
            if (idReporte == '2b3108f8-3463-49e2-b94f-018dc1ba7a1a') {
                $('#txtNombre').val('Reporte General de Capacitación');
                $('.reportTitle').text('"Reporte General de Capacitación"' + '-');
            }
            else
            {
                    $('.reportTitle').text('""' + '-');
                    $('#txtNombre').val('');
            }


            

            
            

        }
        else
        {
            //limpios
            $('.reportTitle').text('Nuevo Reporte' + '-');

        }
        

    }

    function createControlsByDataType(select)
    {
        
        var opcion = $(select).val();
        
       

        // alert('tipo de dato: ' + opcion);
        
        
        var tdControls = $(select).parent().parent().find('.OperatorControls');
        if (opcion != "0")
        {
            var arrDatos = opcion.split('-');
            var tipo = arrDatos[2];
            var idParametro = arrDatos[0];
            debugger;
            var idPadre = arrDatos[3];
            var valorWhere="";
            
            if(idPadre!="0")
            {
                var filtrosAndParams = getParamsAndFilters();
                var filtros = filtrosAndParams.filtros;

                //console.log(filtros);

                var res= filtros.find(x => x.Id_parametro === idPadre);
              
                if(res)
                {
                   // console.log(res);
                    valorWhere=res.Valor_Where;
                }
                else
                {
                    var NombrePadre = arrDatos[4];
                    alert('Debe agregar ' + NombrePadre);
                    $(select).val(0);
                    tdControls.html('');
                    return false;
                }
                
                
            }
            


            var htmlControls = '';


            //OPERADORES
            var operators = [];

            switch (tipo)
            {
                case 'Num':
                    operators = ["=",">","<", ">=", "<="];
                    break;
                case 'IdCatalogo':
                    operators = ["=","IN"];
                    break;
                case 'Date':
                    operators = ["=", ">", "<", ">=", "<=", "Entre"];
                    break;
                case "Str":
                    operators = ["=", "LIKE"];
                    break;
                case 'Year':
                    operators = ["=", ">", "<", ">=", "<="];
                    break;
                case 'Mes':
                    operators = ["=", "IN"];
                    break;

            }

            var mySelect = document.createElement("select");
            mySelect.style = "width:200px";
            mySelect.className = "selectOperator"
            var option = document.createElement("option");

            ////DEFAULT 0-seleccionar
            //option.value = 0;
            //option.text = "Seleccionar Campo";
            //mySelect.appendChild(option);

            for (var i = 0; i < operators.length; i++) {
                //$('#sortable1').append('<ul class="ui-state-default li-sort param " id="' + res[i].Id_parametro + '-' + res[i].tipo + '" >' + res[i].NombreMostrar + '</ul>');
                option = document.createElement("option");
                option.value = tipo + '-' + operators[i] + '-' + idParametro;
                //option.text = operators[i];
                option.text = cambiaXLenguajeVianney(operators[i]);
                mySelect.appendChild(option);
                option = null;
            }
            debugger;
            mySelect.setAttribute("onchange", "controlsByOperator($(this),"+ idPadre +",'" + valorWhere + "')");
            htmlControls = mySelect.outerHTML;

            tdControls.html(htmlControls);

            $(select).parent().parent().find(".selectOperator").trigger('change');

            //if (tipo=="Date")
            //    BindDatePicker($(select).parent().parent().find('#dpicker1'));
            
            

        }
        else
        {
            tdControls.html('');
        }
    }
    function cambiaXLenguajeVianney(operador)
    {
        var traduccion = '';
        switch (operador)
        {
            case '=':
                traduccion = 'IGUAL A';
                break;
            case '>':
                traduccion = 'MAYOR A';
                break;
            case '>=':
                traduccion = 'MAYOR O IGUAL A';
                break;
            case '<':
                traduccion = 'MENOR A';
                break;
            case '<=':
                traduccion = 'MENOR O IGUAL A';
                break;
            case 'IN':
                traduccion = 'VARIOS';
                break;
            case 'LIKE':
                traduccion = 'COINCIDE CON';
                break;
                


            default:
                traduccion = operador;
        }

        return traduccion;

    }
    function controlsByOperator(selectOperator,idPadre,valorwhere)
    {

        var opcion = $(selectOperator).val();
        var tdControls = $(selectOperator).parent().parent().find('.ValuesControls');
        if (opcion != "0") {
            var opcionArr = opcion.split('-');
            var tipoDato = opcionArr[0];
            var operador = opcionArr[1];
            var idParametro = opcionArr[2];

            var htmlControls = '';
            switch (tipoDato) {
                case 'Num':
                    switch (operador)
                    {
                        case "=": case ">": case "<": case ">=": case "<=":
                            htmlControls = '<input type="number" class="txtfilter" ></input>';
                            break;
                    }
                   
                    // htmlControls = '<select class="' + tipo + '" onchange="controlsByOperator("Num",$(this).val())"><option value="=">=</option><option value="IN">IN</option>  </select>';

                    break;
                case 'IdCatalogo':
                    switch (operador) {
                        case "=":
                            htmlControls = '<select  class="txtfilter" id="catFilter" ></select>';
                            break;
                        case "IN":
                            htmlControls = '<select multiple class="txtfilter" id="catFilter" ></select>';
                            break;
                    }
                    break;
                case 'Date':
                    switch (operador)
                    {
                        case "=": case ">": case "<": case ">=": case "<=":
                            htmlControls = '<input type="text" class="txtfilter datepicker" id="dpicker1" ></input>';
                            break;
                        case "Entre":
                            htmlControls = '<label for="dpicker1">DE:</label><input type="text" class="txtfilter datepicker" id="dpicker1" ></input><label for="dpicker2">HASTA:</label><input type="text" class="txtfilter datepicker" id="dpicker2" ></input>';
                            break;
                    }
                    
                    break;
                case 'Str':
                    switch (operador) {
                        case "=": case "LIKE": 
                            htmlControls = '<input type="text" class="txtfilter" ></input>';
                            break;
                    }
                    break;
                case 'Year':
                    switch (operador) {
                        case "=": case ">": case "<": case ">=": case "<=":
                            htmlControls = '<input type="number" class="txtfilter" ></input>';
                            break;
                    }
                    break;
                case 'Mes':
                    switch (operador) {
                        case "=": 
                            htmlControls = '<select  class="txtfilter" id="catMonths" ></select>';
                            break;
                        case "IN":
                            htmlControls = '<select multiple  class="txtfilter" id="catMonths" ></select>';
                            break;
                    }
                    break;

            }

            tdControls.html(htmlControls);
            if (tipoDato=="IdCatalogo")
            {
                loadSelectByCatalog($(selectOperator).parent().parent().find('#catFilter'),idParametro,idPadre,valorwhere);
            }

            if (tipoDato == "Date")
            {
                BindDatePicker($(selectOperator).parent().parent().find('#dpicker1'));
                if (operador == "Entre")
                    BindDatePicker($(selectOperator).parent().parent().find('#dpicker2'));
            }
            if (tipoDato == "Mes") {
                loadSelectMonths($(selectOperator).parent().parent().find('#catMonths'));
            }

        }
        else {
            tdControls.html('');
        }

        


        //alert('tipo ' + tipoDato + ' operador: ' + opcion);

        //alert('tipo ' + tipoDato + ' operador: ' + Operator);

    }
    
    function loadSelectByCatalog(select, idCampo,IdPadre,valorwhere)
    {
        //alert(' Aqui cargando el combo: ' + idCampo);
        debugger;
        $(select).find("option").remove();
        var _data='{ParamId:' + idCampo + '}';
        var _url="uiReportes/uiReporteador.aspx/"
        if (IdPadre && valorwhere)
        {
            _data='{ParamId:' + idCampo  +',IdPadre:'+IdPadre  +',ValorWhere:"'+ valorwhere+ '"}';
            _url+="obtenerCatalogoByParametroWithFilter"
        }
        else
        {
            _url+="obtenerCatalogoByParametroId";
        }
        $.ajax({
            type: 'POST',
            //url: 'uiReportes/uiReporteador.aspx/obtenerCatalogoByParametroId',
            url:_url,
            //data: '{ParamId:' + idCampo + '}',
            data: _data,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (msg) {
                var res = msg.d;
                if (res != null) {
                    for (var i = 0; i < res.length; i++) {
                        $(select).append('<option value="' + res[i].ID + '" title="' + res[i].Extra + '">' + res[i].Value + '</option>');
                    }
                }
                //removeLoader();
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }
        });

    }
    
    function loadSelectMonths(select) {
        //alert(' Aqui cargando el combo: ' + idCampo);
        $(select).find("option").remove();

        var Meses = [
           { ID: "1", Value: "Enero" },
           { ID: "2", Value: "Febrero" },
           { ID: "3", Value: "Marzo" },
           { ID: "4", Value: "Abril" },
           { ID: "5", Value: "Mayo" },
           { ID: "6", Value: "Junio" },
           { ID: "7", Value: "Julio" },
           { ID: "8", Value: "Agosto" },
           { ID: "9", Value: "Septiembre" },
           { ID: "10", Value: "Octubre" },
           { ID: "11", Value: "Noviembre" },
           { ID: "12", Value: "Diciembre" },

        ];
        for (var i = 0; i < Meses.length; i++) {
            $(select).append('<option value="' + Meses[i].ID + '" >' + Meses[i].Value + '</option>');
        }


    }
    
    function LoadDataPickersConfig() {
        loadCSS('Scripts/datepicker/css/datepicker.css');
        $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {
            return true;
        });
    }

    function BindDatePicker(elemento) {
        //var nowTemp = new Date();
        //var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);
        $(elemento).datepicker({ format: 'dd/mm/yyyy', autoclose: true }).on('changeDate', function (ev) {
            $(this).datepicker('hide');
        });

    }
    

    function addFilter()
    {
        //obtener options de select en base a campos registrados, filtrable=1
        
        var source = $('#cbSourceReporte').val();
        if (source==null ||source == "0")
            return false;

        //si se ha seleccionado un source 
        $.ajax({
            type: 'POST',
            url: 'uiReportes/uiReporteador.aspx/obtenerFiltersBySourceId',
            data: '{sourceId:' + source + '}',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (msg) {
                
                var res = msg.d;
                if (res != null) {
                    var mySelect = document.createElement("select");
                    mySelect.style = "width:100%";
                    mySelect.className = "selectFilter"
                    var option = document.createElement("option");

                    //DEFAULT 0-seleccionar
                    option.value = 0;
                    option.text = "Seleccionar Campo";
                    mySelect.appendChild(option);

                    for (var i = 0; i < res.length; i++) {
                        //$('#sortable1').append('<ul class="ui-state-default li-sort param " id="' + res[i].Id_parametro + '-' + res[i].tipo + '" >' + res[i].NombreMostrar + '</ul>');
                        option = document.createElement("option");
                        option.value = res[i].Id_parametro + '-' + res[i].tipo + '-' + res[i].tipoDato + '-' + res[i].FiltroPadre + '-' + res[i].PadreMostrar;
                        option.text = res[i].NombreMostrar;
                        mySelect.appendChild(option);
                        option = null;
                    }


                    //CREAR CONTROLES DE FILTROS
                    //depende del valor del select obtener el tipo de controles
                    mySelect.setAttribute("onchange", "createControlsByDataType($(this))");
                    var newRow = '<tr><td>' + mySelect.outerHTML + '</td><td class="Filter_Controls"><div style="display:inline-block" class="OperatorControls"></div><div style="display:inline-block" class="ValuesControls"></div></td><td><a href="#" class="remove_filter">Remover</a></td></tr>';
                    //add tr to table 
                    $("#tbFiltros").append(newRow);

                   

                    $(".remove_filter").click(function (e) { //user click on remove text        

                        e.preventDefault(); $(this).parent().closest('tr').remove();
                    });

                }
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }
        });



        //var mySelect = document.createElement("select");
        //mySelect.style = "width:100%";
        //mySelect.class = "selectValid"
        //var arr = [
        //          { val: 1, text: 'Area de Aprendizaje' },
        //          { val: 2, text: 'Programa' },
        //          { val: 3, text: 'Subprograma' }
        //                ];

       
        //var option = document.createElement("option");
        //$(arr).each(function () {
        //    option = document.createElement("option");
        //    option.value = this.val;
        //    option.text = this.text;
        //    mySelect.appendChild(option);
        //    option = null;

        //});

        //depende del tipo de dato 
        


        // en evento de change de select
        //formar input de valor para filtro, puede ser una lista para seleccionar varios:
        // catalogo: (consultar catalogo de bd)
        // fecha: input de calendario
        // between: doble input 
        // 








        


    }

    function loadtbFiltros() {
        

    }

    function loadDatosDisponibles()
    {
        //SELECT DE SOURCE REPORTE

    }

    function loadCbSourceReporte()
    {
            $('#cbSourceReporte option').remove();

            $.ajax({
                type: 'POST',
                url: 'uiReportes/uiReporteador.aspx/obtenerSourcesReporte',
                data: null,
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function (msg) {
                    var res = msg.d;
                    if (res != null) {
                        for (var i = 0; i < res.length; i++) {
                            $("#cbSourceReporte").append('<option value="' + res[i].ID + '" title="'+res[i].Extra +'">' + res[i].Value + '</option>');
                        }
                    }
                    removeLoader();
                },
                error: function (request, status, error) {
                    if (request.status == 401) {
                        document.location.href = "uiPublic/uiLogin.aspx";
                    } else {
                        alert("Se ha producido el siguiente error:" + error);
                        closePopup('popup2', 0);
                    }
                }
            });
        
        
    }

    function loadDatosDisponibles()
    {
        $('#sortable1').empty();
        $('#sortable2').empty();
        $("#tbFiltros tbody").empty();
        var source = $('#cbSourceReporte').val();
        if (source == "0")
            return false;

        //si se ha seleccionado un source 
        $.ajax({
            type: 'POST',
            url: 'uiReportes/uiReporteador.aspx/obtenerDatosDisponiblesBySourceId',
            data: '{sourceId:' + source + '}',
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (msg) {
                var res = msg.d;
                if (res != null) {
                    for (var i = 0; i < res.length; i++) {
                        $('#sortable1').append('<li class="ui-state-default li-sort param " id="' + res[i].Id_parametro + '-' + res[i].tipo + '" title="'  + res[i].Descripcion +'" >' + res[i].NombreMostrar + '</li>');
                        
                        //$("#cbSourceReporte").append('<option value="' + res[i].ID + '" title="' + res[i].Extra + '">' + res[i].Value + '</option>');
                    }
                    $("#sortable1").sortable("refresh");
                }
                $(document).tooltip({
                    show: {
                        effect: "puff",
                        //percent: 50,
                        delay: 150
                    },
                    track: true,
                    close: function (event, ui) {$('.ui-effects-wrapper').remove(); }

                });
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error);
                    closePopup('popup2', 0);
                }
            }
        });


        



    }
    debugger
    function editMe() {
        chartEditor.openDialog(wrapper, {});
    }
