﻿/// <reference path="../JQuery/jquery-1.10.4/jquery-1.10.2.js" />
function GetData(callback) {
    loadForm();
}


function loadForm() {
    $('#content > .main').load('uiReportes/uiReporteInstructores.aspx', function (response, status, xhr) {

        $(document).ready(function (event) {

            $("#lnkLimpiarCampos").on('click', function (event) {
                event.preventDefault();
                LimpiarCampos()
                return false;

            });


            $("#lnkReporte").on('click', function (event) {
                event.preventDefault();
                setNombresAsignados();
                GenerarReporte();
                return false;

            });

            CargarControlSeleccionCurso();
            CargarControlSeleccionLocalidad();
            CargarControlJerarquiaEmpleados();
            CargarCombos();
            inicializaControles();

            $("#cbEmpresa").on('click', function () {
                $("#hiddenEmpresa").val($(this).find('option:selected').text());
            });

            $("#cbEstatusInstructores").on('click', function () {
                $("#hiddenInstructores").val($(this).find('option:selected').text());
            });

            $("#cbEstatusEmpelados").on('click', function () {
                $("#hiddenEstatusEmpelados").val($(this).find('option:selected').text());
            });

            $("#cboCursos").on('click', function () {
                $("#hiddenCursos").val($(this).find('option:selected').text());
            });


        });

    });
}

function CargarCombos() {
    fillCombo('#cbEmpresa', 'uiReportes/uiReporteInstructores.aspx/consultaInstructoresExt', null, 0);
    fillCombo('#cbTipoContF', 'uiReportes/uiReporteInstructores.aspx/consultaTipoCont', null, 0);
    BindDataPickers();
}

function CargarControlSeleccionCurso() {
    $('#div-uiControl_Cursos').load('uiControls/PartialView/uiControl_Cursos.aspx');
}

function CargarControlSeleccionLocalidad() {
    $('#div-uiControl_Loc_Dir_Ger_Jef').load('uiControls/PartialView/uiControl_Loc_Dir_Ger_Jef.aspx');
}

function CargarControlJerarquiaEmpleados() {
    $('#divControl_JerarquiaEmpleado').load('uiControls/PartialView/uiControl_JerarquiaEmpleado.aspx');
}


function inicializaControles() {
    $('#cbEmpresa').css('visibility', 'hidden');
    $('#lblEmpresa').css('visibility', 'hidden');
}

function filtrarInstructorExt(_valor) {
    if (_valor == 4) {
        $('#cbEmpresa').css('visibility', 'visible');
        $('#lblEmpresa').css('visibility', 'visible');
    }
    else {
        $('#cbEmpresa').css('visibility', 'hidden');
        $('#lblEmpresa').css('visibility', 'hidden');
    }
}

function BindDataPickers() {
    loadCSS('Scripts/datepicker/css/datepicker.css');
    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {
        //                    $('.TxtFechaIniF').datepicker({ format: 'dd/mm/yyyy' });
        //                    $('.TxtFechaFinF').datepicker({ format: 'dd/mm/yyyy' });
        var nowTemp = new Date();
        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

        var checkin = $('#TxtFechaIniF').datepicker({
            onRender: function (date) {
                return '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {

            var newDate = new Date(ev.date)
            newDate.setDate(newDate.getDate());
            checkout.setValue(newDate);

            checkin.hide();
            $('#TxtFechaFinF')[0].focus();
        }).data('datepicker');
        var checkout = $('#TxtFechaFinF').datepicker({
            onRender: function (date) {
                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
            },
            format: 'yyyy/mm/dd'
        }).on('changeDate', function (ev) {
            checkout.hide();
        }).data('datepicker');

        if ($('#TxtFechaIniF').val() != '') {
            checkin.setValue($('#TxtFechaIniF').val());
        }

        if ($('#TxtFechaFinF').val() != '') {
            checkout.setValue($('#TxtFechaFinF').val());
        }
    });
}

function LimpiarCampos() {

    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_AreaAprendizaje").val("0");
    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_Programa option").remove();
    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_SubPrograma option").remove();
    $("#div-uiControl_Cursos #table-uiControl_Cursos #select_Curso option").remove();

    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Localidad").val("0");
    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Direccion").val("0");
    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Gerencia option").remove();
    $("#div-uiControl_Loc_Dir_Ger_Jef #table-uiControl_Loc_Dir_Ger_Jef #select_Jefatura option ").remove();

    $("#txtNombres").val("");
    $("#txtApellidoPaterno").val("");
    $("#txtApellidoMaterno").val("");
    $("#cbTipoContF").val("0");
    $("#cbEmpresa").val("0");
    $('#cbEmpresa').css('visibility', 'hidden');
    $("#TxtFechaIniF").val("");
    $("#TxtFechaFinF").val("");

    $("#cbEstatusInstructores").val("");
    $("#cbEstatusEmpelados").val("");
}



function setNombresAsignados() {
    //Test
    $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val("");

    $("#divControl_JerarquiaEmpleado #div-Grados select").each(function () {


        //Obtiene el id del control select
        var idSelect = $(this).attr('id');
        //Busca el valor seleccionado de id del select dinamico de empleado asignado
        var valId = $("#divControl_JerarquiaEmpleado #" + idSelect).val();

        if (valId > 0) {

            var textAsignados = $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val();
            textAsignados = textAsignados + $("#divControl_JerarquiaEmpleado #" + idSelect + " option:selected").html();
            $("#divControl_JerarquiaEmpleado #hiddenNombresAsignaciones").val(textAsignados + "~");

            //alert($(this).attr('id'));

        }
    });
}

function GenerarReporte() {

    var _formArray = $("#frmReporte").serializeArray();

    var myJson = objectifyForm(_formArray);
    var strJson = JSON.stringify(myJson);

    showLoader2();

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReporteInstructores.aspx/GenerarReporteInstructores',
        data: '{ frm : ' + strJson + ' }',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg != null && msg.d != "") {
                window.open("uiComun/AuxTableToXls.aspx");
            }
            else {
                debugger;
                showPopup('popup', "No se encotraron resultados ", null);
                closePopup('popup2', 0);
            }
            closePopup('popup2', 0);
        },
        error: function (request, status, error) {

            closePopup('popup2', 0);
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });


}


function objectifyForm(formArray) {//serialize data function


    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}


//function GetData(callback) {
//    buscarInstructores(1, callback);
//}

//function buscarInstructores(tipoBusqueda, callback) {
//    var _data = null;
//    var _url = 'uiReportes/uiReporteInstructores.aspx/'
//        _url = _url + 'intructoresReporte'   
//    showLoader2();
//    $.ajax({
//        type: 'POST',
//        url: _url,
//        data: _data,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (resultado) {
//            $('#content > .main').load('uiReportes/uiReporteInstructores.aspx', function (response, status, xhr) {
//                fillCombo('#cbLocalidad', 'uiReportes/uiReporteInstructores.aspx/consultaCombo', null, 0)
//                fillCombo('#cbAreaF', 'uiReportes/uiReporteInstructores.aspx/ListaAreas', null, 0)
//                fillCombo('#cbTipoContF', 'uiConsultas/uiConsultaInstructores.aspx/consultaTipoCont', null, 0);
//                BindDataPickers();
//                if (tipoBusqueda != 1)
//                    closePopup('popup2', 0);

//                if (callback && typeof (callback) === "function") {
//                    callback();
//                    closePopup('popup2', 0);
//                }
//            });
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error + request.responseText);
//                alert(request.responseText);
//            }
//        }
//    });
//}

//function filtrarArea(_valor) {
//    //var _data = '{"Id_Area":"' + _valor + '", "Id_Localidad":"' + $('#cbLocalidad').val() + '"}';
//    var _data = '{"Id_Area":"' + _valor + '", "Id_Localidad":"0"}';
//    fillCombo('#cbProgramaF', 'uiConsultas/uiConsultaInstructores.aspx/consultarAreaXProgramas', _data, 0);
//}

//function filtrarMaterias(_valor, _select) {
//    //alert('');
//    //iniciaCombos    
//    $('#cbMateriaF option').remove();
//    var _data = '{ "Id_Programa": "' + _valor + '" }';
//    fillCombo('#cbMateriaF', 'uiConsultas/uiConsultaInstructores.aspx/consultaCursoXProg', _data, 0)
//}

//function filtrarInstructorExt(_valor) {
//    if (_valor == 4) {
//        fillCombo('#cbEmpresa', 'uiCatalogos/uiEmpleados.aspx/consultaInstructoresExt', null, 0);
//        $('#cbEmpresa').css('visibility', 'visible');
//        $('#lblEmpresa').css('visibility', 'visible');
//    }
//    else {
//        $('#cbEmpresa').css('visibility', 'hidden');
//        $('#lblEmpresa').css('visibility', 'hidden');
//    }
//}

//function BindDataPickers() {
//    loadCSS('Scripts/datepicker/css/datepicker.css');
//    $.getScript('Scripts/datepicker/js/bootstrap-datepicker.js', function () {
//        //                    $('.TxtFechaIniF').datepicker({ format: 'dd/mm/yyyy' });
//        //                    $('.TxtFechaFinF').datepicker({ format: 'dd/mm/yyyy' });
//        var nowTemp = new Date();
//        var now = new Date(nowTemp.getFullYear(), nowTemp.getMonth(), nowTemp.getDate(), 0, 0, 0, 0);

//        var checkin = $('#TxtFechaIniF').datepicker({
//            onRender: function (date) {
//                return '';
//            },
//            format: 'yyyy/mm/dd'
//        }).on('changeDate', function (ev) {

//            var newDate = new Date(ev.date)
//            newDate.setDate(newDate.getDate());
//            checkout.setValue(newDate);

//            checkin.hide();
//            $('#TxtFechaFinF')[0].focus();
//        }).data('datepicker');
//        var checkout = $('#TxtFechaFinF').datepicker({
//            onRender: function (date) {
//                return date.valueOf() <= checkin.date.valueOf() ? 'disabled' : '';
//            },
//            format: 'yyyy/mm/dd'
//        }).on('changeDate', function (ev) {
//            checkout.hide();
//        }).data('datepicker');

//        if ($('#TxtFechaIniF').val() != '') {
//            checkin.setValue($('#TxtFechaIniF').val());
//        }

//        if ($('#TxtFechaFinF').val() != '') {
//            checkout.setValue($('#TxtFechaFinF').val());
//        }
//    });
//}

//function llamaCallback(callback) {
//    if (callback && typeof (callback) === "function") {
//        callback();
//    }
//}

/////Cometario X
//function Reporte() {
//    debugger;
//    var _data = null;
//    var validar = validarForm();
//    var _url = 'uiReportes/uiReporteInstructores.aspx/'
//    var result = "";
//    _url = _url + 'ReporteInstructor'
//    var Empleado = $('#lblIDEmpleado').val() == '' ? ' ' : $('#lblIDEmpleado').val();
//    var localidad = $('#cbLocalidad').val() == '' ? ' ' : $('#cbLocalidad').val();
//    var area = $('#cbAreaF').val() == '' ? ' ' : $('#cbAreaF').val();

//    var checkNom = document.getElementById('rNumNomina');
//    var checkNob = document.getElementById('rNombre');
//    var nomina;
//    var nombre;
//    if (checkNom.checked == true) {
//        nomina = $('#txtDescripcion').val() == '' ? ' ' : $('#txtDescripcion').val();
//        nombre = ' ';
//    }
//    else {
//        nomina = ' ';
//    }

//    if (checkNob.checked == true) {
//        nombre = $('#txtDescripcion').val() == '' ? ' ' : $('#txtDescripcion').val();
//        nomina = ' ';
//    }
//    else {
//        nombre = ' ';
//    }
//    var programa = $('#cbProgramaF').val() == '' ? ' ' : $('#cbProgramaF').val();
//    var materia = $('#cbMateriaF').val() == '' ? ' ' : $('#cbMateriaF').val();
//    var fechaInicial = $('#TxtFechaIniF').val() == '' ? ' ' : $('#TxtFechaIniF').val();
//    var fechaFinal = $('#TxtFechaFinF').val() == '' ? ' ' : $('#TxtFechaFinF').val();
//    var TipoContrato = $('#cbTipoContF').val() == '' ? ' ' : $('#cbTipoContF').val();
//    var InstrucExte = $('#cbEmpresa').val() == '' ? ' ' : $('#cbEmpresa').val();
//    debugger;
//    var JSONInstructor = '{"Id_Localidad":"' + localidad +
//        '", "Id_Area":"' + area +
//        '", "Id_Programa":"' + programa +
//        '", "NumNomina":"' + nomina +
//        '", "Id_Curso":"' + materia +
//        '", "Nombre":"' + nombre +
//        '", "FechaInicio":"' + fechaInicial +
//        '", "FechaFin":"' + fechaFinal +
//        '", "TipoContrato":"' + TipoContrato +
//        '", "Id_InstrucExte":"' + InstrucExte + '"}';

//    showLoader2();
//    $.ajax({
//        type: 'POST',
//        url: _url,
//        data: JSONInstructor,
//        contentType: 'application/json; charset=utf-8',
//        dataType: 'json',
//        success: function (resultado) {
//            $('#content > .main').load('uiReportes/uiReporteInstructores.aspx', function (response, status, xhr) {
//                fillCombo('#cbLocalidad', 'uiReportes/uiReporteInstructores.aspx/consultaCombo', null, 0)
//                fillCombo('#cbAreaF', 'uiReportes/uiReporteInstructores.aspx/ListaAreas', null, 0)
//                fillCombo('#cbTipoContF', 'uiConsultas/uiConsultaInstructores.aspx/consultaTipoCont', null, 0);
//                BindDataPickers();
//                window.open("uiComun/AuxTableToXls.aspx");
//            });
//            closePopup('popup2', 0);
//        },
//        error: function (request, status, error) {
//            if (request.status == 401) {
//                document.location.href = "uiPublic/uiLogin.aspx";
//            } else {
//                alert("Se ha producido el siguiente error:" + error + " " + request.responseText);
//                closePopup('popup2', 0);
//            }
//        }
//    });
//}