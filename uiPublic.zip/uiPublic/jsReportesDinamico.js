﻿/// <reference path="http://localhost:32276/Scripts/jquery-1.7.1.min.js" />

function GetData(callback) {
    loadForm();
}


function loadForm() {
    $('#content > .main').load('uiReportes/uiReportesDinamicos.aspx', function (response, status, xhr) {
        //$(document).ready(function () {
        //    loadCSS('Scripts/jsTree/jquery.jstree.js.css');
        //    cargarArbol();
        //});

        cargarComboReportes();

        $("#btnBuscar").on('click', function (e) {
            e.preventDefault();
            cargarArbol();
            return false;
        });


        $("#btnGenerarReporte").on('click', function (e) {
            e.preventDefault;
            generarReporte();
            return false;
        });


        //$.getScript('Scripts/Tree/jsTreeViewDataOptions.js', function () {
        //    cargarArbol();
        //});

    });
}



function cargarComboReportes() {
    $("#cboReportes option").remove();
    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReportesDinamicos.aspx/CargarComboReportes',
        data: null,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {


            if (msg != null) {


                var ctrCombo = $("#cboReportes");
                jsonResult = $.parseJSON(msg.d);

                //Carga el combo
                var option = '<option value="-1">Seleccione</option>';
                for (var i = 0; i < jsonResult.length; i++) {
                    option += '<option value="' + jsonResult[i].IdPadre + '">' + jsonResult[i].NombreCatalogo + '</option>';
                }

                ctrCombo.find('option').remove().end().append(option);
                option = null;
            }

        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


function cargarArbol() {

    showLoader2();

    var descCatalogo = $("#cboReportes").val();

    var jsonParam = '{"cat":"' + descCatalogo + '"}'

    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReportesDinamicos.aspx/CargarArbol',
        data: jsonParam,
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg != null && (msg.d != null || msg.d != "")) {
                var jsonResult = $.parseJSON(msg.d);


                $("#TreeView").bind("loaded.jstree", function (event, data) {
                    loadCSS('Scripts/Tree/themes/default/style.css');
                }).jstree({
                    "plugins": [
                        //"checkbox", "themes", "contextmenu", "json_data", "ui", "types", "crrm"
                         "checkbox", "themes", "json_data", "ui", "types",
                    ],

                    "json_data": {
                        "data": jsonResult
                    },


                    "types": {

                        "types": {



                            "HasSubmenus": {
                                "valid_children": "none",
                                "icon": {
                                    "image": "App_Themes/PCAP/images/TreeView/parent_menu.png"
                                }
                            },
                            "DynamicParent": {
                                "valid_children": "none",
                                "icon": {
                                    "image": "App_Themes/PCAP/images/TreeView/parent_menu.png"
                                }
                            },
                            "NoHasSubmenus": {
                                "icon": {
                                    "image": "App_Themes/PCAP/images/TreeView/single_menu.png"
                                }
                            }
                        }
                    }
                });
            }

            closePopup('popup2', 0);

        },
        error: function (request, status, error) {

            closePopup('popup2', 0);
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });
}


//function generarReporte() {

//    //Obtiene los combos seleccionados
//    //var selected = new Array();
//    //debugger;
//    //$("input:checkbox:checked").each(function () {
//    //    debugger;
//    //    selected.push($(this).val());
//    //});


//    $("input:checkbox:checked").each(
//    function () {
//        alert("El checkbox con valor " + $(this).val() + " está seleccionado");
//    });

//    debugger;

//    alert("Seleccionado");
//}


function generarReporte() {

    showLoader2();

    var checked_ids = [];
    $("#TreeView").jstree("get_checked", null, true).each
        (function () {
            checked_ids.push(this.id);
        });

    //alert(checked_ids);

    var ids = checked_ids;
    var idTablaPadre = $("#cboReportes").val();


    $.ajax({
        type: 'POST',
        url: 'uiReportes/uiReportesDinamicos.aspx/GenerarReporte',
        data: '{"IdNombreTabla":"' + idTablaPadre + '","IdsSeleccionados":"' + ids + '"}',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {

            if (msg != null && msg.d != "") {
                window.open("uiComun/AuxTableToXls.aspx");
            }
            else {
                showPopup('popup', "No se encotraron resultados ", null);
                closePopup('popup2', 0);
            }
            closePopup('popup2', 0);

            //if (msg != null) {


            //    var ctrCombo = $("#cboReportes");
            //    jsonResult = $.parseJSON(msg.d);

            //    //Carga el combo
            //    var option = '<option value="-1">Seleccione</option>';
            //    for (var i = 0; i < jsonResult.length; i++) {
            //        option += '<option value="' + jsonResult[i].IdPadre + '">' + jsonResult[i].NombreCatalogo + '</option>';
            //    }

            //    ctrCombo.find('option').remove().end().append(option);
            //    option = null;
            //}

        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
                closePopup('popup2', 0);
            }
        }
    });

    //doStuff(checked_ids)
}