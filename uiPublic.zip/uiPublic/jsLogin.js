﻿function goauthenticate() {

    var TipoAute = $('#TipoAcceso').val();
    var sistema = $('#cbSistema').val()
    var user = $('#TxtUsuario').val();
    var pass = $('#TxtPassword').val();

    if (user == '' || pass == '') {
        if (TipoAute == 1) {
            $('#LabMessageAuth').text('Introduzca Nomina y RFC para acceder a la aplicación');
            $('#MessageAuth').fadeIn("slow");

        }
        else {
            $('#LabMessageAuth').text('Introduzca nombre de usuario y contraseña para acceder a la aplicación');
            $('#MessageAuth').fadeIn("slow");
        }
    }
    else {

        $('#TxtUsuario').attr('disabled', 'disabled');
        $('#TxtPassword').attr('disabled', 'disabled');
        $('#MessageAuth').css('display', 'none');
        $('#LoaderLogin').fadeIn('slow');

        var _contentProps =
        {
            easing: 'fadeIn', //uses jQuery easing plugin
            speed: 650,
            opacity: 0.4,
            modalColor: '#F8F8F8',
            modal: true,
            modalClose: false,
            onOpen: function () {
                setTimeout(function () { $(window).resize() }, 700);
            }
        }


        $.ajax({
            type: "POST",
            url: rootLogin,
            data: '{"User":"' + user + '", "Pass":"' + pass + '", "TipoAute":"' + TipoAute + '", "Sistema":"' + sistema + '" }',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (UsrRes) {

                if (UsrRes.d.isAuthenticated) {
                    document.cookie = "UsrRes=" + UsrRes.d.UrlReferences;
                    var misCookies = document.cookie;
                    var listaCookies = misCookies.split(";")
                    for (i in listaCookies) {
                        var busca = listaCookies[i].search("IDEmpleado");
                        if (busca > -1) { micookie = listaCookies[i] }
                    }
                    var igual = micookie.indexOf("=");
                    var valor = micookie.substring(igual + 1);
                    $.ajax({
                        type: 'POST',
                        url: 'uiLogin.aspx/terminosEmpleado',
                        data: '{Id_Empleado:' + valor + '}',
                        contentType: 'application/json; charset=utf-8',
                        dataType: 'json',
                        success: function (msg) {
                            if (msg.d == 0) {
                                loadContent('#popContent > .content', '#GridContent',
                                    function () {
                                        showPContent('popContent', _contentProps);
                                    }
                                )
                            }
                            else {
                                location.href = UsrRes.d.UrlReferences
                            }
                        },
                        error: function (request, status, error) {
                            if (request.status == 401) {
                                document.location.href = "uiPublic/uiLogin.aspx";
                            } else {
                                alert("Se ha producido el siguiente error:" + error);
                            }
                        }
                    });
                }
                else {
                    if (UsrRes.d.isValid) {
                        location.href = registerPath + '?usr=' + UsrRes.d.username;
                    } else {
                        $('#LabMessageAuth').text(UsrRes.d.UrlReferences);
                        $('#LoaderLogin').fadeOut("fast", function () {
                            $('#MessageAuth').fadeIn("slow");
                            $('#TxtUsuario').removeAttr('disabled');
                            $('#TxtPassword').removeAttr('disabled');
                            $('#TxtPassword').val('');
                            $('#TxtPassword').focus();
                        });
                    }
                }
            },
            error: function (request, status, error) {
                if (request.status == 401) {
                    document.location.href = "uiPublic/uiLogin.aspx";
                } else {
                    alert("Se ha producido el siguiente error:" + error + +request.responseText);
                }
            }
        });
    }
    return false;
}

function TipoAcceso() {
    //*Alonso Nava Cambio Tipo login
    $('#TxtUsuario').val('');
    $('#TxtPassword').val('');

    if ($('#TipoAcceso').val() == 1) {
        $('#lblUsrNomina').text('Nomina');
        $('#LblContRFC').text('RFC');

    }
    else {
        $('#lblUsrNomina').text('Usuario de Red');
        $('#LblContRFC').text('Contraseña');
    }

}

function onKeyPressLogin(evt) {
    var nav = window.Event ? true : false;
    var key = nav ? evt.which : evt.keyCode;
    var res = true;
    if (key == undefined) {
        key = evt.keyCode;
    }

    if (key == 13)
        res = goauthenticate();
    //    }else if ((key >= 48 && key <= 57) || key == 45 || (key >= 97 && key <= 122) || (key >= 65 && key <= 90))
    //        res = true;
    //    else
    //        res = false;

    return res;
}

function guardarAcepto() {

    var misCookies = document.cookie;
    var listaCookies = misCookies.split(";")
    for (i in listaCookies) {
        var busca = listaCookies[i].search("IDEmpleado");
        if (busca > -1) { micookie = listaCookies[i] }
    }
    var igual = micookie.indexOf("=");
    var valor = micookie.substring(igual + 1);
    _url = 'uiLogin.aspx/agregarTeminos';

    $.ajax({
        type: 'POST',
        url: _url,
        data: '{Id_Empleado:' + valor + '}',
        contentType: 'application/json; charset=utf-8',
        dataType: 'json',
        success: function (msg) {
            if (msg.d == true) {
                for (i in listaCookies) {
                    var busca = listaCookies[i].search("UsrRes");
                    if (busca > -1) { micookie = listaCookies[i] }
                }
                var igual = micookie.indexOf("=");
                var valorUrl = micookie.substring(igual + 1);
                location.href = valorUrl;
            } else {
                showPopup('popup', 'No se pudo guardar el usuario', props)
                closePopup('popup2', 0);
            }
        },
        error: function (request, status, error) {
            if (request.status == 401) {
                document.location.href = "uiPublic/uiLogin.aspx";
            } else {
                alert("Se ha producido el siguiente error:" + error);
            }
        }
    });
}

function guardarNoAcepto() {
    closePopup('popContent', 0);
    $('#LoaderLogin').fadeOut("fast", function () {
        $('#MessageAuth').fadeIn("slow");
        $('#TxtUsuario').removeAttr('disabled');
        $('#TxtPassword').removeAttr('disabled');
        $('#TxtPassword').val('');
        $('#TxtPassword').focus();
    });
}

function chekVisible() {
    var chekedTrue = $('#chIdTeminos').val();
    if (chekedTrue == "on") {
        $('#popContent > .content #btnAcepto').css('visibility', 'visible');
    }
    else {
        $('#popContent > .content #btnAcepto').css('visibility', 'hidden');
    }
}

function loadContent(selector, content, callback) {
    $(selector).html($(content).html());
    if (callback && typeof (callback) === "function") {
        callback();
    }
}

function showPContent(elemento, propiedades) {
    popupResult = -1;
    $('#' + elemento).bPopup(propiedades);
}

function closePopup(elemento, resultado) {
    popupResult = resultado;
    $('#' + elemento).bPopup().close();
}

//CAMBIOS VLADIMIR ROMO 2018/09/14 REGISTRO DE USUARIOS

function goRegister() {
    var TipoAute = $('#TipoAcceso').val();
    //var sistema = $('#cbSistema').val()
  

        $('#TxtUsuarioR').attr('disabled', 'disabled');
        $('#TxtPasswordR').attr('disabled', 'disabled');
        $('#MessageAuthR').css('display', 'none');
       // $('#LoaderR').fadeIn('slow');

        var _contentProps =
        {
            easing: 'fadeIn', //uses jQuery easing plugin
            speed: 650,
            opacity: 0.4,
            modalColor: '#F8F8F8',
            modal: true,
            modalClose: false,
            onOpen: function () {
                setTimeout(function () { $(window).resize() }, 700);
            }
        }
        
        var _contentProps =
   {
       easing: 'fadeIn', //uses jQuery easing plugin
       speed: 650,
       opacity: 0.4,
       modalColor: '#F8F8F8',
       modal: true,
       modalClose: false,
       onOpen: function () {
           setTimeout(function () { $(window).resize(); }, 700);
       },
       onClose: function () {
           $('#styleR').remove();//se remueve css general ya que uiLogin.aspx NO hace uso y puede modificar la vista original
           $('#TxtUsuario').focus();
       }
     
       
   }
        $('#RegisterForm').load('uiUserRegister.aspx', function (response, status, xhr) {
            loadContent('#popContent > .content', '#RegisterForm', function () {
                showPContent('popContent', _contentProps);
                $('#RegisterForm').html("");//borro el contenido para no duplicar elements en el DOM
                UserRegisterInit();
            });
        });
        return false;
}
